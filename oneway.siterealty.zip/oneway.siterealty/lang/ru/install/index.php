<?
$MESS["SITEREALTY_INSTALL_NAME"] = "Сайт недвижимости";
$MESS["SITEREALTY_INSTALL_DESCRIPTION"] = "Модуль для установки готового решения сайта недвижимости";
$MESS["SITEREALTY_SPER_PARTNER"] = "Студия ONEWAY";
$MESS["SITEREALTY_PARTNER_URI"] = "http://www.onewaystudio.ru";
$MESS["SITEREALTY_INSTALL_TITLE"] = "Установка модуля";
$MESS["SITEREALTY_UNINSTALL_TITLE"] = "Удаление модуля";
?>
<?
$MESS["SITEREALTY_MOD_UNINST_OK"] = "Модуль успешно удален";
$MESS["SITEREALTY_MOD_UNINST_ERR"] = "Ошибка удаления модуля";
$MESS["SITEREALTY_MOD_BACK"] = "Вернуться назад";
?>
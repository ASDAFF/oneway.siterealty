<?
$MESS["SITEREALTY_MOD_INST_OK"] = "Модуль успешно установлен";
$MESS["SITEREALTY_MOD_INST_ERR"] = "Ошибка установки модуля";
$MESS["SITEREALTY_MOD_BACK"] = "Вернуться назад";
$MESS["SITEREALTY_INSTALL_WIZARD"] = "Перейти к <a href=\"#HREF#\">мастеру установки</a> готового решения на сайт";
?>
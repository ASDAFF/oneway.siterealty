<?
$MESS["ONEWAY_FLOOR_PROPERTY_DESCRIPTION"] = "Oneway: Этаж";
$MESS["MANSARD"] = "мансардный";
$MESS["NUM_FLOOR"] = "номер этажа:";
$MESS["COKOL"] = "цокольный";
?>
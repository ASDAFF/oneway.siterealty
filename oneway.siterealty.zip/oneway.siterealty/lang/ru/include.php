<?
$MESS["SITEREALTY_MODULE_NAME"] = "Готовое решение \"Любимый Дом\"";
$MESS["SITEREALTY_MODULE_NAME_ALT"] = "Модуль для установки готового решения для сайта недвижимости";
?>
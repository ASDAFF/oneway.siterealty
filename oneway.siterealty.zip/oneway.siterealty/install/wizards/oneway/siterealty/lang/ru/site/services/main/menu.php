<?
$MESS["WIZ_MENU_LEFT_DEFAULT"] = "Левое меню";
$MESS["WIZ_MENU_LEFT"] = "Левое меню (подуровни)";
$MESS["WIZ_MENU_LEFT_FIRST"] = "Левое меню (первый уровень)";
$MESS["WIZ_MENU_TOP"] = "Верхнее меню";
$MESS["WIZ_MENU_BOTTOM"] = "Нижнее меню";
?>
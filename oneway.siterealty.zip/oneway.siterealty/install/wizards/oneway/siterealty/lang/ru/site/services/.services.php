<?
$MESS["SITEREALTY_SERVICE_MAIN_SETTINGS"] = "Основные настройки сайта";
$MESS["SITEREALTY_SERVICE_IBLOCK"] = "Настройка инфоблоков";
?>
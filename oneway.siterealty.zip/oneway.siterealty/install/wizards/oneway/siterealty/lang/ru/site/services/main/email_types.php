<?
$MESS["REQUEST_FORM_SENT_NAME"] = "Отправлена заявка на недвижимость";
$MESS["REQUEST_FORM_SENT_DESCRIPTION"] = "
#NAME# - ФИО
#DETAIL_TEXT# - Примечания
#PROPERTY_EMAIL# - E-mail
#PROPERTY_OBJECT# - Объект
#PROPERTY_PHONE# - Телефон
#MESSAGE_ID# - Идентификатор элемента инфоблока
#MESSAGE_NAME# - Имя элемента инфоблока.
#LINK# - Путь к элементу в админке.
";
$MESS["REQUEST_FORM_SENT_SUBJECT"] = "#SITE_NAME#: Новая заявка на недвижимость";
$MESS["REQUEST_FORM_SENT_MESSAGE"] = "
Здравствуйте!<br />
<br />
Получена новая заявка на недвижимость:<br />
<br /><br />
Объект:
<br />#PROPERTY_OBJECT#<br />
<br />
ФИО:
<br />#NAME#<br />
<br />
E-mail:
<br />#PROPERTY_EMAIL#<br />
<br />
Телефон:
<br />#PROPERTY_PHONE#<br />
<br />
Примечания:
<br />#DETAIL_TEXT#<br />
<br />
<hr />
<br />
Посмотреть заявку можно по <a href=\"#LINK#\">этой ссылке</a>.
<br />
<br />
Это письмо сформировано автоматически.
";

$MESS["ORDER_FORM_SENT_NAME"] = "Отправлено сообщение из формы заказа";
$MESS["ORDER_FORM_SENT_DESCRIPTION"] = "
#NAME# - ФИО
#PROPERTY_TYPE# - Тип заявки
#PROPERTY_EMAIL# - E-mail
#PROPERTY_PHONE# - Телефон
#PROPERTY_DEAL_TYPE# - Тип сделки
#PROPERTY_CITY# - Город
#PROPERTY_REGION# - Район
#PROPERTY_ADDRESS# - Адрес
#PROPERTY_ROOMS# - Количество комнат
#PROPERTY_PRICE# - Цена
#DETAIL_TEXT# - Примечания
#MESSAGE_ID# - Идентификатор элемента инфоблока
#MESSAGE_NAME# - Имя элемента инфоблока
#LINK# - Путь к элементу в админке
";
$MESS["ORDER_FORM_SENT_SUBJECT"] = "#SITE_NAME#: Новая заявка";
$MESS["ORDER_FORM_SENT_MESSAGE"] = "
Информационное сообщение сайта #SITE_NAME#
------------------------------------------

ФИО:<br />
#NAME#<br />
<br />
Тип заявки:<br />
#PROPERTY_TYPE#<br />
<br />
E-mail:<br />
#PROPERTY_EMAIL#<br />
<br />
Телефон:<br />
#PROPERTY_PHONE#<br />
<br />
Тип сделки:<br />
#PROPERTY_DEAL_TYPE#<br />
<br />
Город:<br />
#PROPERTY_CITY#<br />
<br />
Район:<br />
#PROPERTY_REGION#<br />
<br />
Адрес:<br />
#PROPERTY_ADDRESS#<br />
<br />
Количество комнат:<br />
#PROPERTY_ROOMS#<br />
<br />
Цена:<br />
#PROPERTY_PRICE#<br />
<br />
Примечания:<br />
#DETAIL_TEXT#<br />
<br />
<hr />
<br />
Посмотреть заявку можно по <a href=\"#LINK#\">этой ссылке</a>.
<br />
<br />
Сообщение сгенерировано автоматически.
";
?>
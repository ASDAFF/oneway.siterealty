<?
$MESS["wiz_structure_data"] = "Установить демонстрационные данные корпоративного сайта.";
$MESS["wiz_restructure_data"] = "Переустановить демонстрационные данные корпоративного сайта.";
$MESS["WIZ_COMPANY_LOGO"] = "Логотип (рекомендуемый размер 316 X 77)";
$MESS["WIZ_COMPANY_SLOGAN"] = "Слоган компании";
$MESS["WIZ_COMPANY_SLOGAN_DEF"] = "Слоган компании<br />находится в этом месте";
$MESS["WIZ_COMPANY_COPY"] = "Подпись сайта";
$MESS["WIZ_COMPANY_COPY_DEF"] = "Copyright &copy; 2011 &laquo;Название сайта компании&raquo;";
$MESS["WIZ_COMPANY_PHONE"] = "Телефон компании";
$MESS["WIZ_COMPANY_CONTACTS"] = "Контактная информация";
$MESS["WIZ_COMPANY_CONTACTS_DEF"] = 'Контактная информация:<br />Адрес: Ваш адрес компании<br /> Тел.: Телефон Вашей компании';
$MESS["WIZ_COMPANY_CONTACTS_FULL"] = "Полная информация";
$MESS["WIZ_COMPANY_CONTACTS_FULL_DEF"] = '<p>Адрес:<br>Адрес Вашей компании</p><p>Тел./факс:<br>Телефон Вашей компании</p><p>Электронный адрес:<br><a href="mailto:info@email.com">info@email.com</a></p>';
$MESS["WIZ_COMPANY_PHONE_DEF"] = "+7 (495)</span><span class=\"headerTel_Number\">540-24-34";
$MESS["wiz_site_name"] = "Cайт недвижимости";
$MESS["wiz_site_desc"] = "Агентсво недвижиомсти. Все для недвижиомсти. Продажа, покупка жилых объектов";
$MESS["wiz_keywords"] = "недвижиомсть, жилая недвижимость";
$MESS["wiz_meta_data"] = "Метаданные:";
$MESS["wiz_meta_description"] = "Описание сайта:";
$MESS["wiz_meta_keywords"] = "Ключевые слова:";
$MESS["wiz_header_data"] = "Шапка сайта:";
$MESS["wiz_footer_data"] = "Подвал сайта:";
$MESS["wiz_info_data"] = "Обратная связь:";
?>
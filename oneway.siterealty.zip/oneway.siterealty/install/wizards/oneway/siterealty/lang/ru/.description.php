<?
$MESS["SITEREALTY_WIZARD_NAME"] = "Студия ONEWAY: Сайт недвижимости";
$MESS["SITEREALTY_WIZARD_DESC"] = "Мастер установки готового решения сайта агентства недвижимости";
?>
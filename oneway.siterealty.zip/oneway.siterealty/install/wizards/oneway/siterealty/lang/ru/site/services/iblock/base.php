<?
$MESS["HOT_OFFER_VALUE"] = "Да";
$MESS["DEAL_TYPE_UF_USER_FIELD"] = "Типы сделок";
?>
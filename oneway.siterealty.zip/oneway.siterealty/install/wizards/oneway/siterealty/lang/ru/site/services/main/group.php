<?
$MESS["REGISTERED_USERS"] = "Зарегистрированные пользователи";
$MESS["TASK_WIZARD_CONTENT_EDITOR"] = "Контент-редакторы";
$MESS["TASK_WIZARD_CONTENT_EDITOR_DESC"] = "Разрешено изменять информацию в своем профайле. Управление кешем";
?>
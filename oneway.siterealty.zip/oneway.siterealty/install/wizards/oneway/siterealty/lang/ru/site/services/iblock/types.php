<?
$MESS["NEWS_TYPE_NAME"] = "Дополнительно";
$MESS["NEWS_ELEMENT_NAME"] = "Дополнительно";
$MESS["NEWS_SECTION_NAME"] = "";
$MESS["CATALOG_TYPE_NAME"] = "База объектов";
$MESS["CATALOG_ELEMENT_NAME"] = "";
$MESS["CATALOG_SECTION_NAME"] = "";
?>
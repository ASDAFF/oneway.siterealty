<?
$sSectionName = "Почему мы";
$arDirProperties = Array(

);
?>
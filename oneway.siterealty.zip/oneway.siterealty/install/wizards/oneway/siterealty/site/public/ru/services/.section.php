<?
$sSectionName = "Услуги";
$arDirProperties = Array(

);
?>
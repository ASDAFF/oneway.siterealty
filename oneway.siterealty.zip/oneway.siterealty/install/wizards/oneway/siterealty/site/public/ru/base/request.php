<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?$APPLICATION->ShowHead();?>
</head>
<body>
<section class="iframeOrderBlock iframeBlock" id="-main-container">

	<?	
	 if(isset($_REQUEST['object'])){
		
		CModule::IncludeModule('iblock');
		$res = CIBlockElement::GetByID($_REQUEST['object']);
		$res = $res->Fetch();
		
		$GLOBALS['__OBJECT'] = $res['ID'];
	 }else
		die();
	 ?>

	<header class="pageTitle">
		<div class="pageTitleLine"></div>
		<div class="pageTitleText"><h1>Заявка на объект <nobr>&laquo;<?=$res['NAME']?>&raquo;</nobr></h1></div>
		<br class="clear_both">
	</header>

<?$APPLICATION->IncludeComponent("awesome:iblock.form", "request", array(
	"IBLOCK_TYPE" => "#NEWS_IBLOCK_TYPE#",
	"IBLOCK_ID" => "#REQUEST_IBLOCK_ID#",
	"FIELDS" => array(
		0 => "NAME",
		1 => "DETAIL_TEXT",
		2 => "",
	),
	"PROPS" => array(
		0 => "EMAIL",
		1 => "PHONE",
		2 => "OBJECT",
	),
	"EVENT_TYPE" => "REQUEST_FORM_SENT",
	"USE_CAPTCHA" => "Y",
	"CALENDAR_TEMPLATE" => "",
	"ERROR_CSS_CLASS" => "",
	"NAME_ALT" => "ФИО",
	"TAGS_ALT" => "",
	"ACTIVE_FROM_ALT" => "",
	"ACTIVE_TO_ALT" => "",
	"IBLOCK_SECTION_ALT" => "",
	"PREVIEW_TEXT_ALT" => "",
	"PREVIEW_PICTURE_ALT" => "",
	"DETAIL_TEXT_ALT" => "Примечания",
	"DETAIL_PICTURE_ALT" => "",
	"SORT_ALT" => "",
	"XML_ID_ALT" => "",
	"CODE_ALT" => "",
	"FETCH_OPTIONS" => "N",
	"REQUEST_PREFIX" => "",
	"FORM_NAME" => "",
	"SUCCESS_URL" => ""
	),
	false
);?>
	</section>
	
	<script type="text/javascript">
		window.resizeHandler = (function(){
			var rh = {};
			rh.$ = parent.$;
			rh.fbContent = rh.$("#fancybox-content");
			rh.container = document.getElementById('-main-container');
			rh.resize = function(dontCentrize){
				rh.fbContent.height(parseInt(rh.container.offsetHeight));
				if(typeof(dontCentrize) == 'undefined' || !dontCentrize)
					rh.$.fancybox.center();
			}
			return rh.resize;
		})();
		window.resizeHandler();
	</script>
	
</body>
</html>
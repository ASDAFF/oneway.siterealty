<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Контакты");
?>

							<!--CONTACTS-->
							<section class="contactsBlock">
								<article class="contactsInfo">
								
<?$APPLICATION->IncludeComponent(
	"bitrix:main.include",
	"",
	Array(
		"AREA_FILE_SHOW" => "file",
		"PATH" => SITE_DIR."include/contacts_full.html",
		"EDIT_TEMPLATE" => ""
	)
);?>
								</article>
								<a href="feedback.php" class="contactsFeedbackLink">Быстрая связь</a>
								<br class="clear_both">
								<script type="text/javascript">
									$(".contactsFeedbackLink").fancybox({
										'type' : 'iframe',
										'titleShow' : false,
										'centerOnScroll' : true,
										'hideOnOverlayClick' : false,
										'scrolling' : 'no',
										'autoScale' : false,
										'width' : 620,
										'height' : 460,
										'speedIn' : 500,
										'speedOut' : 500,
										'transitionIn' : 'elastic',
										'transitionOut' : 'elastic',
										'easingIn' : 'easeOutBack',
										'easingOut' : 'easeInBack',
										'overlayOpacity' : 0.8,
										'overlayColor' : '#000'
									});
								</script>
								
								<!--map-->
								<section class="contactsMap">
									<header class="contactsMap_Title"><h2>Схема расположения</h2></header>
									<div class="contactsMapBlock">									
<?$APPLICATION->IncludeComponent("bitrix:map.yandex.view", ".default", array(
	"INIT_MAP_TYPE" => "MAP",
	"MAP_DATA" => "a:4:{s:10:\"yandex_lat\";d:55.753211617578756;s:10:\"yandex_lon\";d:37.604899682617145;s:12:\"yandex_scale\";i:10;s:10:\"PLACEMARKS\";a:1:{i:0;a:3:{s:3:\"LON\";d:37.618632592773395;s:3:\"LAT\";d:55.74895173939964;s:4:\"TEXT\";s:0:\"\";}}}",
	"MAP_WIDTH" => "619",
	"MAP_HEIGHT" => "455",
	"CONTROLS" => array(
		0 => "ZOOM",
		1 => "SCALELINE",
	),
	"OPTIONS" => array(
		0 => "ENABLE_SCROLL_ZOOM",
		1 => "ENABLE_DBLCLICK_ZOOM",
		2 => "ENABLE_DRAGGING",
	),
	"MAP_ID" => ""
	),
	false
);?>
									
									</div>
								</section>
								<!--END map-->
							</section>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
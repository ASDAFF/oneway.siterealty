<?
$sSectionName = "Вакансии";
$arDirProperties = Array(

);
?>
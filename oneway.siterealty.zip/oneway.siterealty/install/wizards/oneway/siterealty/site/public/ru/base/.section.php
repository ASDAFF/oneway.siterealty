<?
$sSectionName = "Каталог недвижимости";
$arDirProperties = Array(
   "show_side_panel" => "N"
);
?>
<?
$sSectionName = "Главная";
$arDirProperties = array(
   "description" => "",
   "keywords" => "",
   "robots" => "index, follow"
);
?>
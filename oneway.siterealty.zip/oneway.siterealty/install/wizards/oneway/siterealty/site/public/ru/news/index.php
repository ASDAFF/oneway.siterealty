<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Новости");
?> Сайт находится в разработке. Раздел ожидает наполнения. <?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
<?
$sSectionName = "Отправить заявку";
$arDirProperties = Array(

);
?>
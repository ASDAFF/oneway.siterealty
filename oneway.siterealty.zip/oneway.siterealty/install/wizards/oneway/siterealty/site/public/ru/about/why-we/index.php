<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Почему мы");
?>

Сайт находится в разработке. Раздел ожидает наполнения.

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
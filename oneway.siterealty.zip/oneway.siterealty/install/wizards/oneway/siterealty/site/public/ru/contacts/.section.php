<?
$sSectionName = "Контакты";
$arDirProperties = Array(

);
?>
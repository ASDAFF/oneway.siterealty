<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$aMenuLinks = Array(
	Array(
		"Контакты", 
		"contacts/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Авторизация", 
		"login/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
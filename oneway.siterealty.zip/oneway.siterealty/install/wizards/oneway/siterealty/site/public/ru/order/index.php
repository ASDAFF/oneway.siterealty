<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Отправить заявку");
?> 

<?$APPLICATION->IncludeComponent("awesome:iblock.form", "order", array(
	"IBLOCK_TYPE" => "#NEWS_IBLOCK_TYPE#",
	"IBLOCK_ID" => "#ORDER_IBLOCK_ID#",
	"FIELDS" => array(
		0 => "NAME",
		1 => "DETAIL_TEXT",
		2 => "",
	),
	"PROPS" => array(
		0 => "TYPE",
		1 => "EMAIL",
		2 => "PHONE",
		3 => "DEAL_TYPE",
		4 => "CITY",
		5 => "REGION",
		6 => "ADDRESS",
		7 => "ROOMS",
		8 => "PRICE",
		9 => "",
	),
	"EVENT_TYPE" => "ORDER_FORM_SENT",
	"USE_CAPTCHA" => "Y",
	"CALENDAR_TEMPLATE" => "",
	"ERROR_CSS_CLASS" => "",
	"NAME_ALT" => "ФИО",
	"TAGS_ALT" => "",
	"ACTIVE_FROM_ALT" => "",
	"ACTIVE_TO_ALT" => "",
	"IBLOCK_SECTION_ALT" => "",
	"PREVIEW_TEXT_ALT" => "",
	"PREVIEW_PICTURE_ALT" => "",
	"DETAIL_TEXT_ALT" => "Примечания",
	"DETAIL_PICTURE_ALT" => "",
	"SORT_ALT" => "",
	"XML_ID_ALT" => "",
	"CODE_ALT" => "",
	"FETCH_OPTIONS" => "Y",
	"REQUEST_PREFIX" => "",
	"FORM_NAME" => "",
	"SUCCESS_URL" => ""
	),
	false
);?> 

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
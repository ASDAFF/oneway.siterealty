<?
$aMenuLinks = Array(
	Array(
		"О компании", 
		SITE_DIR."/about/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Почему мы?", 
		SITE_DIR."/about/why-we/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Новости", 
		SITE_DIR."/about/news/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вакансии", 
		SITE_DIR."/about/vacancy/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
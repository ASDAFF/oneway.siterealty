<?
$sSectionName = "Клиентам";
$arDirProperties = Array();
?>
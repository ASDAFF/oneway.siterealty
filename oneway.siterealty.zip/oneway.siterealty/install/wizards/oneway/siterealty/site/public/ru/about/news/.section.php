<?
$sSectionName = "Новости";
$arDirProperties = Array(

);
?>
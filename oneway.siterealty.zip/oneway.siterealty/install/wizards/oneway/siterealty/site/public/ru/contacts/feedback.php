<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?$APPLICATION->ShowHead();?>
</head>
<body>
	<section class="iframeOrderBlock iframeBlock" id="-main-container">

	<header class="pageTitle">
		<div class="pageTitleLine"></div>
		<div class="pageTitleText"><h1>Свяжитесь с нами</h1></div>
		<br class="clear_both">
	</header>	
	
	<?$APPLICATION->IncludeComponent("bitrix:main.feedback", "fb", Array(
		"USE_CAPTCHA" => "Y",	// Использовать защиту от автоматических сообщений (CAPTCHA) для неавторизованных пользователей
		"OK_TEXT" => "Спасибо, ваше сообщение принято.",	// Сообщение, выводимое пользователю после отправки
		"EMAIL_TO" => "",	// E-mail, на который будет отправлено письмо
		"REQUIRED_FIELDS" => array(	// Обязательные поля для заполнения
			0 => "NAME",
			1 => "EMAIL",
			2 => "MESSAGE",
		),
		"EVENT_MESSAGE_ID" => array(	// Почтовые шаблоны для отправки письма
			0 => "7",
		)
		),
		false
	);?>

	</section>
	
	<script type="text/javascript">
		window.resizeHandler = (function(){
			var rh = {};
			rh.$ = parent.$;
			rh.fbContent = rh.$("#fancybox-content");
			rh.container = document.getElementById('-main-container');
			rh.resize = function(dontCentrize){
				rh.fbContent.height(parseInt(rh.container.offsetHeight));
				if(typeof(dontCentrize) == 'undefined' || !dontCentrize)
					rh.$.fancybox.center();
			}
			return rh.resize;
		})();
		window.resizeHandler();
	</script>
	
</body>
</html>
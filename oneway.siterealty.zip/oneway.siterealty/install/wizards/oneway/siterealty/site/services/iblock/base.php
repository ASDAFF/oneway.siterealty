<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!CModule::IncludeModule("iblock")) return;

$iblockType = "CATALOG";
$iblockCode = basename(__FILE__, '.php');
$iblockXMLFile = WIZARD_SERVICE_RELATIVE_PATH."/xml/".LANGUAGE_ID."/".$iblockCode.'.xml'; 

$rsIBlock = CIBlock::GetList(array(), array("CODE" => $iblockCode, "TYPE" => $iblockType));
$iblockID = false;

if ($arIBlock = $rsIBlock->Fetch())
{
	$iblockID = $arIBlock["ID"]; 
	if (WIZARD_REINSTALL_DATA)
	{
		CIBlock::Delete($iblockID); 
		$iblockID = false; 
	}
}

if($iblockID == false)
{
	$permissions = Array(
		"1" => "X",
		"2" => "R"
	);
	
	$dbGroup = CGroup::GetList($by = "", $order = "", Array("STRING_ID" => "content_editor"));
	if($arGroup = $dbGroup->Fetch())
	{
		$permissions[$arGroup["ID"]] = 'W';
	};
	
	$iblockID = WizardServices::ImportIBlockFromXML(
		$iblockXMLFile,
		$iblockCode,
		$iblockType,
		WIZARD_SITE_ID,
		$permissions
	);
	if ($iblockID < 1) return;
	
	// IBlock form settings
	//WizardServices::SetIBlockFormSettings($iblockID, Array ( 'tabs' => GetMessage("W_IB_GROUP_PHOTOG_TAB1").$REAL_PICTURE_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB2").$rating_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB3").$vote_count_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB4").$vote_sum_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB5").$APPROVE_ELEMENT_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB6").$PUBLIC_ELEMENT_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB7"), ));
	
	//IBlock fields
	$iblock = new CIBlock;
	$arFields = Array(
		"ACTIVE" => "Y",
		"FIELDS" => array (
			'IBLOCK_SECTION' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'ACTIVE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'Y'
			),
			'ACTIVE_FROM' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => '=today'
			),
			'ACTIVE_TO' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'SORT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'NAME' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => ''
			),
			'PREVIEW_PICTURE' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => array(
					'FROM_DETAIL' => 'Y',
					'DELETE_WITH_DETAIL' => 'Y',
					'UPDATE_WITH_DETAIL' => 'Y',
					'SCALE' => 'Y',
					'METHOD' => 'resample',
					'WIDTH' => '100',
					'HEIGHT' => '99999',
					'IGNORE_ERRORS' => 'Y',
					'COMPRESSION' => 95
				)
			),
			'PREVIEW_TEXT_TYPE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'html'
			),
			'PREVIEW_TEXT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'DETAIL_PICTURE' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => array(
					'SCALE' => 'Y',
					'METHOD' => 'resample',
					'WIDTH' => '296',
					'HEIGHT' => '99999',
					'IGNORE_ERRORS' => 'Y',
					'COMPRESSION' => 95,
				)
			),
			'DETAIL_TEXT_TYPE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'html'
			),
			'DETAIL_TEXT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'XML_ID' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
                        'SECTION_CODE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => array(
					'UNIQUE' => 'Y',
					'TRANSLITERATION' => 'Y',
					'TRANS_LEN' => 100,
					'TRANS_CASE' => 'L',
					'TRANS_SPACE' => '-',
					'TRANS_OTHER' => '',
					'TRANS_EAT' => 'Y',
					'USE_GOOGLE' => 'N'
				)
			),
			'CODE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => array(
					'UNIQUE' => 'Y',
					'TRANSLITERATION' => 'Y',
					'TRANS_LEN' => 100,
					'TRANS_CASE' => 'L',
					'TRANS_SPACE' => '-',
					'TRANS_OTHER' => '',
					'TRANS_EAT' => 'Y',
					'USE_GOOGLE' => 'N'
				)
			),
			'TAGS' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
				
			)
		),
		"CODE" => $iblockCode, 
		"XML_ID" => $iblockCode,
		"NAME" => $iblock->GetArrayByID($iblockID, "NAME")
	);
	
	$iblock->Update($iblockID, $arFields);
}
else
{
	$arSites = array(); 
	$db_res = CIBlock::GetSite($iblockID);
	
	while ($res = $db_res->Fetch())
		$arSites[] = $res["LID"];
		
	if (!in_array(WIZARD_SITE_ID, $arSites))
	{
		$arSites[] = WIZARD_SITE_ID;
		$iblock = new CIBlock;
		$iblock->Update($iblockID, array("LID" => $arSites));
	}
}

$rsBaseProps = CIBlockProperty::GetList(
	array("ID" => "ASC"),
	array("IBLOCK_ID" => $iblockID)
);
$arBaseProps = array();
$hotOfferValueID = 0;

while($arProp = $rsBaseProps->GetNext())
{
	$arBaseProps["PROPERTY_".$arProp["CODE"]."_ID"] = $arProp["ID"];
	
	// Link E || G properties to iblock
	if (($arProp['PROPERTY_TYPE'] == 'E' || $arProp['PROPERTY_TYPE'] == 'G') && empty($arProp['LINK_IBLOCK_ID']))
	{
		$linkIBlockID = $_SESSION['LINK_IBLOCK_ID['.$arProp['CODE'].']'];
		
		if ($linkIBlockID > 0)
		{
			$prop = new CIBlockProperty;
			$prop->Update($arProp['ID'], array('LINK_IBLOCK_ID' => $linkIBlockID));
		}
	}
	
	// hotOffer filter
	if ($arProp['CODE'] == 'HOT_OFFER' && $arProp['PROPERTY_TYPE'] == 'L')
	{
		$arHotOfferValue = CIBlockProperty::GetPropertyEnum(
			$arProp['ID'],
			array(),
			array("IBLOCK_ID" => $iblockID, "VALUE" => GetMessage("HOT_OFFER_VALUE"))
		)->GetNext();
		$hotOfferValueID = $arHotOfferValue["ID"];
	}
}

$linkDealTypeIBlockID = $_SESSION['LINK_IBLOCK_ID[DEAL_TYPE]'];
if ($linkDealTypeIBlockID > 0)
{
    $rsUserTypeList = CUserTypeEntity::GetList(
        array(),
        array(
            'ENTITY_ID' => 'IBLOCK_'.$iblockID.'_SECTION',
            'FIELD_NAME' => 'UF_DEAL_TYPE',
            'USER_TYPE_ID' => 'iblock_element'
        )
    );
    $arUserTypeList = $rsUserTypeList->GetNext();
    $userTypeID = $arUserTypeList['ID'];
    
    if ($userTypeID > 0)
    {
        $userType = new CUserTypeEntity;
        $arUserTypeFields = array(
            'SETTINGS'          => array('IBLOCK_ID' => $linkDealTypeIBlockID, 'LIST_HEIGHT' => 10),	// добавить в настройки высоту поля
            'EDIT_FORM_LABEL'   => array('ru' => GetMessage('DEAL_TYPE_UF_USER_FIELD'), 'en' => GetMessage('DEAL_TYPE_UF_USER_FIELD'))
        );
        $userType->Update($userTypeID, $arUserTypeFields);   
    }
}

//$wizard->SetDefaultVar("LINK_IBLOCK_ID[TYPE]", $iblockID);
//$wizard->SetDefaultVar("LINK_IBLOCK_ID[OBJECT]", $iblockID);
$_SESSION['LINK_IBLOCK_ID[TYPE]'] = $_SESSION['LINK_IBLOCK_ID[OBJECT]'] = $iblockID;

$tmpInterfaceFile = str_replace("//", "/",WIZARD_SITE_ROOT_PATH."/bitrix/tmp/php_interface/init.php");
if (file_exists($tmpInterfaceFile))
{
	$arBaseProps["BASE_IBLOCK_ID"] = $iblockID;
	CWizardUtil::ReplaceMacros(
		$tmpInterfaceFile,
		$arBaseProps
	);
}

$tmpInterfaceSiteFile = str_replace("//", "/",WIZARD_SITE_ROOT_PATH."/bitrix/tmp/php_interface/classes/site.php");
if (file_exists($tmpInterfaceSiteFile))
{
	CWizardUtil::ReplaceMacros(
		$tmpInterfaceSiteFile,
		array('BASE_IBLOCK_ID' => $iblockID)
	);
}

CWizardUtil::ReplaceMacros(
	str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/base/index.php"),
	array(
		"CATALOG_IBLOCK_TYPE" => $iblockType,
		"BASE_IBLOCK_ID" => $iblockID
	)
);
CWizardUtil::ReplaceMacros(
	str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/index.php"),
	array(
		"CATALOG_IBLOCK_TYPE" => $iblockType,
		"BASE_IBLOCK_ID" => $iblockID,
		"HOT_FILTER_VALUE_ID" => $hotOfferValueID
	)
);
CWizardUtil::ReplaceMacros(
	str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/_index.php"),
	array(
		"CATALOG_IBLOCK_TYPE" => $iblockType,
		"BASE_IBLOCK_ID" => $iblockID,
		"HOT_FILTER_VALUE_ID" => $hotOfferValueID
	)
);
CWizardUtil::ReplaceMacros(
        str_replace("//", "/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/templates/".WIZARD_TEMPLATE_ID."/header.php"),
        array(
                "CATALOG_IBLOCK_TYPE" => $iblockType,
                "BASE_IBLOCK_ID" => $iblockID,
                "HOT_FILTER_VALUE_ID" => $hotOfferValueID
        )
);


//Установка значений пользовательского поля
$element_code = 'deal_types';
   CModule::IncludeModule("iblock");
   $dbE = CIBlockElement::GetList(Array(), Array('IBLOCK_CODE' => $element_code),false, array());

$mas=array(
	"kottedzhi"=>array(232,229),
	"zagorodnaya_nedvizhimost"=>array(232,229),
	"kommercheskaya_nedvizhimost"=>array(229),
	"kvartiry"=>array(230,229),
	"garazhi"=>array(232),
	"zemlya"=>array(229),
	"novostroyki"=>array(229),
);
foreach($mas as &$val)
{
foreach($val as &$val1)
		{
	 CModule::IncludeModule("iblock");
	$res = CIBlockElement::GetList(Array(), Array('IBLOCK_CODE' => $element_code, "XML_ID" => $val1),false, array());
	$arres = $res->Getnext();
	$val1=$arres["ID"];
		}
}

$arFilter = Array("IBLOCK_CODE"=>"base");
$res = CIBlockSection::GetList(Array(), $arFilter, false, Array(), Array());
$element = $res->Fetch();
$arFilter = Array("IBLOCK_CODE"=>"base");
$res = CIBlockSection::GetList(Array(), $arFilter, false, Array(), Array());
while($ob = $res->GetNext())
{
$arFields = array(
	"UF_DEAL_TYPE" => $mas[$ob['CODE']]
);
$uf_updated = $GLOBALS["USER_FIELD_MANAGER"]->Update("IBLOCK_".$element['IBLOCK_ID']."_SECTION", $ob['ID'], $arFields);
}
?>

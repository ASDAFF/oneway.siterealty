<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arServices = Array(
	"main" => Array(
		"NAME" => GetMessage("SITEREALTY_SERVICE_MAIN_SETTINGS"),
		"STAGES" => Array(
			"files.php",            // Copy public files
			"template.php",         // Install template
			"group.php",            // Install group
            "email_types.php",      // Install email types and templates
			"settings.php"          // Settings
		)
	),
	"iblock" => Array(
		"NAME" => GetMessage("SITEREALTY_SERVICE_IBLOCK"),
		"STAGES" => Array(
			"types.php",            // IBlock types
			"deal_types.php",       // Deal types iblock
            "managers.php",         // Managers iblock
            "regions.php",          // Regions iblock
            "base.php",             // Base iblock (REGION -> G -> regions.php, CPERSON -> E -> managers.php, DEAL_TYPE -> E -> deal_types.php)
            "order.php",            // Order iblock (TYPE -> G -> base.php, DEAL_TYPE -> E -> deal_types.php, )
            "request.php",          // Request iblock (OBJECT -> E -> base.php)
            "2clients.php",         // 2clients iblock
            "news.php",             // News iblock
            "vacancy.php"           // Vacancy iblock
		),
	)
);
?>
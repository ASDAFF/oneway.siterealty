<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!CModule::IncludeModule("iblock")) return;

$iblockType = "news";
$iblockCode = basename(__FILE__, '.php');
$iblockXMLFile = WIZARD_SERVICE_RELATIVE_PATH."/xml/".LANGUAGE_ID."/".$iblockCode.'.xml';  

$rsIBlock = CIBlock::GetList(array(), array("CODE" => $iblockCode, "TYPE" => $iblockType));
$iblockID = false;

if ($arIBlock = $rsIBlock->Fetch())
{
	$iblockID = $arIBlock["ID"]; 
	if (WIZARD_REINSTALL_DATA)
	{
		CIBlock::Delete($iblockID); 
		$iblockID = false; 
	}
}

if($iblockID == false)
{
	$permissions = Array(
		"1" => "X",
		"2" => "R"
	);
	
	$dbGroup = CGroup::GetList($by = "", $order = "", Array("STRING_ID" => "content_editor"));
	if($arGroup = $dbGroup->Fetch())
	{
		$permissions[$arGroup["ID"]] = 'W';
	};
	
	$iblockID = WizardServices::ImportIBlockFromXML(
		$iblockXMLFile,
		$iblockCode,
		$iblockType,
		WIZARD_SITE_ID,
		$permissions
	);

	if ($iblockID < 1) return;
	
	// IBlock form settings
	//WizardServices::SetIBlockFormSettings($iblockID, Array ( 'tabs' => GetMessage("W_IB_GROUP_PHOTOG_TAB1").$REAL_PICTURE_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB2").$rating_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB3").$vote_count_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB4").$vote_sum_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB5").$APPROVE_ELEMENT_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB6").$PUBLIC_ELEMENT_PROPERTY_ID.GetMessage("W_IB_GROUP_PHOTOG_TAB7"), ));
	
	//IBlock fields
	$iblock = new CIBlock;
	$arFields = Array(
		"ACTIVE" => "Y",
		"FIELDS" => array (
			'IBLOCK_SECTION' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'ACTIVE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'Y'
			),
			'ACTIVE_FROM' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'ACTIVE_TO' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'SORT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'NAME' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => ''
			),
			'PREVIEW_TEXT_TYPE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'html'
			),
			'PREVIEW_TEXT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'DETAIL_TEXT_TYPE' => array(
				'IS_REQUIRED' => 'Y',
				'DEFAULT_VALUE' => 'html'
			),
			'DETAIL_TEXT' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'XML_ID' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			),
			'TAGS' => array(
				'IS_REQUIRED' => 'N',
				'DEFAULT_VALUE' => ''
			)
		), 
		"CODE" => $iblockCode, 
		"XML_ID" => $iblockCode,
		"NAME" => $iblock->GetArrayByID($iblockID, "NAME")
	);
	
	$iblock->Update($iblockID, $arFields);
}
else
{
	$arSites = array(); 
	$db_res = CIBlock::GetSite($iblockID);
	
	while ($res = $db_res->Fetch())
		$arSites[] = $res["LID"];
		
	if (!in_array(WIZARD_SITE_ID, $arSites))
	{
		$arSites[] = WIZARD_SITE_ID;
		$iblock = new CIBlock;
		$iblock->Update($iblockID, array("LID" => $arSites));
	}
}

//$wizard =& $this->GetWizard();	
//$wizard->SetDefaultVar("LINK_IBLOCK_ID[DEAL_TYPE]", $iblockID);
$_SESSION['LINK_IBLOCK_ID[DEAL_TYPE]'] = $iblockID;

$tmpInterfaceSiteFile = str_replace("//", "/",WIZARD_SITE_ROOT_PATH."/bitrix/tmp/php_interface/classes/site.php");
if (file_exists($tmpInterfaceSiteFile))
{
	$rsDealTypeProp = CIBlockProperty::GetList(array(), array('IBLOCK_ID' => $iblockID, 'PROPERTY_TYPE' => 'L'));
	$arDealTypeProp = $rsDealTypeProp->GetNext();

	$arDealTypeEnum = CIBlockPropertyEnum::GetList(array(), array('IBLOCK_ID' => $iblockID, 'PROPERTY_ID' => $arDealTypeProp['ID']));

	$arDealTypeEnumValue = $arDealTypeEnum->GetNext();
	$dealTypeInBase = $arDealTypeEnumValue['ID'];

	$arDealTypeEnumValue = $arDealTypeEnum->GetNext();
	$dealTypeInOrder = $arDealTypeEnumValue['ID'];

	CWizardUtil::ReplaceMacros(
		$tmpInterfaceSiteFile,
		array(
			'DEAL_TYPES_IBLOCK_ID' => $iblockID,
			'DT_IN_BASE' => $dealTypeInBase,
			'DT_IN_ORDER' => $dealTypeInOrder
		)
	);
}
?>

<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$siteID = WIZARD_SITE_ID;
$arEventTypes = array(
    'REQUEST_FORM_SENT' => array(
        'NAME' => GetMessage('REQUEST_FORM_SENT_NAME'),
        'DESCRIPTION' => GetMessage('REQUEST_FORM_SENT_DESCRIPTION')
    ),
    'ORDER_FORM_SENT' => array(
        'NAME' => GetMessage('ORDER_FORM_SENT_NAME'),
        'DESCRIPTION' => GetMessage('ORDER_FORM_SENT_DESCRIPTION')
    )
);

foreach ($arEventTypes as $eventName => $arEvent)
{
    $oEventType = CEventType::GetList(
        array(
            "TYPE_ID" => $eventName,
            "LID"     => LANGUAGE_ID
        )                                  
    );
    if (!$oEventType->Fetch())
    {
        $oEventType = new CEventType;
        $oEventType->Add(
            array(
                'LID' => LANGUAGE_ID,
                'EVENT_NAME' => $eventName,
                'NAME' => $arEvent['NAME'],
                'DESCRIPTION' => $arEvent['DESCRIPTION']
            )
        );   
    }
    
    $oEventMessage = CEventMessage::GetList($by = $siteID, $order = "desc", array(
        "TYPE_ID" => $eventName,
        "SITE_ID" => $siteID
    ));
    if (!$oEventMessage->Fetch())
    {
        $oEventMessage  = new CEventMessage();
        $oEventMessage->Add(
            array(
                'ACTIVE'        => 'Y',
                'EVENT_NAME'    => $eventName,
                'LID'           => $siteID,
                'EMAIL_FROM'    => '#PROPERTY_EMAIL#',
                'EMAIL_TO'      => '#DEFAULT_EMAIL_FROM#',
                'SUBJECT'       => GetMessage($eventName."_SUBJECT"),
                'MESSAGE'       => GetMessage($eventName.'_MESSAGE'),
                'BODY_TYPE'     => 'html'
            )
        );   
    }
}
?>
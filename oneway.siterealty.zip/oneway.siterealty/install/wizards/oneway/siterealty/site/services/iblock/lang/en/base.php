<?
$MESS["DEAL_TYPE_UF_USER_FIELD"] = "Type orders";
?>
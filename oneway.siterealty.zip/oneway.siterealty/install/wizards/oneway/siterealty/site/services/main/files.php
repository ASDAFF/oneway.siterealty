<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!defined("WIZARD_SITE_ID")) return;

if (!defined("WIZARD_SITE_DIR")) return;

function ___writeToAreasFile($fn, $text)
{
	if(file_exists($fn) && !is_writable($abs_path) && defined("BX_FILE_PERMISSIONS"))
		@chmod($abs_path, BX_FILE_PERMISSIONS);

	$fd = @fopen($fn, "wb");
	if(!$fd)
		return false;

	if(false === fwrite($fd, $text))
	{
		fclose($fd);
		return false;
	}

	fclose($fd);

	if(defined("BX_FILE_PERMISSIONS"))
		@chmod($fn, BX_FILE_PERMISSIONS);
}
 
/*if (WIZARD_INSTALL_DEMO_DATA)
{*/



	$path = str_replace("//", "/", WIZARD_ABSOLUTE_PATH."/site/public/".LANGUAGE_ID."/"); 
	$pathInterface = str_replace("//", "/", WIZARD_ABSOLUTE_PATH."/site/php_interface/");
	$pathTmpInterface = str_replace("//", "/",WIZARD_SITE_ROOT_PATH."/bitrix/tmp/php_interface/");
	
	CheckDirPath($pathTmpInterface);
	CopyDirFiles(
		$pathInterface,
		$pathTmpInterface,
		$rewrite = true,
		$recursive = true, 
		$delete_after_copy = false
	);
	CWizardUtil::ReplaceMacros(
	str_replace("//", "/",WIZARD_SITE_ROOT_PATH."/bitrix/tmp/php_interface/classes/bx/CMBxFile.php"),
	array(
		"ROOT_FOLDER" => WIZARD_SITE_DIR,
	)
	);
	
	$handle = @opendir($path);
	if ($handle)
	{
		while ($file = readdir($handle))
		{
			if (in_array($file, array(".", "..")))
				continue; 

			CopyDirFiles(
				$path.$file,
				WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR.$file,
				$rewrite = true, 
				$recursive = true,
				$delete_after_copy = false
			);
		}
		CModule::IncludeModule("search");
		CSearch::ReIndexAll(false, 0, Array(WIZARD_SITE_ID, WIZARD_SITE_DIR));
		
		CWizardUtil::ReplaceMacros(
			str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/about/news/index.php"),
			array(
				"site_catalog" => WIZARD_SITE_DIR,
				)
		);
		CWizardUtil::ReplaceMacros(
			str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/about/vacancy/index.php"),
			array(
				"site_catalog" => WIZARD_SITE_DIR,
				)
		);
		CWizardUtil::ReplaceMacros(
			str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/base/index.php"),
			array(
				"site_catalog" => WIZARD_SITE_DIR,
				)
		);
		CWizardUtil::ReplaceMacros(
			str_replace("//", "/",WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."/info/index.php"),
			array(
				"site_catalog" => WIZARD_SITE_DIR,
				)
		);
	}

	WizardServices::PatchHtaccess(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR);

	WizardServices::ReplaceMacrosRecursive(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR, Array("SITE_DIR" => WIZARD_SITE_DIR));
	CUrlRewriter::ReIndexAll();
/*}*/

CheckDirPath(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/");
$wizard =& $this->GetWizard();

___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/contacts.html", $wizard->GetVar("siteContacts"));
___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/contacts_full.html", $wizard->GetVar("siteContactsFull"));
___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/copyright.html", $wizard->GetVar("siteCopy"));
___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/cphone.html", $wizard->GetVar("sitePhone"));
___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/slogan.html", $wizard->GetVar("siteSlogan"));

$siteLogo = $wizard->GetVar("siteLogo");
if ($siteLogo > 0)
{
	$ff = CFile::GetByID($siteLogo);
	if($zr = $ff->Fetch())
	{
		$strOldFile = str_replace("//", "/", WIZARD_SITE_ROOT_PATH."/".(COption::GetOptionString("main", "upload_dir", "upload"))."/".$zr["SUBDIR"]."/".$zr["FILE_NAME"]);
		@copy($strOldFile, WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/" . $zr["FILE_NAME"]);
		___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/logo.html", '<img src="'.WIZARD_SITE_DIR.'/include/'.$zr["FILE_NAME"].'" />');
		CFile::Delete($siteLogo);
	}
}
elseif(!file_exists($siteLogo))
{
	copy($siteLogo, WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/logo.png");
	___writeToAreasFile(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR."include/logo.html", '<img src="'.WIZARD_SITE_DIR.'include/logo.png" />');
}

if (WIZARD_INSTALL_DEMO_DATA)
{ 
	CWizardUtil::ReplaceMacros(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR.".section.php", array("SITE_DESCRIPTION" => htmlspecialchars($wizard->GetVar("siteMetaDescription"))));
	CWizardUtil::ReplaceMacros(WIZARD_SITE_ROOT_PATH.WIZARD_SITE_DIR.".section.php", array("SITE_KEYWORDS" => htmlspecialchars($wizard->GetVar("siteMetaKeywords"))));
}
?>
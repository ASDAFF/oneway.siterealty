<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?
 /*
 $first = false;
 foreach($arResult["SECTIONS"] as $arSection){
	if(!$first)
		$first = $arSection['SECTION_PAGE_URL'];
	if($arSection["ELEMENT_CNT"] > 0)
		header('Location: '.$arSection['SECTION_PAGE_URL']);
 }
 header('Location: '.$first);
 */
 ?>
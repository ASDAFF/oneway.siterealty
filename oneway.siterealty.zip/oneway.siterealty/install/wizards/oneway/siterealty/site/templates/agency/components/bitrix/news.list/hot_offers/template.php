<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if(!empty($arResult["ITEMS"])):?>

						<aside class="leftHotContainer">
							<header class="leftHotHeader"><h2><?= GetMessage('HOT_OFFERS'); ?></h2></header>
							<nav class="leftHotNav">
								<ul class="leftHotList">

<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
								
									<li class="leftHotItem" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
										<figure class="lHS_linkPicBlock">
											<a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="leftHotSection_Pic">
												<span class="lHS_Pic">
													<span class="vert_align">
														<?if(intval($arItem['PREVIEW_PICTURE']['ID'])):?>
														<?=CFile::ShowImage($arItem['PREVIEW_PICTURE']['ID'], 100, 99999, 'alt="'.$arItem['NAME'].'" title="'.$arItem['NAME'].'"')?>
														<?else:?>
															<div class="hot_no_photo"><?= GetMessage('NO_PHOTO'); ?></div>
														<?endif?>
														
													</span><span class="vert_align_helper"></span>
												</span>
											</a>
											<figcaption class="lHS_linkTitleBlock">
												<a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="lHS_Title"><?=$arItem['NAME']?></a>
												<br class="clear_both">
											</figcaption>
										</figure>
									</li>

<?endforeach;?>

								</ul>
							</nav>
						</aside>

<?endif?>
<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?//_print_r($arResult['ORDER']['INDEX'])?>


							<section class="indexLinksBlock">
								<ul class="indexLinks_List">
								
									<?//������ ����� � ����?>
									<?foreach($arResult['INDEX']['DEAL_TYPES'] as $id => $dt):?>
								
										<li class="indexLinks_Item">
											<div class="indexLinks_itemBg"></div>
											<header><h2><?=$dt['NAME']?></h2></header>
											<nav class="indexLinks_itemNav">
												<ul class="itemNav_List">
													<?foreach($dt['SECTIONS'] as $sect):?>
														<li class="itemNav_Item"><a href="<?$str=SITE_DIR; print(substr($str,0,strlen($str)-1));?><?=$arResult['SECTIONS'][$sect]['SECTION_PAGE_URL']?>#!<?=__BASE_COOKIE_GROUP?>DT=<?=$id?>"><?=$arResult['SECTIONS'][$sect]['NAME']?></a></li>
													<?endforeach?>
												</ul>
											</nav>
										</li>

									<?endforeach?>

									<?//����� ����� �� ����� ������?>
									<?foreach($arResult['ORDER']['DEAL_TYPES'] as $id => $dt):?>
									
										<?
										 $name = strlen($dt['PROPERTY_MP_NAME_VALUE']) ? $dt['PROPERTY_MP_NAME_VALUE'] : $dt['NAME'];
										 ?>
									
										<li class="indexLinks_Item">
											<div class="indexLinks_itemBg"></div>
											<header><h2><?=$name?></h2></header>
											<nav class="indexLinks_itemNav">
												<ul class="itemNav_List">
													<?
													 $sections = $arResult['ORDER']['INDEX'][$dt['ID']];
													 ?>
													<?foreach($arResult['SECTIONS'] as $sect):?>
														<?if(!isset($sections[$sect['ID']])) continue;?>
														<li class="itemNav_Item"><a href="<?print(SITE_DIR)?>order/?dtype=<?=$dt['ID']?>&type=<?=$sect['ID']?>"><?=$sect['NAME']?></a></li>
													<?endforeach?>
												</ul>
											</nav>
										</li>

									<?endforeach?>
									
								</ul>
								<br class="clear_both">
							</section>
							<script>
								setEqualHeight($('.indexLinks_Item'));
							</script>
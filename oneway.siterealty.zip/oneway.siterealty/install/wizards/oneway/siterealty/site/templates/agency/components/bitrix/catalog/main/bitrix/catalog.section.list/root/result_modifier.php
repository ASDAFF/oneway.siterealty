<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
global $APPLICATION;

$cp = $this->__component; 
if (is_object($cp)){

	$redirTo = false;
	foreach($cp->arResult["SECTIONS"] as $arSection){
		if(!$redirTo)
			$redirTo = $arSection['SECTION_PAGE_URL'];
		if($arSection["ELEMENT_CNT"] > 0){
			$redirTo = $arSection['SECTION_PAGE_URL'];
			break;
		}
	}
	
	$cp->arResult['REDIR_TO'] = $redirTo;
	$cp->SetResultCacheKeys(array('REDIR_TO'));
}
?>
<?
$MESS["SELECT_TYPE_REALTY_TEXT"] = "Выберите тип недвижимости:";
$MESS["ERROR_FIELD_SETTING"] = "Допущены ошибки при заполнении:";
$MESS["DATA_NO_SAVED"] = "Сохранение данных не произошло:";
$MESS["ORDER_SUCCESS_SEND"] = "Заявка успешно отправлена!";
$MESS["RUB"] = "руб.";
$MESS["FIELD_SELECT_SYMBOL"] = "Поля отмеченные символом";
$MESS["REQUIRED_SYMBOL"] = "*";
$MESS["REQUIRED_FIELD"] = "обязательны для заполнения";
$MESS["SEND"] = "Отправить";
$MESS["YOUR_PHONE"] = "Ваш телефон";
$MESS["YOUR_EMAIL"] = "Ваш Email";
?>
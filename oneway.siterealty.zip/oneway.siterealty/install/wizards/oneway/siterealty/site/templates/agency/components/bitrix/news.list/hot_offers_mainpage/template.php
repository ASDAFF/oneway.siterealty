<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if(!empty($arResult["ITEMS"])):?>

	<?CMacro::Add('html')?>

							<!--OBJECTS SLIDER-->
							<section class="objectsSliderBlock">
								<header class="objectsSlider_Title"><h2><?= GetMessage('HOT_OFFERS'); ?></h2></header>
								<nav class="objectsSliderNav">
									<ul class="objectsSliderList">		
		
<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
										<li class="objectsSliderItem"  id="<?=$this->GetEditAreaId($arItem['ID']);?>">
											<section>
												<figure class="lHS_linkPicBlock">
													<a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="leftHotSection_Pic">
														<span class="lHS_Pic">
															<span class="vert_align">
																<?if(intval($arItem['PREVIEW_PICTURE']['ID'])):?>
																<?=CFile::ShowImage($arItem['PREVIEW_PICTURE']['ID'], 100, 99999, 'alt="'.$arItem['NAME'].'" title="'.$arItem['NAME'].'"')?>
																<?else:?>
																	<div class="hot_no_photo"><?= GetMessage('NO_PHOTO'); ?></div>
																<?endif?>
															</span><span class="vert_align_helper"></span>
														</span>
													</a>
													<figcaption class="lHS_linkTitleBlock">
														<a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="lHS_Title"><?=$arItem['NAME']?></a>
														<br class="clear_both">
													</figcaption>
												</figure>
												<article class="objectsSliderItem_Article">
													<div class="objectsSliderItem_articleText">
														<?=$arItem['PREVIEW_TEXT']?>
													</div>
													<?if(strlen($arItem['PROPERTIES']['PRICE']['VALUE'])):?>
													<?= GetMessage('PRICE'); ?> <strong><?=CMHtml::Triada($arItem['PROPERTIES']['PRICE']['VALUE'])?></strong> <?= GetMessage('RUB'); ?>
													<?endif?>
												</article>
											</section>
										</li>
<?endforeach;?>									
										
									</ul>
									<br class="clear_both">
								</nav>
								<div class="objectsSlider_leftArrowBlock"><div class="objectsSlider_leftArrow"></div></div>
								<div class="objectsSlider_rightArrowBlock"><div class="objectsSlider_rightArrow"></div></div>
							</section>
							<script>
								// �������� �������
								$('.objectsSliderBlock').tinycarousel({
									display: 4,
									duration: 800
								});
								
								// ������ ���������� ������ � ��������� ��������
								setEqualHeight($('.objectsSliderItem'));
							</script>
							<!--end OBJECTS SLIDER-->
<?endif?>
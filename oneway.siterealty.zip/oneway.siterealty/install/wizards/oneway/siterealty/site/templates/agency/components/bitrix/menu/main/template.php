<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if (!empty($arResult)):?>

			<nav class="topMenu">
				<table class="topMenu_linksTable">
					<tr>

						<?foreach($arResult as $arItem):?>
					
						<td>
							<a href="<?=$arItem["LINK"]?>" class="topMenu_<?=($arItem["SELECTED"] ? 'linkSelected' : 'Link')?>">
								<span class="vert_align"><?=$arItem["TEXT"]?></span><span class="vert_align_helper"></span>
							</a>
						</td>

						<?endforeach?>

					</tr>
				</table>
				<script>
					$('.topMenu a').first().addClass('topMenu_linkFirst');
					$('.topMenu a').first().prepend('<span class="topMenu_Link_leftCorner"></span>');
				</script>
				<a href="<?print(SITE_DIR)?>order/" class="topMenu_sendOrder">
					<span class="topMenu_Link_leftCorner"></span>
					<span class="topMenu_Link_rightCorner"></span>
					<span class="vert_align"><?= GetMessage('SEND_ORDER_TITLE'); ?></span><span class="vert_align_helper"></span>
				</a>
				<!-- ����� ��� ����������� ������ "<?= GetMessage('SEND_ORDER_TITLE'); ?>" - "topMenu_sendOrderSelected" -->
				<br class="clear_both">
				<div class="topMenu_decorLeft">
					<div class="topMenu_decorLeftShadow"></div>
				</div>
				<div class="topMenu_decorRight">
					<div class="topMenu_decorRightShadow"></div>
				</div>
			</nav>

<?endif?>
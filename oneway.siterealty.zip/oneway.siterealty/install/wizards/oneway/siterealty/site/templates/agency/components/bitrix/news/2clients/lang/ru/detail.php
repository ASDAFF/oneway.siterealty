<?
$MESS["BACK_TO_LIST"] = "Назад к списку";
?>
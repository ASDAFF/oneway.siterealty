<?
$MESS["YEAR"] = "г.";
?>
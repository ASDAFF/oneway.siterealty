<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
 require('CItemsOut.php');
 
 $COOKIE_GROUP = __BASE_COOKIE_GROUP;
 $COOKIE_SECTION = $APPLICATION->GetCurDir(); 
 
 $ab_controller = _m_bx_restore_component_borders($arParams['IBLOCK_ID'], '.ab_items');
 ?>
 
							<section class="databaseTableBlock">
								<div class="-list-loader">������ ��������������, ���������...</div>
								<div class="-list-cs-nothing-found">� ���������, ������ ����������� �� ������� <span>:(</span></div>
								<table class="databaseTable">
									<thead>
										<tr>

											<th style="width: 220px">
												<div class="databaseTable_thBlock databaseTable_cornerFirst">
													<div class="vert_align"><a class="dT_tB_Link -list-sort" -list-sort-by="ADDR">����� � �����<img src="<?=SITE_TEMPLATE_PATH?>/img/arrow_04_up.png" width="7" height="4" alt="" /></a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock">
													<div class="vert_align"><a class="dT_tB_Link -list-sort" -list-sort-by="RMS">�����<br>������</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock" style="text-align: right;">
													<div class="vert_align"><a class="dT_tB_Link -list-sort" -list-sort-by="FL">����</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock">
													<div class="vert_align">�������, �<sup>2</sup><br><a class="dT_tB_Link -list-sort" -list-sort-by="SQ">���</a> / <a class="dT_tB_Link -list-sort" -list-sort-by="SQL">���</a> / <a class="dT_tB_Link -list-sort" -list-sort-by="SQK">���</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock" style="text-align: right;">
													<div class="vert_align">����, ���.<br><a class="dT_tB_Link -list-sort" -list-sort-by="PR">�����</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock databaseTable_cornerLast" style="text-align: right;">
													<div class="vert_align">����, ���.<br><a class="dT_tB_Link -list-sort" -list-sort-by="PRM">�� �<sup>2</sup></a></div><div class="vert_align_helper"></div>
												</div>
											</th>

										</tr>
									</thead>
									<tbody class="-list-items">

										<tr><td class="offer_links">
										<?foreach($arResult["ITEMS"] as $cell=>$arElement):?>
											<a href="<?=$arElement['DETAIL_PAGE_URL']?>"><?=$arElement['NAME']?></a><br />
										<?endforeach?>
										<?=$arResult["NAV_STRING"]?>
										</td></tr>
												
										<script type="text/html">
										<tr class="ab_items" bxElementID="%ID%" id="bx_item_%ID%">
											<td>
												<div class="databaseTable_tdRegion">%REG%</div>
												<div class="databaseTable_tdInfoBlock">
													<a href="%URL%" class="databaseTable_tdTitle">%ADDR%</a>
													<a href="%URL%?show=pics" class="dT_dT_Ico -item-pics"><img src="<?=SITE_TEMPLATE_PATH?>/img/ico_photocamera.png" width="16" height="13" alt="���������� ����������" title="���������� ����������"></a>
													<?/*
													<a href="%URL%?show=video" class="dT_dT_Ico -item-video"><img src="<?=SITE_TEMPLATE_PATH?>/img/ico_video.png" width="16" height="16" alt="���������� �����" title="���������� �����"></a>
													*/?>
												</div>
											</td>
											<td>%RMS%</td>
											<td style="text-align: right;">%FL% / %NOS%</td>
											<td>%SQ_C% / %SQ_L% / %SQ_K%</td>
											<td style="text-align: right;">%PR%</td>
											<td style="text-align: right;">%PR_M%</td>
										</tr>
										</script>

									</tbody>
								</table>
							</section>

							<?/*
							<section class="pageNaviBlock">
								<header class="pageNaviTitle">��������:</header>
								<nav class="pageNavi_navBlock">
									<a href="#" class="pageNavi_linkPrev">&laquo;&nbsp;����������</a>
									<ul class="pageNavi_numbersList">

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">1<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

										<li class="pageNavi_numbersItem">
											<span class="pageNavi_Selected">2</span>
										</li>

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">3<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">4<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

									</ul>
									<a href="#" class="pageNavi_linkNext">���������&nbsp;&raquo;</a>
									<br class="clear_both">
								</nav>
							</section>
							*/?>

						</section>

	<?
	 //_print_r($arResult['ITEMS']);
	
	 $regions = array();
	 $series = array();
	 $types = array();
	 $maxRooms = 0;
	 $maxFloor = 0;
	 $maxSquare = 0;
	 $maxCost = 0;
	 $dealTypes = array();
	 
	 foreach($arResult['ITEMS'] as $item){
	 
		// �������
		if(intval($item['PROPERTIES']['REGION']['VALUE']))
			$regions[] = $item['PROPERTIES']['REGION']['VALUE'];
		
		//����� ����
		if(intval($item['PROPERTIES']['SERIES']['VALUE_ENUM_ID']))
			$series[$item['PROPERTIES']['SERIES']['VALUE_ENUM_ID']] = $item['PROPERTIES']['SERIES']['VALUE'];
		
		//��� ����
		if(intval($item['PROPERTIES']['TYPE']['VALUE_ENUM_ID']))
			$types[$item['PROPERTIES']['TYPE']['VALUE_ENUM_ID']] = $item['PROPERTIES']['TYPE']['VALUE'];
		
		//���������� ������
		if($maxRooms < $item['PROPERTIES']['ROOMS']['VALUE'])
			$maxRooms = $item['PROPERTIES']['ROOMS']['VALUE'];

		//����
		if($maxFloor < $item['PROPERTIES']['FLOOR']['VALUE'] && $item['PROPERTIES']['FLOOR']['VALUE'] != __CItemsOut::ATTIC_FLOOR_INT)
			$maxFloor = $item['PROPERTIES']['FLOOR']['VALUE'];
			
		//���������
		if($maxCost < $item['PROPERTIES']['PRICE']['VALUE'])
			$maxCost = $item['PROPERTIES']['PRICE']['VALUE'];
			
		//����� �������
		if($maxSquare < $item['PROPERTIES']['SQUARE_TOTAL']['VALUE'])
			$maxSquare = $item['PROPERTIES']['SQUARE_TOTAL']['VALUE'];
			
		// ��� ������
		if(intval($item['PROPERTIES']['DEAL_TYPE']['VALUE_ENUM_ID']))
			$dealTypes[$item['PROPERTIES']['DEAL_TYPE']['VALUE_ENUM_ID']] = $item['PROPERTIES']['DEAL_TYPE']['VALUE'];
	 }
	 $maxSquare = ceil($maxSquare);
	 
	 $regions = array_unique($regions);
	 $series = array_unique($series);
	 $types = array_unique($types);
	 
	 // ������ ��� ������, � ����� ������� �� ��� ��, � ������� ������ ���
	 $res = CIBlockSection::GetList(array('left_margin' => 'asc', 'sort' => 'asc'), array('IBLOCK_ID' => __CItemsOut::REGION_IBLOCK_ID, 'ACTIVE' => 'Y'), false, array('ID', 'NAME', 'IBLOCK_SECTION_ID', 'DEPTH_LEVEL'));
	 $regionsActual = array();
	 $regionInfo = array();
	 while($item = $res->Fetch()){
		$regionInfo[$item['ID']] = $item;
		
		if(in_array($item['ID'], $regions)){
			$regionsActual[] = $item['ID'];
			$regionsActual[] = $item['IBLOCK_SECTION_ID'];
		}
	 }
	 $regionsActual = array_unique($regionsActual);
	 
	 foreach($regionInfo as $k => $reg)
		if(!in_array($k, $regionsActual))
			unset($regionInfo[$k]);
	
	 asort($types, SORT_STRING);
	 asort($series, SORT_STRING);
	 ?>
						
						<aside class="leftFilterBlock">
							<header class="leftFilterHeader">����� �� ����������<div class="leftFilterHeader_Arrow"></div></header>
							<form class="leftFilterForm" action="page.php" method="post">

								<div class="customSelectBlock">
									<div class="customSelect"><?=$arResult['NAME']?><div class="customSelectBlock_Arrow"></div></div>
									<!--sublvl-->
									<div class="customSelectBlock_Sublvl">
									
										<?
										 $res = CIBlockSection::GetList(array('sort' => 'asc'), array('IBLOCK_ID' => $arParams['IBLOCK_ID'], 'ACTIVE' => 'Y'), false, array('ID', 'NAME', 'SECTION_PAGE_URL'));
										 $res->SetURLTemplates();
										 ?>
										<?while($sect = $res->GetNext()):?>
											<a class="cSB_sublvlLink<?=($sect['ID'] == $arResult['ID']? ' cSB_sublvlLink_Selected' : '')?>" href="<?=$sect['SECTION_PAGE_URL']?>"><?=$sect['NAME']?></a>
										<?endwhile?>
									</div>
									<!--sublvl-->
								</div>

								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">��� ������</div>
									<br class="clear_both">

									<div class="leftFilter_items -filter-deal">
									<script type="text/html">
										<div class="leftFilter_roomsCount" class_selected="lF_rC_Selected">%VALUE%</div>
									</script>
									</div>
									
									<br class="clear_both">
								</div>
								<div class="orderForm_lineDivider"></div>
								
								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">�����</div>
									<br class="clear_both">
									<div class="customSelect03_Block">
										<select class="customSelect03 -city-select">
											<?foreach($regionInfo as $reg):?>
												<?if($reg['DEPTH_LEVEL'] == 1):?>
												<option value="<?=$reg['ID']?>"><?=$reg['NAME']?></option>
												<?endif?>
											<?endforeach?>
										</select>
										<div class="customSelect02_arrow"></div>
									</div>
								</div>
								<div class="orderForm_lineDivider"></div>

								<div class="leftFilterForm_Line area_region">
									<div class="leftFilterForm_lineTitle">�����</div>
									<div class="leftFilterForm_addButton -droplist-open-popup -droplist-smth-selected" title="��������"></div>
									<br class="clear_both">
									<a class="leftFilterForm_Param -droplist-open-popup -droplist-noting-selected">�������� ������ ������</a>
									<span class="-droplist-selected-items">
										<script type="text/html">
											<div class="leftFilterForm_selectedParam">%VALUE%<div class="lFF_sP_Close -droplist-remove-item" title="�������"></div></div>
										</script>
									</span>
									<br class="clear_both">
									<!--sublvl-->
									<div class="leftFilterForm_Sublvl -droplist-popup">
										<div class="leftFilterForm_sublvlClose -droplist-close-popup" title="�������"><div class="lFF_sC_Ico"></div></div>
										
										<div class="-droplist-available-items">
											<script type="text/html">
												<label class="lFF_S_item"><input type="checkbox" value="%ID%" name="" />%VALUE%</label><br class="clear_both">
											</script>
										</div>
										
										<div style="float: right; position: relative;">
											<input class="formButton_Orange -droplist-select" style="width: 80px;" type="submit" value="�������" name="">
										</div>
										<br class="clear_both">
									</div>
									<!--END sublvl-->
								</div>
								<div class="orderForm_lineDivider"></div>
								
								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">���������� ������</div>
									<br class="clear_both">

									<div class="leftFilter_items -filter-rooms">
									<script type="text/html">
										<div class="leftFilter_roomsCount" class_selected="lF_rC_Selected">%VALUE%</div>
									</script>
									</div>
									
									<br class="clear_both">
								</div>

								<div class="orderForm_lineDivider"></div>
								
								<?if($maxCost > 0):?>
								<div class="leftFilterForm_Line area_slider_cost">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">���������, ���.</div>
									<br class="clear_both">
									��<input type="text" id="cost-min" class="-slider-range-from range-slider">��<input type="text" id="cost-max" class="-slider-range-to range-slider">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=__CItemsOut::PriceValue($maxCost)?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<?if($maxFloor > 0):?>
								<div class="leftFilterForm_Line area_slider_floor">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">����</div>
									<br class="clear_both">
									��<input type="text" id="floor-min" class="-slider-range-from range-slider">��<input type="text" id="floor-max" class="-slider-range-to range-slider">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=$maxFloor?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<?if($maxSquare > 0):?>
								<div class="leftFilterForm_Line area_slider_square">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">����� �������, �<sup>2</sup></div>
									<br class="clear_both">
									��<input type="text" id="area-min" class="range-slider -slider-range-from">��<input type="text" id="area-max" class="range-slider -slider-range-to">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=$maxSquare?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
							
								<?if(!empty($series)):?>
								<div class="leftFilterForm_Line area_series">
									<div class="leftFilterForm_lineTitle">����� ����</div>
									<div class="leftFilterForm_addButton -droplist-open-popup -droplist-smth-selected" title="��������"></div>
									<br class="clear_both">
									<a class="leftFilterForm_Param -droplist-open-popup -droplist-noting-selected">�������� ������ �����</a>
									<span class="-droplist-selected-items">
										<script type="text/html">
											<div class="leftFilterForm_selectedParam">%VALUE%<div class="lFF_sP_Close -droplist-remove-item" title="�������"></div></div>
										</script>
									</span>
									<br class="clear_both">
									<!--sublvl-->
									<div class="leftFilterForm_Sublvl -droplist-popup">
										<div class="leftFilterForm_sublvlClose -droplist-close-popup" title="�������"><div class="lFF_sC_Ico"></div></div>
										
										<div class="-droplist-available-items">
											<script type="text/html">
												<label class="lFF_S_item"><input type="checkbox" value="%ID%" name="" />%VALUE%</label><br class="clear_both">
											</script>
										</div>
										
										<div style="float: right; position: relative;">
											<input class="formButton_Orange -droplist-select" style="width: 80px;" type="submit" value="�������" name="">
										</div>
										<br class="clear_both">
									</div>
									<!--END sublvl-->
								</div>
								<div class="orderForm_lineDivider"></div>								
								<?endif?>
								
								<?if(!empty($types)):?>
								<div class="leftFilterForm_Line area_types">
									<div class="leftFilterForm_lineTitle">��� ����</div>
									<div class="leftFilterForm_addButton -droplist-open-popup -droplist-smth-selected" title="��������"></div>
									<br class="clear_both">
									<a class="leftFilterForm_Param -droplist-open-popup -droplist-noting-selected">�������� ������ ����</a>
									<span class="-droplist-selected-items">
										<script type="text/html">
											<div class="leftFilterForm_selectedParam">%VALUE%<div class="lFF_sP_Close -droplist-remove-item" title="�������"></div></div>
										</script>
									</span>
									<br class="clear_both">
									<!--sublvl-->
									<div class="leftFilterForm_Sublvl -droplist-popup">
										<div class="leftFilterForm_sublvlClose -droplist-close-popup" title="�������"><div class="lFF_sC_Ico"></div></div>
										
										<div class="-droplist-available-items">
											<script type="text/html">
												<label class="lFF_S_item"><input type="checkbox" value="%ID%" name="" />%VALUE%</label><br class="clear_both">
											</script>
										</div>
										
										<div style="float: right; position: relative;">
											<input class="formButton_Orange -droplist-select" style="width: 80px;" type="submit" value="�������" name="">
										</div>
										<br class="clear_both">
									</div>
									<!--END sublvl-->
								</div>
								<div class="orderForm_lineDivider"></div>								
								<?endif?>

								<div class="leftFilterForm_Line">
									<a class="leftFilterForm_Reset">�������� ���������</a>
									<input class="formButton_Orange" style="float: right; width: 70px;" type="submit" value="�����" name="" onClick="return false" />
									<br class="clear_both">
								</div>

							</form>
						</aside>					

<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/ABaseClass.js?1.1"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/CCookie.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/CHash.js?<?=rand(0,9999999)?>"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/jquery-ui-slider.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/underscore.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/list.model.js?<?=rand(0,999999)?>"></script>

<script type="text/javascript">

	$(".databaseTable").stickyTableHeaders(); <?// ����� ������� ������ ������ �������� ?>
					
	(function(){
		
		<?// /base/kvartiry/#!base_REG=32&base_REG_filter=27&base_RMS=0:1&base_PR=427730-9526780 ?>
		
		var cookieHandler = new CCookie({
			path: '<?=$COOKIE_SECTION?>',
			prefix: '<?=$COOKIE_GROUP?>',
			expires: '5m',
			renewLifeTime: true
		});

		var hashHandler = new CHash({
			prefix: '<?=$COOKIE_GROUP?>'
		});
		$(document).ready(function(){
			hashHandler.cleanUp();
		});
		
		//console.dir(hashHandler.get('CITY'));
		//console.dir(hashHandler.get('PR'));
		//console.dir(hashHandler.get('REG'));
		//console.dir(hashHandler.get('RMS'));
		
		new CSimpleDrop({
			block: '.customSelectBlock',
			handle: '.customSelect',
			drop: '.customSelectBlock_Sublvl'
		});
		$('.customSelectBlock a').click(function(){
			cookieHandler.cleanUp();
		});
		
		var properties = [];
		
		<?//����� - �����?>
		var hFilter = hashHandler.get('REG_filter');
		if(hFilter.length == 0)
			hFilter = cookieHandler.get('REG_filter');
		else
			cookieHandler.cleanUp(); <?//���� �� �����?>
		$('.-city-select').val(hFilter);
		cookieHandler.set({name: 'REG_filter', value: $('.-city-select').val()});

		var items = [];
		<?foreach($regionInfo as $reg):?>
			<?if($reg['DEPTH_LEVEL'] == 2):?>
			items.push({ID: <?=$reg['ID']?>, VALUE: '<?=$reg['NAME']?>', parent: <?=$reg['IBLOCK_SECTION_ID']?>}); <?// value => ID, name => VALUE?>
			<?endif?>
		<?endforeach?>
		
		var regionSelector = new CDropListProperty({
			code: 'REG',
			area: '.area_region',
			items: items,
			initialFilter: $('.-city-select').val(),
			cookie: cookieHandler,
			hash: hashHandler
		});
		properties.push(regionSelector);
		$('.-city-select').change(function(){
			regionSelector.setFilter($(this).val());
			cookieHandler.set({name: 'REG_filter', value: $(this).val()});
		});

		<?//����� ����?>
		var items = [];
		<?foreach($series as $k=>$ser):?>
			items.push({ID: <?=$k?>, VALUE: '<?=$ser?>'});
		<?endforeach?>
		
		properties.push(new CDropListProperty({
			code: 'SER',
			area: '.area_series',
			items: items,
			cookie: cookieHandler
		}));

		<?//��� ����?>
		var items = [];
		<?foreach($types as $k=>$type):?>
			items.push({ID: <?=$k?>, VALUE: '<?=$type?>'});
		<?endforeach?>
		
		properties.push(new CDropListProperty({
			code: 'TYP',
			area: '.area_types',
			items: items,
			cookie: cookieHandler
		}));
		
		<?//����� ������?>
		properties.push(new CListProperty({
			code: 'RMS',
			items: [{ID:0, VALUE:'�������'},{ID:1, VALUE:'1'},{ID:2, VALUE:'2'},{ID:3, VALUE:'3'},{ID:4, VALUE:'4+'}],
			area: '.-filter-rooms',
			customMatch: function(val, self){				
				if($.inArray(val, self.value) >= 0)
					return true;
				if($.inArray(4, self.value) >= 0 && val > 4)
					return true;
				return false;
			},
			cookie: cookieHandler,
			hash: hashHandler
		}));

		var dTypes = [];
		<?foreach($dealTypes as $id => $text):?>
			dTypes.push({ID:<?=intval($id)?>, VALUE:'<?=$text?>'});
		<?endforeach?>
		
		<?//��� ������?>
		properties.push(new CListProperty({
			code: 'DT',
			items: dTypes,
			area: '.-filter-deal',
			cookie: cookieHandler,
			hash: hashHandler
		}));
		
		<?//���������?>
		<?if($maxCost > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'PR',
				area: '.area_slider_cost',
				min: 0,
				max: <?=$maxCost?>,
				step: 10,
				cookie: cookieHandler,
				hash: hashHandler,
				triadize: true
			}));
		<?endif?>
		<?//����?>
		<?if($maxFloor > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'FL',
				area: '.area_slider_floor',
				min: 0,
				max: <?=$maxFloor?>,
				step: 1,
				cookie: cookieHandler
			}));
		<?endif?>
		<?//����� �������?>
		<?if($maxSquare > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'SQ',
				area: '.area_slider_square',
				min: 0,
				max: <?=$maxSquare?>,
				step: 1,
				cookie: cookieHandler
			}));
		<?endif?>
		
		var items = [];
		<?foreach($arResult['ITEMS'] as $good):?>
			items.push({
				id: <?=$good['ID']?>,
				displayProps: {
								ID: '<?=$good['ID']?>',
								REG: '<?=$good['NAME']?>',
								ADDR: '<?=$good['PROPERTIES']['ADDRESS']['VALUE']?>',
								URL: '<?=$good['DETAIL_PAGE_URL']?>',
								NO_PIC: <?=(empty($good['PROPERTIES']['PHOTOS']['VALUE']) ? 'true' : 'false')?>,
								NO_VID: <?=(empty($good['PROPERTIES']['VIDEO']['VALUE']) ? 'true' : 'false')?>,
								RMS: '<?=__CItemsOut::RoomsValue($good['PROPERTIES']['ROOMS']['VALUE'])?>',
								FL: '<?=__CItemsOut::FloorValue($good['PROPERTIES']['FLOOR']['VALUE'])?>',
								NOS: '<?=__CItemsOut::EmptyValue($good['PROPERTIES']['NOS']['VALUE'])?>',
								SQ_C: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_TOTAL']['VALUE'])?>',
								SQ_L: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_LIVING']['VALUE'])?>',
								SQ_K: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])?>',
								PR: '<?=__CItemsOut::PriceValue($good['PROPERTIES']['PRICE']['VALUE'])?>',
								PR_M: '<?=__CItemsOut::PriceValue($good['PROPERTIES']['PRICE_M2']['VALUE'])?>'
							},
				filterProps: {
								PR: <?=intval($good['PROPERTIES']['PRICE']['VALUE'])?>,
								FL: <?=intval($good['PROPERTIES']['FLOOR']['VALUE'])?>,
								SQ: <?=intval($good['PROPERTIES']['SQUARE_TOTAL']['VALUE'])?>,
								SQL: <?=intval($good['PROPERTIES']['SQUARE_LIVING']['VALUE'])?>,
								SQK: <?=intval($good['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])?>,
								RMS: <?=intval($good['PROPERTIES']['ROOMS']['VALUE'])?>,
								REG: <?=intval($good['PROPERTIES']['REGION']['VALUE'])?>,
								SER: <?=intval($good['PROPERTIES']['SERIES']['VALUE_ENUM_ID'])?>,
								TYP: <?=intval($good['PROPERTIES']['TYPE']['VALUE_ENUM_ID'])?>,
								ADDR: '<?=$good['NAME']?>',
								PR: <?=floatval($good['PROPERTIES']['PRICE']['VALUE'])?>,
								PRM: <?=floatval($good['PROPERTIES']['PRICE_M2']['VALUE'])?>,
								DT: <?=intval($good['PROPERTIES']['DEAL_TYPE']['VALUE_ENUM_ID'])?>
							}
			});
			<?$cities[] = $shop['IBLOCK_SECTION_ID'];?>	
		<?endforeach?>
					
		new CCatalogRequester({
			props: properties,
			area: $('.databaseTableBlock'),
			resetButton: $('.leftFilterForm_Reset'),
			defaultSortBy: 'ADDR', <?// ���������������� ��������� � cookie ?>
			defaultSortOrder: 'asc', <?// ���������������� ��������� � cookie ?>
			
			onSortSwitch: function(wayNow, button){ <?//this ��������� �� �������� CCatalogRequester?>
				this.controls.sortButtons.find('img').remove();
				button.append('<img src="<?=SITE_TEMPLATE_PATH?>/img/arrow_04_'+(wayNow == 'asc' ? 'up' : 'down')+'.png" width="7" height="4" alt="" />');
			},
			onAfterRefresh: function(responser, itemsCount){
				var th = this.controls.list.find('tr');
				th.removeClass('databaseTable_thColor').filter(':even').addClass('databaseTable_thColor');
				th.hide().fadeIn(200);
				
				if(!this.tableLocked){
					$('.tableFloatingHeader th').lockDimensions();
					$('.tableFloatingHeaderOriginal th').lockDimensions();
					this.tableLocked = true;
				}
				
				<?=$ab_controller?>.addBorders('<?=$APPLICATION->GetCurDir()?>');
			},
			
			responser: new CCatalogResponserClientSide({
				items: items,
				onItemPostproc: function(domItem, item){
					
					if(item.displayProps.NO_PIC)
						domItem.find('.-item-pics').remove();
					if(item.displayProps.NO_VID)
						domItem.find('.-item-video').remove();
						
					return domItem;
				}
			})
		});							

		CustomSelect($('.customSelect03'));
	})();
		
	$('.leftFilterBlock').appendTo('.mainTable_leftSide');
</script>
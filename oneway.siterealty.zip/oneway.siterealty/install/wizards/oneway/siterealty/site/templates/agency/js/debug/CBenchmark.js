function CBenchmark(options){var self = this;
	
	/*** defaults ***/
	self.options = {
		probeCount: 10000,
		testIterations: 10000,
		tests: []
	}
	if(typeof(options) == 'object')
		$.extend(self.options, options);
		
	/*** public ***/
	/* props */
	
	/* methods */
	self.randomFlag = function(){
		return Math.floor(Math.random() * 10) > 5;
	};
	self.go = function(){
		if(!self._created) return;
			
		setTimeout(function(){
			
			var i = 0;
			$.each(self.options.tests, function(i, item){
				
				_print_r('Test '+i+' : '+item);
				var start = new Date();
				
				for(j=0;j<self.options.testIterations;j++){
					if(typeof(self.options.beforeTests) != 'undefined' && typeof(self.options.beforeTests[j]) == 'function')
						self.options.beforeTests[j]();
					item(self, j);
				}
				
				_print_r('On '+self.options.probeCount+' probes takes '+((new Date()).getMilliseconds()-start.getMilliseconds())+' ms');
				
			});
			
		}, 1);
	}
		
	/*** private ***/
	/* props */
	self._created = false;

	/* methods */
	self._error = function(message){
		console.error('CBenchmark: '+message);
		return self;
	}
	
    /*** init ***/
	if(self.options.tests.length == 0)
		return self._error('no test found');
		
	if(typeof(self.options.prepare) == 'function')
		self.options.prepare(self);
	
	self.area = $('body').append('<div>');
	if(typeof(self.options.makeProbe) == 'function')
		for(var i=0; i<self.options.probeCount; i++)
			self.options.makeProbe(self, i);
	
	self._created = true;
	
return self;}
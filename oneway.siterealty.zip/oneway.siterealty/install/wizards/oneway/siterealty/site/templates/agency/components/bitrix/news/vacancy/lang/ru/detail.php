<?
$MESS["BACK_TO_VACANCY"] = "Назад к списку вакансий";
?>
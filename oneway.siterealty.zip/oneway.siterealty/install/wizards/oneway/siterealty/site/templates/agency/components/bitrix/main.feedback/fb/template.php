<?if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();?>


	<?
	 if(!function_exists('__feedback_fld_required')){
		function __feedback_fld_required(&$arParams, $fld){
			if(empty($arParams["REQUIRED_FIELDS"]) || in_array($fld, $arParams["REQUIRED_FIELDS"]))
				return ' <span class="formImportant">*</span>';
		}
	 }
	 
	 //_print_r($arResult);
	 ?>
	
	<form class="iframeOrderForm" action="" method="post">
	
		<?=bitrix_sessid_post()?>
	
		<?if(!empty($arResult['ERROR_MESSAGE'])):?>
		<div class="error_message"><?= GetMessage('ERRORS_TEXT'); ?></div>
		<ul class="error_list">
			<?foreach($arResult['ERROR_MESSAGE'] as $error):?>
				<li><?=$error?></li>
			<?endforeach?>
		</ul>
		<?endif?>
	
		<div class="orderForm_lineDivider"></div>
		<div class="orderForm_Line" style="background: #eef5fb; padding: 6px 20px;">
			<div class="orderForm_lineTitle"><?= GetMessage('FIO'); ?><?=__feedback_fld_required($arParams, 'NAME')?></div>
			<div class="orderForm_lineResult<?=(in_array(GetMessage('YOUR_NAME'), $arResult['ERROR_MESSAGE']) ? ' input_error' : '')?>"><input class="lineResult_Input" type="text" name="user_name" value="<?=$arResult["AUTHOR_NAME"]?>" /></div>
			<br class="clear_both">
		</div>
		<div class="orderForm_lineDivider"></div>

		<div class="orderForm_Line" style="padding: 6px 20px;">
			<div class="orderForm_lineTitle"><?= GetMessage('YOUR_EMAIL'); ?><?=__feedback_fld_required($arParams, 'EMAIL')?></div>
			<div class="orderForm_lineResult<?=(in_array(GetMessage('INCORRECT_EMAIL'), $arResult['ERROR_MESSAGE']) || in_array(GetMessage('RESPONSE_EMAIL'), $arResult['ERROR_MESSAGE']) ? ' input_error' : '')?>"><input class="lineResult_Input" type="text" name="user_email" value="<?=$arResult["AUTHOR_EMAIL"]?>" /></div>
			<br class="clear_both">
		</div>
		<div class="orderForm_lineDivider"></div>

		<div class="orderForm_Line" style="background: #eef5fb; padding: 6px 20px;">
			<div class="orderForm_lineTitle"><?= GetMessage('YOUR_MESSAGE'); ?><?=__feedback_fld_required($arParams, 'MESSAGE')?></div>
			<div class="orderForm_lineResult<?=(in_array(GetMessage('NO_WRITE_MESSAGE'), $arResult['ERROR_MESSAGE']) ? ' input_error' : '')?>"><textarea class="lineResult_Textarea" name="MESSAGE"><?=$arResult["MESSAGE"]?></textarea></div>
			<br class="clear_both">
		</div>
		<div class="orderForm_lineDivider"></div>

		<?if($arParams["USE_CAPTCHA"] == "Y"):?>
									<div class="orderForm_Line" style="padding: 6px 20px;">
										<?$APPLICATION->IncludeComponent("oneway:system.recaptcha", "order", Array(
											'WORD_INPUT_NAME' => 'captcha_word',
											'SID_INPUT_NAME' => 'captcha_sid',
											'FAILED' => in_array(GetMessage('EMPTY_CAPTCHA_CODE'), $arResult['ERROR_MESSAGE'])
										), false, array('HIDE_ICONS' => 'Y'));?>
									</div>
									<div class="orderForm_lineDivider"></div>

		<?endif?>
		
		<input type="hidden" name="PARAMS_HASH" value="<?=$arResult["PARAMS_HASH"]?>">
		<div class="orderForm_Line" style="padding: 6px 20px;">
			<div class="orderForm_lineTitle"><?= GetMessage('REQURED_FIELDS'); ?> <span class="formImportant"><?= GetMessage('REQUIRED_SYMBOL'); ?></span><br><?= GetMessage('REQURED'); ?></div>
			<div class="orderForm_lineResult" style="text-align: right;">
				<input class="formButton_Orange" style="margin: 6px 0 0 0; width: 100px;" type="submit" value="<?= GetMessage('SEND'); ?>" name="submit">
			</div>
			<br class="clear_both">
		</div>


		<?if(!empty($arResult['OK_MESSAGE'])):?>
		<div class="successMessageBlock">
			<div class="successMessageText"><?= GetMessage('YOUR_ORDER_SUCCESS'); ?><br><?= GetMessage('MANAGER_CALL_YOU'); ?></div>
		</div>
		<?endif?>

	</form>
	<style>
		.orderForm_lineTitle{
			max-width: 200px !important;
		}
		.successMessageText{
			top: 25% !important;
		}
	</style>
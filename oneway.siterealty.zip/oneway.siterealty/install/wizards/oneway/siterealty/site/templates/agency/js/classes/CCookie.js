/*
 Класс для работы с cookie. v2.0 (24.01.2013)
 
 Требует:
 * jquery
 * ABaseClass.js >= v2.1
 
 */
function CCookie(options){
	
	var self = this;
	
	/*** defaults ***/
	self.options = {
		path: '/',
		expires: 0, // 0 or '' - remove on browser close; Nd - N days (default); Nm - N minutes;
		prefix: '', // that prefix means cookie group
		renewLifeTime: false // re-set lifetime on each .get()
	}
	ABaseClass.apply(self, [options]);
	
	/*** public ***/
	/* props */
	/* methods */
	self.set = function(params){		
		var dparams = $.extend({}, self.options);
		if(typeof(params) == 'object')
			$.extend(dparams, params);

		dparams.expires = dparams.expires == 0 ? '' : dparams.expires.toString();
			
		document.cookie = dparams.prefix+dparams.name+'='+escape(dparams.value)+'; expires='+(dparams.expires.length > 0 ? (new Date( (new Date()).getTime() + self._getMultiplier(dparams.expires)*parseInt(dparams.expires)).toUTCString()) : '')+'; path='+dparams.path;
		return self;
	}
	self.get = function(name){
		var found = '';
		$.each(document.cookie.split(';'), function(i, cookie){
			cookie = cookie.replace(/(^\s+|\s+$)/, '').split('=');
			if(self.options.prefix+name.toString() == cookie[0].toString()){
				found = cookie[1];
				return;
			}
		});
		
		found = unescape(found);
		if(self.options.renewLifeTime)
			self.set({name: name, value: found}); // path has not been preserved
		
		return found;
	}
	self.unset = function(params, dontUsePrefix){

		var dparams = $.extend({}, self.options);
		if(typeof(params) == 'object')
			$.extend(dparams, params);

		document.cookie = (dontUsePrefix ? '' : dparams.prefix)+dparams.name+'=; expires='+(new Date((new Date()).getTime() - 1)).toUTCString()+'; path='+dparams.path;
		return self;
	}
	
	// function removes cookie with specified self.options.prefix
	self.cleanUp = function(){
		$.each(document.cookie.split(';'), function(i, cookie){
			cookie = cookie.replace(/(^\s+|\s+$)/, '').split('=');
			if(cookie[0].toString().search(self.options.prefix) >= 0)
				self.unset({name: cookie[0]}, true);
		});
		return false;
	}
	
	/*** private ***/
	/* props */
	/* methods */
	self._getMultiplier = function(expires){
		// 10m 
		// 5d or just 5
		if(expires.search('m') > 0)
			return 3600000; // 1000 * 60 * 60
			
		return 86400000; // 1000 * 60 * 60 * 24
	}
	
    /*** init ***/
	
	/*** finally ***/
	self._created = true;
	
return self;}
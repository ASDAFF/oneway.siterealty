<?
$MESS["SITE_NAME"] = "Агентство Недвижимости";
$MESS["MAIN_PAGE"] = "На главную страницу";
$MESS["CONTACT_PHONE"] = "Контактный телефон";
?>
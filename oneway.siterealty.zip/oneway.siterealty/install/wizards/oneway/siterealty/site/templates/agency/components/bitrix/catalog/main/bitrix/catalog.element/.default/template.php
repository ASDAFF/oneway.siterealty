<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?//_print_r($arResult)?>

<?CMacro::Add('string')?>
<?CMacro::Add('html')?>
<?CMacro::Add('bxfile')?>
<?
 function _comma($str){
	return str_replace('.', ',', $str);
 }
 function _empty($val){
	return empty($val) || $val == '0';
 }
 ?>

							<section class="objectDetailBlock">
								<section class="objectDetailInfo">
									<!--description-->
									<article class="oDI_Description">
									<p>
										<strong><?= GetMessage('LOCATION'); ?></strong>
										<br>
										
										<?
										 $location = array();
										 if($arResult['PROPERTIES']['REGION']['VALUE']){
											$res = CIBlockSection::GetById($arResult['PROPERTIES']['REGION']['VALUE']);
											$res = $res->Fetch();
											
											$location[] = $res['NAME'].($res['DEPTH_LEVEL'] == 2 ? GetMessage('RAION'): '');
											
											if($res['IBLOCK_SECTION_ID']){
												$res = CIBlockSection::GetById($res['IBLOCK_SECTION_ID']);
												$res = $res->Fetch();
												if($res['ID'])
													array_unshift($location, $res['NAME']);
											}
										 }
										 
										 if(!empty($arResult['PROPERTIES']['ADDRESS']['VALUE']))
											$location[] = $arResult['PROPERTIES']['ADDRESS']['VALUE'];
										 ?>
										
										<?if(!empty($location)):?>
											<?=implode(', ', $location)?>
										<br><br>
										<?endif?>
										<?if(!empty($arResult['PROPERTIES']['FLOOR2']['VALUE'])):?>
											<?
											 $floor = intval($arResult['PROPERTIES']['FLOOR2']['VALUE']);
											 if($floor == __BASEMENT_FOOR_INT)
												$floor = GetMessage('COK');
											 elseif($floor == __ATTIC_FOOR_INT)
												$floor = GetMessage('MANSARD');
											 ?>
											<?=$floor?> <?= GetMessage('FLOOR'); ?>
											<?if(!empty($arResult['PROPERTIES']['NOS']['VALUE'])):?>
												<?=intval($arResult['PROPERTIES']['NOS']['VALUE'])?><?= GetMessage('FLOOR_DOM'); ?>
											<?endif?>
										<?else:?>
											<?if(!empty($arResult['PROPERTIES']['NOS']['VALUE'])):?>
												<?=intval($arResult['PROPERTIES']['NOS']['VALUE'])?><?= GetMessage('FLOOR_DOM2'); ?>
											<?endif?>
										<?endif?>
										<br />
										<?if(strlen($arResult['PROPERTIES']['TYPE']['VALUE'])):?>
											<?= GetMessage('DOM'); ?> <?=ToLower($arResult['PROPERTIES']['TYPE']['VALUE'])?>,
										<?endif?>
										<?if(strlen($arResult['PROPERTIES']['SERIES']['VALUE'])):?>
											<?= GetMessage('SERIA'); ?> <?=ToLower($arResult['PROPERTIES']['SERIES']['VALUE'])?>
										<?endif?>
									</p>
									
									<?if(strlen($arResult['DETAIL_TEXT'])):?>
									<p>
										<strong><?= GetMessage('EXT_INFO'); ?></strong>
										<br />
										<?=$arResult['DETAIL_TEXT']?>
									</p>
									<?endif?>
									
									</article>
									<article class="oDI_Params">
										<?if(!_empty($arResult['PROPERTIES']['PRICE']['VALUE'])):?>
										<p>
											<strong><?= GetMessage('TOTAL_PRICE'); ?></strong>
											<br>
											<span class="oDI_paramsCost"><?=CMHtml::Triada($arResult['PROPERTIES']['PRICE']['VALUE'])?></span>&nbsp;<?= GetMessage('RUB'); ?>
										</p>
										<?endif?>
										<?if(!_empty($arResult['PROPERTIES']['PRICE_M2']['VALUE'])):?>
										<p>
											<strong><?= GetMessage('PRICE_MSQUARE'); ?></strong>
											<br>
											<span class="oDI_paramsCost"><?=CMHtml::Triada($arResult['PROPERTIES']['PRICE_M2']['VALUE'])?></span>&nbsp;<?= GetMessage('RUB'); ?>
										</p>
										<?endif?>
										<?if(!_empty($arResult['PROPERTIES']['SQUARE_TOTAL']['VALUE']) || !_empty($arResult['PROPERTIES']['SQUARE_LIVING']['VALUE']) || !_empty($arResult['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])):?>
										<p>
											<strong><?= GetMessage('SQUARE'); ?></strong>
											<br>
											<?if(!_empty($arResult['PROPERTIES']['SQUARE_TOTAL']['VALUE'])):?>
											<span class="oDI_paramsDimensions">
												<?= GetMessage('TOTAL_SQUARE'); ?><br>
												<?=_comma($arResult['PROPERTIES']['SQUARE_TOTAL']['VALUE'])?> <?= GetMessage('M'); ?><sup>2</sup>
											</span>
											<?endif?>
											<?if(!_empty($arResult['PROPERTIES']['SQUARE_LIVING']['VALUE'])):?>
											<span class="oDI_paramsDimensions">
												<?= GetMessage('LIVE_SQUARE'); ?><br>
												<?=_comma($arResult['PROPERTIES']['SQUARE_LIVING']['VALUE'])?> <?= GetMessage('M'); ?><sup>2</sup>
											</span>
											<?endif?>
											<?if(!_empty($arResult['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])):?>
											<span class="oDI_paramsDimensions">
												<?= GetMessage('KITCHEN_SQUARE'); ?><br>
												<?=_comma($arResult['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])?> <?= GetMessage('M'); ?><sup>2</sup>
											</span>
											<?endif?>
											<br class="clear_both">
										</p>
										<?endif?>
									</article>
									<br class="clear_both">
									
									<?if(strlen($arResult['PROPERTIES']['YAMAP']['VALUE'])):?>
									<section class="objectDetailMap">
										<header class="objectDetailMap_Title"><h2><?= GetMessage('OBJECT_MAP'); ?></h2></header>
										<div class="objectDetailMapBlock">
											<?=str_replace('zoom: 10', 'zoom: 16', $arResult['DISPLAY_PROPERTIES']['YAMAP']['DISPLAY_VALUE'])?>
										</div>
										<script type="text/javascript">
											$('.bx-yandex-map').width('552px');
										</script>
									</section>
									<?endif?>
									
								</section>
								<aside class="objectDetailAside">
									<!--pics-->
									
									<?if(!empty($arResult['PROPERTIES']['PHOTOS']['VALUE'])):?>
									<section class="objectDetailPicsBlock">
									
										<?
										 $count = count($arResult['PROPERTIES']['PHOTOS']['VALUE']);
										
										 $photo = CFile::GetByID(array_shift($arResult['PROPERTIES']['PHOTOS']['VALUE']));
										 $photo = $photo->Fetch();
										 $photo = CMBxFile::File($photo['ID']);
										 
										 array_shift($arResult['PROPERTIES']['PHOTOS_THUMB']['VALUE']); // ��������� ���� thumb
										 ?>
									
										<a href="<?=$photo['SRC']?>" class="oDPB_bigPic" rel="pics">

											<?=CFile::ShowImage($arResult['DETAIL_PICTURE']['ID'], 296, 999999, 'alt="'.$arResult['NAME'].'" title="'.$arResult['NAME'].'"')?>
											
											<span class="oDPB_bP_Zoom"></span>
											<span class="oDPB_picsCountBg"></span>
											<span class="oDPB_picsCountText"><?= GetMessage('PHOTOS'); ?> <?=$count?></span>
										</a>
										
										<?if(!empty($arResult['PROPERTIES']['PHOTOS']['VALUE'])):?>
										<div class="oDPB_smallPicsBlock">

											<?foreach($arResult['PROPERTIES']['PHOTOS']['VALUE'] as $file):?>
												<?
												 $thumb = array_shift($arResult['PROPERTIES']['PHOTOS_THUMB']['VALUE']);
												 $photo = CMBxFile::File($file);
												 ?>
										
											<a href="<?=$photo['SRC']?>" class="oDPB_smallPic" rel="pics">
												<span class="vert_align">
													<?=CFile::ShowImage($thumb)?>
												</span><span class="vert_align_helper"></span>
											</a>

											<?endforeach?>
											
											<br class="clear_both">
										</div>
										<?endif?>
										
									</section>
									<?endif?>
									
									<?if(!empty($arResult['PROPERTIES']['PLAN']['VALUE'])):?>
									<section class="objectDetailPicsBlock">
										<header class="objectDetailPlanesTitle"><h2><?= GetMessage('PLAN'); ?></h2></header>
										<div class="oDPB_smallPicsBlock">

											<?foreach($arResult['PROPERTIES']['PLAN']['VALUE'] as $file):?>
												<?
												 $thumb = array_shift($arResult['PROPERTIES']['PLAN_THUMB']['VALUE']);
												 $photo = CMBxFile::File($file);
												 ?>
										
												<a href="<?=$photo['SRC']?>" class="oDPB_smallPic" rel="planes">
													<span class="vert_align"><?=CFile::ShowImage($thumb)?></span><span class="vert_align_helper"></span>
												</a>

											<?endforeach?>
											
											<br class="clear_both">
										</div>
									</section>
									<?endif?>
									
									<?if(intval($arResult['PROPERTIES']['CPERSON']['VALUE'])):?>
										<?
										 $res = CIBlockElement::GetList(false, array('ID' => $arResult['PROPERTIES']['CPERSON']['VALUE'], 'ACTIVE' => 'Y'), false, false, array('*', 'PROPERTY_PHONE', 'PROPERTY_EMAIL'));
										 $res = $res->Fetch();
										 ?>
									<section class="objectDetailContactsBlock">
										<header class="objectDetailContactsTitle"><h2><?= GetMessage('CONTACT_INFO'); ?></h2></header>
										<article class="objectDetailContactsText">
											<?=$res['NAME']?>
											<br>
											<?if(strlen($res['PROPERTY_PHONE_VALUE'])):?>
												<?= GetMessage('PHONE'); ?> <?=$res['PROPERTY_PHONE_VALUE']?>
											<br>
											<?endif?>
											<?if(strlen($res['PROPERTY_EMAIL_VALUE'])):?>
												<?= GetMessage('EMAIL'); ?> <a href="mailto:<?=$res['PROPERTY_EMAIL_VALUE']?>"><?=$res['PROPERTY_EMAIL_VALUE']?></a>
											<br>
											<?endif?>
											<a href="<?= SITE_DIR ?>base/request.php?object=<?=$arResult['ID']?>" class="objectDetailSendOrder"><?= GetMessage('SEND_ORDER'); ?></a>
											<br class="clear_both">
										</article>
									</section>
									<?endif?>
									
								</aside>
								<br class="clear_both">
							</section>
							<script>
								// ���� � Fancybox
								$("a[rel=pics]").fancybox({
									'titleShow' : false,
									'centerOnScroll' : true,
									'speedIn' : 500,
									'speedOut' : 500,
									'transitionIn' : 'elastic',
									'transitionOut' : 'elastic',
									'easingIn' : 'easeOutBack',
									'easingOut' : 'easeInBack',
									'overlayOpacity' : 0.8,
									'overlayColor' : '#000'
								});

								// ����� � Fancybox
								$("a[rel=planes]").fancybox({
									'titleShow' : false,
									'centerOnScroll' : true,
									'speedIn' : 500,
									'speedOut' : 500,
									'transitionIn' : 'elastic',
									'transitionOut' : 'elastic',
									'easingIn' : 'easeOutBack',
									'easingOut' : 'easeInBack',
									'overlayOpacity' : 0.8,
									'overlayColor' : '#000'
								});

								// ������ Fancybox
								$(".objectDetailSendOrder").fancybox({
									'type' : 'iframe',
									'titleShow' : false,
									'centerOnScroll' : true,
									'hideOnOverlayClick' : false,
									'scrolling' : 'no',
									'autoScale' : false,
									'width' : 620,
									'height' : 460,
									'speedIn' : 500,
									'speedOut' : 500,
									'transitionIn' : 'elastic',
									'transitionOut' : 'elastic',
									'easingIn' : 'easeOutBack',
									'easingOut' : 'easeInBack',
									'overlayOpacity' : 0.8,
									'overlayColor' : '#000'
								});
								
  $.fn.center = function(selector){
			if(!selector)
				selector = '.-m-center-item';
	  
			$(this).css({
				'text-align': 'center',
				'position': 'relative',
				'overflow': 'hidden'
			});
			$(this).each(function(){
			
				var item = $(selector, this);
				var _this = $(this);
				
				var margin_top = Math.floor((parseInt(_this.height()) - parseInt(item.height()))/2);
				var margin_left = Math.floor((parseInt(_this.width()) - parseInt(item.width()))/2);
				
				item.css({
					/*
					'position': 'absolute',
					'top': 0,
					'left': 0,
					*/
					'margin-top': margin_top+'px', 
					'margin-left': margin_left+'px'
				});
			});
  };
							$('.oDPB_smallPicsBlock a').center('img');
								
							</script>
<?$arTemplate = Array(
	"NAME"=>GetMessage('SITEREALTY_TEMPLATE_NAME'), 
	"DESCRIPTION"=>GetMessage('SITEREALTY_TEMPLATE_DESC')
);?>
<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

							<div class="vacancyDetailBlock">
								<div class="vacancyAva"></div>
								<section class="vacancyInfo">
									<header class="newsDetailTitle"><h1><?=$arResult['NAME']?></h1></header>
									<article>
	
<?$APPLICATION->IncludeComponent(
	"bitrix:main.include",
	"",
	Array(
		"AREA_FILE_SHOW" => "file",
		"PATH" => SITE_DIR."/include/vacancy_detail_before.html", // $templateFolder."/includes/before.html",
		"EDIT_TEMPLATE" => ""
	)
);?>	
	
									<?if(strlen($arResult['PROPERTIES']['REQUIRED']['VALUE']['TEXT'])):?>
	
										<span style="font-size: 16px;"><strong><?= GetMessage("REQ"); ?></strong></span>
											<?=htmlspecialchars_decode($arResult['PROPERTIES']['REQUIRED']['VALUE']['TEXT'])?>
										<br>
										
									<?endif?>

									<?if(strlen($arResult['PROPERTIES']['DUTY']['VALUE']['TEXT'])):?>
	
										<span style="font-size: 16px;"><strong><?= GetMessage('OB'); ?></strong></span>
											<?=htmlspecialchars_decode($arResult['PROPERTIES']['DUTY']['VALUE']['TEXT'])?>
										<br>
										
									<?endif?>
									
									<?if(strlen($arResult['PROPERTIES']['PAYMENT']['VALUE']['TEXT'])):?>
	
										<span style="font-size: 16px;"><strong><?= GetMessage('YOU_GET'); ?></strong></span>
											<?=htmlspecialchars_decode($arResult['PROPERTIES']['PAYMENT']['VALUE']['TEXT'])?>
										<br>
										
									<?endif?>
									</article>
								</section>
								<br class="clear_both">
								<div class="vacancyDetailLine"></div>
								<section class="vacancyInfo">

<?$APPLICATION->IncludeComponent(
	"bitrix:main.include",
	"",
	Array(
		"AREA_FILE_SHOW" => "file",
		"PATH" => SITE_DIR."/include/vacancy_detail_after.html",  // $templateFolder."/includes/after.html",
		"EDIT_TEMPLATE" => ""
	)
);?>								
								
								</section>
								<br class="clear_both">
							</div>
<?
$MESS["ERRORS_TEXT"] = "Допущены ошибки при заполнении:";
$MESS["FIO"] = "ФИО";
$MESS["YOUR_NAME"] = "Укажите ваше имя.";
$MESS["YOUR_EMAIL"] = "Ваш Email";
$MESS["YOUR_MESSAGE"] = "Сообщение";
$MESS["INCORRECT_EMAIL"] = "Указанный E-mail некорректен.";
$MESS["RESPONSE_EMAIL"] = "Укажите E-mail, на который хотите получить ответ.";
$MESS["YOUR_MESSEGE"] = "Сообщение";
$MESS["NO_WRITE_MESSAGE"] = "Вы не написали сообщение.";
$MESS["EMPTY_CAPTCHA_CODE"] = "Не указан код защиты от автоматических сообщений.";
$MESS["REQURED_FIELDS"] = "Поля отмеченные символом";
$MESS["REQUIRED_SYMBOL"] = "*";
$MESS["REQURED"] = "обязательны для заполнения";
$MESS["SEND"] = "Отправить";
$MESS["YOUR_ORDER_SUCCESS"] = "Спасибо! Ваша заявка принята.";
$MESS["MANAGER_CALL_YOU"] = "В ближайшее время с Вами свяжется наш менеджер.";
?>
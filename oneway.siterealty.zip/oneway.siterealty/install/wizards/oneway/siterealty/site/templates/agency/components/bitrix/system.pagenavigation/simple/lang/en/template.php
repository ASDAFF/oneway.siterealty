<?
$MESS ['nav_of'] = "of";
$MESS ['nav_begin'] = "first";
$MESS ['nav_prev'] = "prev.";
$MESS ['nav_next'] = "next";
$MESS ['nav_end'] = "last";
$MESS ['nav_paged'] = "paged";
$MESS ['nav_all'] = "all";
?>
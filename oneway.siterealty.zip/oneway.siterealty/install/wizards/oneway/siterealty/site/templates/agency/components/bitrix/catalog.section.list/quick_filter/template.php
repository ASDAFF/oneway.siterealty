<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

	<?CMacro::Add('html')?>
	<?
	 // ��� � "���" ����, ��� � �������� ��� ���������� �������
	 $res = CIBlockElement::GetList(array('PROPERTY_PRICE' => 'DESC'), array('ACTIVE' => 'Y', 'IBLOCK_ID' => __BASE_IBLOCK_ID), false, array('nTopCount' => 1), array('ID', 'PROPERTY_PRICE'));	 
	 $res = $res->Fetch();
	 $maxCost = intval($res['PROPERTY_PRICE_VALUE']) ? intval($res['PROPERTY_PRICE_VALUE']) : 10000000;
	 ?>

							<section class="indexQuickSearch">
								<header class="indexQuickSearch_Title"><?= GetMessage('QUICK_SEARCH'); ?></header>
								<div class="indexQuickSearch_Ico"></div>
								<form class="indexQuickSearchForm" action="" method="post">

									<div class="indexQuickSearch_Line">
										<div class="indexQuickSearch_lineTitle"><?= GetMessage('CITY'); ?></div>
										<div class="customSelect02_Block">
											<select class="customSelect02 -filter-city">
											</select>
											<div class="customSelect02_arrow"></div>
										</div>
									</div>

									<div class="indexQuickSearch_Line">
										<div class="indexQuickSearch_lineTitle"><?= GetMessage('RAION'); ?></div>
										<div class="customSelect02_Block">
											<select class="customSelect02 -filter-region">
											</select>
											<div class="customSelect02_arrow"></div>
										</div>
									</div>

									<div class="indexQuickSearch_Line">
										<div class="indexQuickSearch_lineTitle"><?= GetMessage('TYPE_REALTY'); ?></div>
										<div class="customSelect02_Block">
											<select class="customSelect02 -filter-type">
											</select>
											<div class="customSelect02_arrow"></div>
										</div>
									</div>

								<div class="indexQuickSearch_Line">
									<div class="leftFilterForm_lineTitle"><?= GetMessage('COUNT_ROOMS'); ?></div>
									<br class="clear_both">

									<div class="leftFilter_items">
									<script type="text/html">
										<div class="leftFilter_roomsCount lf_roomsCount_whitebg" class_selected="lF_rC_Selected">%VALUE%</div>
									</script>
									</div>
									
									<br class="clear_both">
								</div>
									
									<div class="indexQuickSearch_Line area_slider_cost">
										<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;"><?= GetMessage('COST'); ?></div>
										
										<br class="clear_both">
										<?= GetMessage('FROM'); ?><input type="text" id="cost-min" class="-slider-range-from range-slider"><?= GetMessage('TO'); ?><input type="text" id="cost-max" class="-slider-range-to range-slider"><?= GetMessage('RUB'); ?>
										<br class="clear_both">
										
										<div class="-slider-area" style="width: 255px;"></div>
										
										<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral_wide.png" width="255" height="20" alt="">
										<span class="ruler_right_border"><?=CMHtml::Triada($maxCost)?></span>
										<span class="ruler_left_border">0</span>
										
									</div>

									<div class="indexQuickSearch_Line" style="text-align: right;">
										<input class="formButton_Orange" style="margin: 10px 0 0 0; width: 70px;" type="submit" value="<?= GetMessage('SEARCH'); ?>" name="">
									</div>

								</form>
							</section>

							
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/ABaseClass.js?1.1"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/CCookie.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/jquery-ui-slider.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/underscore.js"></script>							
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/list.model.js?<?=rand(0,999999)?>"></script>

<script type="text/javascript">
	(function(){

		var cities = [];
		var regions = [];
		var types = [];
		<?foreach($arResult["SECTIONS"] as $arSection):?>
			<?if($arSection['DEPTH_LEVEL'] == 1):?>
				cities.push({ID: <?=$arSection['ID']?>, VALUE: '<?=$arSection['NAME']?>', parent: false});
			<?elseif($arSection['DEPTH_LEVEL'] == 2 && intval($arSection['IBLOCK_SECTION_ID'])):?>
				regions.push({ID: <?=$arSection['ID']?>, VALUE: '<?=$arSection['NAME']?>', parent: <?=$arSection['IBLOCK_SECTION_ID']?>});
			<?endif?>
		<?endforeach?>
	
		<?$res = CIBlockSection::GetList(array('SORT' => 'ASC'), array('ACTIVE' => 'Y', 'IBLOCK_ID' => __BASE_IBLOCK_ID));?>
		<?$res->SetURLTemplates();?>
		<?while($type = $res->GetNext()):?>
			types.push({ID: <?=$type['ID']?>, VALUE: '<?=$type['NAME']?>', parent: false, additional: {path: '<?=$type['SECTION_PAGE_URL']?>'}});
		<?endwhile?>
	
		var properties = [];	

		var regions = new CSelectBoxProperty({
			code: 'REG',
			select: '.-filter-region',
			items: regions,
			emptyItem: '<?= GetMessage('RAION_EMPTY'); ?>'
		});
		properties.push(regions);

		properties.push(new CSelectBoxProperty({
			code: 'REG_filter',
			select: '.-filter-city',
			items: cities,
			chain: regions
		}));				
		
		properties.push(new CSelectBoxProperty({
			code: 'TYPE',
			select: '.-filter-type',
			items: types,
			customGetValue: function(){
				return this._itemIndex[this.value[0]].additional.path;
			}
		}));		
		
		properties.push(new CListProperty({
			code: 'RMS',
			items: [{ID:0, VALUE:'<?= GetMessage('ROOM'); ?>'},{ID:1, VALUE:'1'},{ID:2, VALUE:'2'},{ID:3, VALUE:'3'},{ID:4, VALUE:'4+'}],
			area: '.leftFilter_items',
			customGetValue: function(){
				return this._packedValue();
			}
		}));
		properties.push(new CSlider2InputsProperty({
			code: 'PR',
			area: '.area_slider_cost',
			min: 0,
			max: <?=$maxCost?>,
			step: 10,
			triadize: true
		}));		

		new CCatalogRequester({
			props: properties,
			area: $('.indexQuickSearch'),
			responser: new CCatalogResponserDoRequestHash({
				cookiePrefix: '<?=__BASE_COOKIE_GROUP?>',
				performButton: '.formButton_Orange',
				propUseAsPath: 'TYPE'
			})
		});			
		
		CustomSelect($('.customSelect02'));
	
	})();
</script>
	
<?/*
<div class="catalog-section-list">
<ul>
<?
$CURRENT_DEPTH=$arResult["SECTION"]["DEPTH_LEVEL"]+1;
foreach($arResult["SECTIONS"] as $arSection):
	$this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], CIBlock::GetArrayByID($arSection["IBLOCK_ID"], "SECTION_EDIT"));
	$this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], CIBlock::GetArrayByID($arSection["IBLOCK_ID"], "SECTION_DELETE"), array("CONFIRM" => GetMessage('CT_BCSL_ELEMENT_DELETE_CONFIRM')));
	if($CURRENT_DEPTH<$arSection["DEPTH_LEVEL"])
		echo "<ul>";
	elseif($CURRENT_DEPTH>$arSection["DEPTH_LEVEL"])
		echo str_repeat("</ul>", $CURRENT_DEPTH - $arSection["DEPTH_LEVEL"]);
	$CURRENT_DEPTH = $arSection["DEPTH_LEVEL"];
?>
	<li id="<?=$this->GetEditAreaId($arSection['ID']);?>"><a href="<?=$arSection["SECTION_PAGE_URL"]?>"><?=$arSection["NAME"]?><?if($arParams["COUNT_ELEMENTS"]):?>&nbsp;(<?=$arSection["ELEMENT_CNT"]?>)<?endif;?></a></li>
<?endforeach?>
</ul>
</div>
*/?>

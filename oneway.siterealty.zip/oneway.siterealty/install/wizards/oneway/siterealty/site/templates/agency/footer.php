						</section>
					</td>
				</tr>
			</table>
		</div>
	</div>

	<div class="footer_fix"></div>
	<div class="footerContainer">
		<footer class="footerBlock">

			<div class="footerContacts">
						<?$APPLICATION->IncludeComponent(
							"bitrix:main.include",
							"",
							Array(
								"AREA_FILE_SHOW" => "file",
								"PATH" => SITE_DIR."include/contacts.html",
								"EDIT_TEMPLATE" => ""
							)
						);?>
			</div>

			<div class="footerCopyright">
						<?$APPLICATION->IncludeComponent(
							"bitrix:main.include",
							"",
							Array(
								"AREA_FILE_SHOW" => "file",
								"PATH" => SITE_DIR."include/copyright.html",
								"EDIT_TEMPLATE" => ""
							)
						);?>
			</div>
			
			<br class="clear_both" />
		</footer>
	</div>
	
</div>
</body>
</html>
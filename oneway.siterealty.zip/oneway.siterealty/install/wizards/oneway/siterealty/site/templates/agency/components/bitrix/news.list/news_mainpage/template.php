<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?//_print_r($arResult)?>

<?if(!empty($arResult["ITEMS"])):?>

	<?CMacro::Add('string');?>

							<section class="indexNewsBlock">
								<div class="pageTitleLine"></div>
								<header class="indexNewsHeader">
									<h2><?= GetMessage('NEWS'); ?></h2><span class="indexNewsHeader_Divider">/</span><a href="<?=str_replace('#SITE_DIR#', '', $arResult['LIST_PAGE_URL'])?>" class="indexNewsHeader_linkToSection"><?= GetMessage('NEWS_ARCHIVE'); ?></a>
									<br class="clear_both">
								</header>
								<br class="clear_both">
								<nav class="indexNewsNav">
									<ul class="indexNewsList">

<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
									
										<li class="indexNewsItem" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
											<section>
												<div class="newsItemSection_Date"><?=ToLower($arItem['DISPLAY_ACTIVE_FROM'])?> <?= GetMessage('YEAR'); ?></div>
												<header class="newsItemHeader"><a class="newsItemSection_Link" href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></header>
												<article><?=$arItem['PREVIEW_TEXT']?></article>
											</section>
										</li>

<?endforeach;?>

									</ul>
									<br class="clear_both">
								</nav>
							</section>
							<script>
								setEqualHeight($('.indexNewsItem'), 3);
							</script>

<?endif?>
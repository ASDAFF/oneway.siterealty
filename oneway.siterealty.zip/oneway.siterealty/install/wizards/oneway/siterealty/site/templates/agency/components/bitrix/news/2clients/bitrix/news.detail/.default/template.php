<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

							<div class="newsDetailBlock">
								<header class="newsDetailTitle"><h1><?=$arResult["NAME"];?></h1></header>
								
								<article>
									<?=$arResult["DETAIL_TEXT"];?>
								</article>
							</div>
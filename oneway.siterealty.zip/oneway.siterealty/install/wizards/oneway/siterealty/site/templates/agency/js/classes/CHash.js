/*
 Класс для работы с hash. v1.0 (31.01.2013)
 
 Требует:
 * jquery
 * ABaseClass.js >= v2.1
 
 Как работает. Внутри класса есть структура, отражающая текущее состояние хэша. Хэш перегоняется в структуру, со структурой идёт работа. Когда структура обновляется, *должен* (пока не реализовано) обновляться их хэш (зеркально ей)
 
 Почему сделал так? Куки могут обновляться независимо друг от друга, а переменные хэша не могут.
 
 */
function CHash(options){
	
	var self = this;
	
	/*** defaults ***/
	self.options = {
		prefix: '', // that prefix means hash group,
		varSeparator: '&'
	}
	ABaseClass.apply(self, [options]);
	
	/*** public ***/
	/* props */
	/* methods */
	self.set = function(options){
		self._currentHash[options.name] = options.value;
		self._updateHash();
		return self;
	}
	self.get = function(name){
		return typeof(self._currentHash[name]) == 'undefined' ? '' : self._currentHash[name];
	}
	self.unset = function(name){
		delete(self._currentHash[name]);
		self._updateHash();
		return self;
	}
	self.cleanUp = function(){
		self._currentHash = {};
		self._updateHash();
		document.location.hash = ''; // VERY TEMP
	}
	
	/*** private ***/
	/* props */
	self._currentHash = {};
	/* methods */
	self._updateHash = function(){
		// 'God knows how this feature will be implemented. But don`t forget about self.options.prefix
	}
	self._mirrorizeHash = function(){
		var params = document.location.hash.replace('#!', '');
		self._currentHash = {};
		if(params.length > 0){
		
			params = params.split(self.options.varSeparator);
			$.each(params, function(i, item){
			
				var val = item.split('=');
				if(typeof(val[0]) == 'string'){
					if(typeof(val[1]) == 'undefined')
						val[1] = '';
				
					val[0] = val[0].replace(self.options.prefix, '');
				
					self._currentHash[val[0]] = val[1];
				}
			});
		}
	}
    /*** init ***/
	
	self._mirrorizeHash();
	
	/*** finally ***/
	self._created = true;
	
return self;}
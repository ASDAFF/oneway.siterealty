<?
$MESS["SITEREALTY_TEMPLATE_NAME"] = "Агентство недвижимости";
$MESS["SITEREALTY_TEMPLATE_DESC"] = "Шаблон агентства недвижимости";
?>
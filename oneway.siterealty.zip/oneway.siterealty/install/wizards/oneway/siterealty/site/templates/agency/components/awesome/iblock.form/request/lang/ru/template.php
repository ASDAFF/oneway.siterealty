<?
$MESS["ERRORS_TEXT"] = "Допущены ошибки при заполнении.";
$MESS["DATA_NOT_SAVED"] = "Сохранение данных не произошло :(";
$MESS["ORDER_SUCCESS_SEND"] = "Заявка успешно отправлена!";
$MESS["YOUR_PHONE"] = "Ваш телефон";
$MESS["YOUR_EMAIL"] = "Ваш Email";
$MESS["FIELD_SELECT_SYMBOL"] = "Поля отмеченные символом";
$MESS["REQUIRED_SYMBOL"] = "*";
$MESS["REQUIRED_FIELD"] = "обязательны для заполнения";
$MESS["RUB"] = "руб.";
$MESS["SEND"] = "Отправить";
?>
<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if(empty($arResult["ITEMS"])):?>
	<p><?= GetMessage('NO_NEWS'); ?></p>
<?else:?>

	<?CMacro::Add('string');?>

							<nav class="newsBlock">
								<ul class="newsList">

<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>								
								
									<li class="newsItem" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
										<section class="newsItemSection">
											<div class="newsItemSection_Date"><?=ToLower($arItem['DISPLAY_ACTIVE_FROM'])?> <?= GetMessage('YEAR'); ?></div>
											<header class="newsItemHeader"><a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="newsItemSection_Link"><?=$arItem['NAME']?></a></header>
											<article><?=$arItem['PREVIEW_TEXT']?></article>
										</section>
									</li>

<?endforeach?>

								</ul>
							</nav>

<?if($arParams["DISPLAY_BOTTOM_PAGER"]):?>
	<br /><?=$arResult["NAV_STRING"]?>
<?endif;?>

<?endif?>
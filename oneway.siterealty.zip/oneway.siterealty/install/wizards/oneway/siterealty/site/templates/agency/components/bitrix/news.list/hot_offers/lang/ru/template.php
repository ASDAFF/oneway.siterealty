<?
$MESS["HOT_OFFERS"] = "Горячие предложения";
$MESS["NO_PHOTO"] = "Нет фото";
?>
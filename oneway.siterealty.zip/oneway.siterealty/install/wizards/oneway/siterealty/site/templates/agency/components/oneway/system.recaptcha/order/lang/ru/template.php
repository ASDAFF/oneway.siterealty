<?
$MESS["AUTO_DEFENCE_TEXT"] = "Защита от автоматических сообщений";
$MESS["REQUIRED_SYMBOL"] = "*";
$MESS["NOT_SEE_CAPTCHA"] = "Не видно надписи?";
$MESS["CLICK_CAPTCHA"] = "Нажмите";
$MESS["OR_CLICK_IMAGE"] = "или щелкните по картинке";
$MESS["ENTER_CAPTCHA_CODE"] = "Введите защитный код с этой картинки";
?>
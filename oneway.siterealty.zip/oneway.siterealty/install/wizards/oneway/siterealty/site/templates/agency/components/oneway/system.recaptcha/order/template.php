<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

									<div class="orderForm_lineTitle"><?= GetMessage("AUTO_DEFENCE_TEXT"); ?> <span class="formImportant"><?= GetMessage("REQUIRED_SYMBOL"); ?></span></div>
									<div class="orderForm_lineResult captcha_block">
										<div class="captchaRefresh"><?= GetMessage("NOT_SEE_CAPTCHA"); ?><br /><?= GetMessage("CLICK_CAPTCHA"); ?> <input class="captchaRefresh_Button -m-recaptcha-update" type="button" value="" name=""><br /><?= GetMessage("OR_CLICK_IMAGE"); ?></div>
										<div class="captchaPic"><img class="-m-recaptcha-image -m-recaptcha-update" src="/bitrix/tools/captcha.php?captcha_code=<?=$arResult["CODE"]?>" width="180" height="40" title="<?= GetMessage("ENTER_CAPTCHA_CODE"); ?>" /></div>
										<span<?=($arParams['FAILED'] ? ' class="input_error"' : '')?>><input class="-m-recaptcha-input lineResult_Input" style="width: 162px;text-transform:uppercase" type="text" value="" name="<?=$arParams['WORD_INPUT_NAME']?>"></span>
										<input class="-m-recaptcha-code" type="hidden" name="<?=$arParams['SID_INPUT_NAME']?>" value="<?=$arResult["CODE"]?>"/>
										<br class="clear_both">
									</div>
									<br class="clear_both">

<script type="text/javascript">
 window.jQuery || document.write('<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"><\/script>');
</script>
<script type="text/javascript">
	
	(function($){$.fn.recaptcha = function(options){function operations(options, dom){this.dom = dom;
	
		this.links = $('.-m-recaptcha-update', this.dom);
		this.button = $('.-m-recaptcha-button', this.dom);
		this.loader = $('.-m-recaptcha-loader', this.dom);
		this.img = $('.-m-recaptcha-image', this.dom);
		this.code = $('.-m-recaptcha-code', this.dom);
		this.word = $('.-m-recaptcha-input', this.dom);
	
		this.unlock = function()
		{
			this.button.show();
			this.loader.hide();
		}
		this.lock = function()
		{
			this.button.hide();
			this.loader.show();
		}
	
		var _this = this;
	
		this.links.click(function(){
			
			var fields = {};
			fields.AJAX_CALL = 'Y';
			
			_this.lock();
			$.ajax({
					url: '<?=$this->__component->__path?>/component.php',
					data: fields,
					type: "POST",
					dataType: "json",
					success: function(result){
				
												if(result.result)
												{
													_this.img.attr('src', '/bitrix/tools/captcha.php?captcha_code='+result.code);
													_this.code.val(result.code);
													_this.word.val('');
												}
						
												_this.unlock();
											},
					error: function(){
									  _this.unlock();
									 }
			});
			
		});
	
	}return new operations(options, this);}})( jQuery );
	
	$('.captcha_block').recaptcha();
</script>
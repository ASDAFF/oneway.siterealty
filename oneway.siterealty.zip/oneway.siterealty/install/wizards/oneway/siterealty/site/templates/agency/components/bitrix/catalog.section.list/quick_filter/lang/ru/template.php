<?
$MESS["QUICK_SEARCH"] = "Быстрый поиск объектов";
$MESS["CITY"] = "Город";
$MESS["RAION"] = "Район";
$MESS["TYPE_REALTY"] = "Тип недвижимости";
$MESS["COUNT_ROOMS"] = "Количество комнат";
$MESS["COST"] = "Стоимость";
$MESS["RUB"] = "руб.";
$MESS["SEARCH"] = "Найти";
$MESS["FROM"] = "от";
$MESS["TO"] = "до";
$MESS["ROOM"] = "комната";
$MESS["RAION_EMPTY"] = "-- любой";
?>
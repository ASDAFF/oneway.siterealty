<?
$MESS["HOT_OFFERS"] = "Горячие предложения";
$MESS["NO_PHOTO"] = "Нет фото";
$MESS["PRICE"] = "Цена:";
$MESS["RUB"] = "руб.";
?>
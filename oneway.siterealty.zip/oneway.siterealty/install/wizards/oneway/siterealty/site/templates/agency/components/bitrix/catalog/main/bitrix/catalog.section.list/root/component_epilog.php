<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if(strlen($arResult['REDIR_TO']))
	LocalRedirect($arResult['REDIR_TO']);
?>
<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?
 CMacro::Add('string');
 ?>

							<div class="newsDetailBlock">
								<div class="newsItemSection_Date"><?=ToLower($arResult["DISPLAY_ACTIVE_FROM"]);?> <?= GetMessage('YEAR'); ?></div>
								<header class="newsDetailTitle"><h1><?=$arResult["NAME"];?></h1></header>
								
								<?if(intval($arResult['DETAIL_PICTURE']['ID'])):?>
									<?=CFile::ShowImage($arResult['DETAIL_PICTURE']['ID'], 580, 9999, 'class="newsDetail_Pic" alt="'.$arResult["NAME"].'" title="'.$arResult["NAME"].'"');?>
									
									<script>
										// ������� ������������ � ��������
										$('.newsDetail_Pic').each(function() {
											if($(this).attr('align') === 'left' )
												$(this).addClass('img-right-margin');

											if($(this).attr('align') === 'right' )
												$(this).addClass('img-left-margin');
										});

										// �� ������� ������������ � ��������
										$('.newsDetail_Pic:not([align])').each(function() {
											if($(this).width() <= 400 )
											{
												$(this).attr('align', 'left');
												$(this).addClass('img-right-margin');
											}
										});
									</script>
									
								<?endif?>
								
								<article>
									<?=$arResult["DETAIL_TEXT"];?>
								</article>
							</div>
<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if(!empty($arResult)):?>

						<aside class="leftMenuContainer">
							<nav class="leftMenuNav">
								<ul class="leftMenuList">

									<?foreach($arResult as $arItem):?>
									<li class="leftMenuItem">
										<a href="<?=$arItem["LINK"]?>" class="leftMenu_<?=($arItem["SELECTED"] ? 'linkSelected' : 'Link')?>">
											<?if($arItem["SELECTED"]):?>
											<span class="leftMenu_Hover"><span class="leftMenu_hoverArrow"></span></span>
											<span class="leftMenu_Text">
											<?endif?><?=$arItem["TEXT"]?><?if($arItem["SELECTED"]):?></span>
											<?endif?>
										</a>
									</li>
									<?endforeach?>

								</ul>
							</nav>
						</aside>
						<script type="text/javascript">
							$('.leftMenuList a').first().filter('.leftMenu_Link').css({ 'border-top' : '1px dashed #c8c8c8' });
						</script>
						
<?endif?>
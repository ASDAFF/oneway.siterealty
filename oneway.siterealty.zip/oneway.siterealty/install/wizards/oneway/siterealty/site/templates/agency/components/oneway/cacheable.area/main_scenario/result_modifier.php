<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$cp = $this->__component; // ������ ����������

if (is_object($cp)){

	$arResult =& $cp->arResult;
	$arParams =& $cp->arParams;

	CModule::IncludeModule('iblock');
	
	$index = array();
	$stat = array();
	$enum = array();
	$sections = array();
	
	// ����� ���� ����
	$res = CIBlockElement::GetList(false, array('ACTIVE' => 'Y', 'IBLOCK_ID' => __DEAL_TYPES_IBLOCK_ID, 'PROPERTY_WHERE_USED' => __DT_IN_BASE), array('ID', 'NAME', 'PROPERTY_MP_NAME'));
	while($item = $res->Fetch()){
		$index['DEAL_TYPES'][$item['ID']] = array('NAME' => strlen($item['PROPERTY_MP_NAME_VALUE']) ? $item['PROPERTY_MP_NAME_VALUE'] : $item['NAME']);
		$enum[] = $item['ID'];
	}
	
	// ����� ������� �� ������� ���� ������
	foreach($enum as $id){
		$res = CIBlockElement::GetList(false, array('ACTIVE' => 'Y', 'IBLOCK_ID' => __BASE_IBLOCK_ID, 'PROPERTY_DEAL_TYPE' => $id), array('IBLOCK_SECTION_ID'));
		while($item = $res->Fetch()){
			$index['DEAL_TYPES'][$id]['SECTIONS'][] = $item['IBLOCK_SECTION_ID'];
			$sections[$item['IBLOCK_SECTION_ID']] = 1;
		}
		$index['DEAL_TYPES'][$id]['SECTIONS'] = array_unique($index['DEAL_TYPES'][$id]['SECTIONS']);
	}
	
	$ufDealTypes = array();
	$res = CIBlockSection::GetList(array('SORT' => 'ASC', 'NAME' => 'ASC'), array('ACTIVE' => 'Y', 'IBLOCK_ID' => __BASE_IBLOCK_ID, /*, 'ID' => array_keys($sections)*/), false, array('*', 'UF_DEAL_TYPE'));
	$res->SetURLTemplates();
	$sections = array();
	while($sect = $res->GetNext()){
		$sections[$sect['ID']] = $sect;
		foreach($sect['UF_DEAL_TYPE'] as $dt)
			$ufDealTypes[$dt][$sect['ID']]++;
	}
		
	$arResult['INDEX'] = $index;
	$arResult['SECTIONS'] = $sections;

	//////////////////////////////////////////////
	// ������ ����� - ������ ������
	// 1) �������� ������ �����
	$arResult['ORDER']['DEAL_TYPES'] = array();
	if(!empty($ufDealTypes)){
		$res = CIBlockElement::GetList(array(), array('ACTIVE' => 'Y', 'ID' => array_keys($ufDealTypes)), false, false, array('*', 'PROPERTY_MP_NAME'));
		while($dt = $res->Fetch())
			$arResult['ORDER']['DEAL_TYPES'][$dt['ID']] = $dt;
			
		$arResult['ORDER']['INDEX'] = $ufDealTypes;
	}
	///////////////////////////////////////////////////////////////////////
	
	$cp->SetResultCacheKeys(array('INDEX', 'SECTIONS', 'ORDER'));
}
?>
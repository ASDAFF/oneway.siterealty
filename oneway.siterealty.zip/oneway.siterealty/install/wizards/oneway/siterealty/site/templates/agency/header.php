<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?IncludeTemplateLangFile(__FILE__);?>
<title><?=$APPLICATION->ShowTitle()?> &mdash; <?= GetMessage("SITE_NAME") ?></title>
<?=$APPLICATION->ShowHead()?>
<?CMacro::AddJQuery();?>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/jquery.site_scripts.js"></script>
<!--[if lt IE 9]> 
	<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/html5shiv.js"></script>
<![endif]-->
</head>
<body>
<div class="bodyContainer">
	<?=$APPLICATION->ShowPanel()?>
	<div class="siteContainer">

		<header>
			<div class="siteContainer_headerLine">

				<a href="<?print(SITE_DIR)?>" class="headerLogo" title="<?= GetMessage("MAIN_PAGE") ?>">
					<?$APPLICATION->IncludeComponent(
							"bitrix:main.include",
							"",
							Array(
								"AREA_FILE_SHOW" => "file",
								"PATH" => SITE_DIR."include/logo.html",
								"EDIT_TEMPLATE" => ""
							)
					);?>					
				</a>
				<div class="headerSlogan">
					<h1>
						<?$APPLICATION->IncludeComponent(
							"bitrix:main.include",
							"",
							Array(
								"AREA_FILE_SHOW" => "file",
								"PATH" => SITE_DIR."include/slogan.html",
								"EDIT_TEMPLATE" => ""
							)
						);?>
					</h1>
				</div>
				<div class="headerTel">
					<span class="headerTel_Title"><?= GetMessage("CONTACT_PHONE") ?></span><br>
					<span class="headerTel_Code">
						<?$APPLICATION->IncludeComponent(
							"bitrix:main.include",
							"",
							Array(
								"AREA_FILE_SHOW" => "file",
								"PATH" => SITE_DIR."include/cphone.html",
								"EDIT_TEMPLATE" => ""
							)
						);?>
					</span>
				</div>
	
				<br class="clear_both">
			</div>
			
<?$APPLICATION->IncludeComponent("bitrix:menu", "main", Array(
	"ROOT_MENU_TYPE" => "top",
	"MENU_CACHE_TYPE" => "N",
	"MENU_CACHE_TIME" => "3600",
	"MENU_CACHE_USE_GROUPS" => "Y",
	"MENU_CACHE_GET_VARS" => "",
	"MAX_LEVEL" => "1",
	"CHILD_MENU_TYPE" => "left",
	"USE_EXT" => "N",
	"DELAY" => "N",
	"ALLOW_MULTI_SELECT" => "N",
	),
	false
);?>
			
		</header>
		<!--end HEADER-->

		<div class="siteBlock">
			<table class="mainTable">
				<tr>
					<td class="mainTable_leftSide">
					
					<?
					 CMacro::Add('bxfile');
					 $info = CMBxFile::FolderInfo();
					 ?>
					
					<?if(!CMBxFile::AtMainPage() && $info['PROPS']['show_side_panel'] != 'N'):?>
					
<?$APPLICATION->IncludeComponent("bitrix:menu", "left", Array(
	"ROOT_MENU_TYPE" => "left",
	"MENU_CACHE_TYPE" => "A",
	"MENU_CACHE_TIME" => "3600",
	"MENU_CACHE_USE_GROUPS" => "Y",
	"MENU_CACHE_GET_VARS" => "",
	"MAX_LEVEL" => "1",
	"CHILD_MENU_TYPE" => "left",
	"USE_EXT" => "N",
	"DELAY" => "N",
	"ALLOW_MULTI_SELECT" => "N",
	),
	false
);?>						
	
<?$GLOBALS['hotFilter'] = array('PROPERTY_HOT_OFFER' => "#HOT_FILTER_VALUE_ID#");?>
<?$APPLICATION->IncludeComponent("bitrix:news.list", "hot_offers", array(
	"IBLOCK_TYPE" => "#CATALOG_IBLOCK_TYPE#",
	"IBLOCK_ID" => "#BASE_IBLOCK_ID#",
	"NEWS_COUNT" => "5",
	"SORT_BY1" => "SORT",
	"SORT_ORDER1" => "ASC",
	"SORT_BY2" => "ACTIVE_FROM",
	"SORT_ORDER2" => "DESC",
	"FILTER_NAME" => "hotFilter",
	"FIELD_CODE" => array(
		0 => "ID",
		1 => "PREVIEW_PICTURE",
		2 => "",
	),
	"PROPERTY_CODE" => array(
		0 => "",
		1 => "DESCRIPTION",
		2 => "",
	),
	"CHECK_DATES" => "Y",
	"DETAIL_URL" => "",
	"AJAX_MODE" => "Y",
	"AJAX_OPTION_JUMP" => "N",
	"AJAX_OPTION_STYLE" => "Y",
	"AJAX_OPTION_HISTORY" => "N",
	"CACHE_TYPE" => "A",
	"CACHE_TIME" => "3600",
	"CACHE_FILTER" => "Y",
	"CACHE_GROUPS" => "Y",
	"PREVIEW_TRUNCATE_LEN" => "",
	"ACTIVE_DATE_FORMAT" => "d.m.Y",
	"SET_TITLE" => "N",
	"SET_STATUS_404" => "N",
	"INCLUDE_IBLOCK_INTO_CHAIN" => "N",
	"ADD_SECTIONS_CHAIN" => "N",
	"HIDE_LINK_WHEN_NO_DETAIL" => "N",
	"PARENT_SECTION" => "",
	"PARENT_SECTION_CODE" => "",
	"DISPLAY_TOP_PAGER" => "N",
	"DISPLAY_BOTTOM_PAGER" => "N",
	"PAGER_TITLE" => "�������",
	"PAGER_SHOW_ALWAYS" => "N",
	"PAGER_TEMPLATE" => "",
	"PAGER_DESC_NUMBERING" => "N",
	"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
	"PAGER_SHOW_ALL" => "N",
	"DISPLAY_DATE" => "N",
	"DISPLAY_NAME" => "N",
	"DISPLAY_PICTURE" => "N",
	"DISPLAY_PREVIEW_TEXT" => "N",
	"AJAX_OPTION_ADDITIONAL" => ""
	),
	false
);?>
	
					<?endif?>
					
					</td>
					<td class="mainTable_Content">

						<section class="mainTable_Section">
							<?if(!CMBxFile::AtMainPage()):?>
							<header class="pageTitle">
								<div class="pageTitleLine"></div>
								<?
								 CMacro::Add('bxetc');
								 ?>
								<div class="pageTitleText"><?=CMBxEtc::ShowConditionalH1Title(false)?></div>
								<br class="clear_both" />
							</header>
							<?endif?>
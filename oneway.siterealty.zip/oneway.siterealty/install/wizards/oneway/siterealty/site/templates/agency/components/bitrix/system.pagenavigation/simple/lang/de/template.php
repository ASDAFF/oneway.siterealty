<?
$MESS["nav_all"] = "Alle";
$MESS["nav_begin"] = "Erste";
$MESS["nav_end"] = "letzte";
$MESS["nav_next"] = "Nдchste";
$MESS["nav_of"] = "von";
$MESS["nav_paged"] = "Seite";
$MESS["nav_prev"] = "Vorherige";
?>
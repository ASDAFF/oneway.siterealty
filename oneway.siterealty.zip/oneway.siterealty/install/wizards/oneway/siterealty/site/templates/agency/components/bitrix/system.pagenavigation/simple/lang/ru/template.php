<?
$MESS ['nav_of'] = "из";
$MESS ['nav_begin'] = "начало";
$MESS ['nav_prev'] = "предыдущая";
$MESS ['nav_next'] = "следующая";
$MESS ['nav_end'] = "конец";
$MESS ['nav_paged'] = "по стр.";
$MESS ['nav_all'] = "все";
$MESS['pages'] = "Страницы:";
?>
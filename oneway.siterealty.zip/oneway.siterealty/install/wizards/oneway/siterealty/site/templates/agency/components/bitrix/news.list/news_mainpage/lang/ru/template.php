<?
$MESS["NEWS_ARCHIVE"] = "архив новостей";
$MESS["NEWS"] = "Новости";
$MESS["YEAR"] = "г.";
?>
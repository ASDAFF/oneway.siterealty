<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
 require('CItemsOut.php');
 ?>
 
							<section class="databaseTableBlock">
								<div class="-list-loader">������ ��������������, ���������...</div>
								<div class="-list-cs-nothing-found">� ���������, ������ ����������� �� ������� <span>:(</span></div>
								<table class="databaseTable">
									<thead>
										<tr>

											<th style="width: 220px">
												<div class="databaseTable_thBlock databaseTable_cornerFirst">
													<div class="vert_align"><a class="dT_tB_Link">����� � �����<img src="<?=SITE_TEMPLATE_PATH?>/img/arrow_04_up.png" width="7" height="4" alt=""></a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock">
													<div class="vert_align"><a class="dT_tB_Link">�����<br>������</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock" style="text-align: right;">
													<div class="vert_align"><a class="dT_tB_Link">����</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock">
													<div class="vert_align">�������, �<sup>2</sup><br><a class="dT_tB_Link">���</a> / <a class="dT_tB_Link">���</a> / <a class="dT_tB_Link">���</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock" style="text-align: right;">
													<div class="vert_align">����, ���.<br><a class="dT_tB_Link">�����</a></div><div class="vert_align_helper"></div>
												</div>
											</th>

											<th>
												<div class="databaseTable_thBlock databaseTable_cornerLast" style="text-align: right;">
													<div class="vert_align">����, ���.<br><a class="dT_tB_Link">�� �<sup>2</sup></a></div><div class="vert_align_helper"></div>
												</div>
											</th>

										</tr>
									</thead>
									<tbody class="-list-items">

										<tr><td class="offer_links">
										<?foreach($arResult["ITEMS"] as $cell=>$arElement):?>
											<a href="<?=$arElement['DETAIL_PAGE_URL']?>"><?=$arElement['NAME']?></a><br />
										<?endforeach?>
										<?=$arResult["NAV_STRING"]?>
										</td></tr>
												
										<script type="text/html">
										<tr>
											<td>
												<div class="databaseTable_tdRegion">%REG%</div>
												<div class="databaseTable_tdInfoBlock">
													<a href="%URL%" class="databaseTable_tdTitle">%ADDR%</a>
													<a href="%URL%?show=pics" class="dT_dT_Ico -item-pics"><img src="<?=SITE_TEMPLATE_PATH?>/img/ico_photocamera.png" width="16" height="13" alt="���������� ����������" title="���������� ����������"></a>
													<a href="%URL%?show=video" class="dT_dT_Ico -item-video"><img src="<?=SITE_TEMPLATE_PATH?>/img/ico_video.png" width="16" height="16" alt="���������� �����" title="���������� �����"></a>
												</div>
											</td>
											<td>%RMS%</td>
											<td style="text-align: right;">%FL% / %NOS%</td>
											<td>%SQ_C% / %SQ_L% / %SQ_K%</td>
											<td style="text-align: right;">%PR%</td>
											<td style="text-align: right;">%PR_M%</td>
										</tr>
										</script>

									</tbody>
								</table>
							</section>

							<?/*
							<section class="pageNaviBlock">
								<header class="pageNaviTitle">��������:</header>
								<nav class="pageNavi_navBlock">
									<a href="#" class="pageNavi_linkPrev">&laquo;&nbsp;����������</a>
									<ul class="pageNavi_numbersList">

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">1<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

										<li class="pageNavi_numbersItem">
											<span class="pageNavi_Selected">2</span>
										</li>

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">3<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

										<li class="pageNavi_numbersItem">
											<a href="#" class="pageNavi_Number">4<span class="pageNavi_Number_IE8Fix"></span></a>
										</li>

									</ul>
									<a href="#" class="pageNavi_linkNext">���������&nbsp;&raquo;</a>
									<br class="clear_both">
								</nav>
							</section>
							*/?>

						</section>

	<?
	 //_print_r($arResult['ITEMS']);
	
	 $regions = array();
	 $series = array();
	 $types = array();
	 $maxRooms = 0;
	 $maxFloor = 0;
	 $maxSquare = 0;
	 $maxCost = 0;
	 foreach($arResult['ITEMS'] as $item){
		// �������
		if(intval($item['PROPERTIES']['REGION']['VALUE']))
			$regions[] = $item['PROPERTIES']['REGION']['VALUE'];
		
		//����� ����
		if(intval($item['PROPERTIES']['SERIES']['VALUE']))
			$series[] = $item['PROPERTIES']['SERIES']['VALUE'];
		
		//��� ����
		if(intval($item['PROPERTIES']['TYPE']['VALUE']))
			$types[] = $item['PROPERTIES']['TYPE']['VALUE'];
		
		//���������� ������
		if($maxRooms < $item['PROPERTIES']['ROOMS']['VALUE'])
			$maxRooms = $item['PROPERTIES']['ROOMS']['VALUE'];

		//����
		if($maxFloor < $item['PROPERTIES']['FLOOR']['VALUE'] && $item['PROPERTIES']['FLOOR']['VALUE'] != __CItemsOut::ATTIC_FLOOR_INT)
			$maxFloor = $item['PROPERTIES']['FLOOR']['VALUE'];
			
		//���������
		if($maxCost < $item['PROPERTIES']['PRICE']['VALUE'])
			$maxCost = $item['PROPERTIES']['PRICE']['VALUE'];
			
		//����� �������
		if($maxSquare < $item['PROPERTIES']['SQUARE_TOTAL']['VALUE'])
			$maxSquare = $item['PROPERTIES']['SQUARE_TOTAL']['VALUE'];
	 }
	 $maxSquare = ceil($maxSquare);
	 
	 $regions = array_unique($regions);
	 $series = array_unique($series);
	 $types = array_unique($types);
	 
	 // ������ ��� ������, � ����� ������� �� ��� ��, � ������� ������ ���
	 $res = CIBlockSection::GetList(array('left_margin' => 'asc', 'sort' => 'asc'), array('IBLOCK_ID' => __CItemsOut::REGION_IBLOCK_ID, 'ACTIVE' => 'Y'), false, array('ID', 'NAME', 'IBLOCK_SECTION_ID', 'DEPTH_LEVEL'));
	 $regionsActual = array();
	 $regionInfo = array();
	 while($item = $res->Fetch()){
		$regionInfo[$item['ID']] = $item;
		
		if(in_array($item['ID'], $regions)){
			$regionsActual[] = $item['ID'];
			$regionsActual[] = $item['IBLOCK_SECTION_ID'];
		}
	 }
	 $regionsActual = array_unique($regionsActual);
	 
	 foreach($regionInfo as $k => $reg)
		if(!in_array($k, $regionsActual))
			unset($regionInfo[$k]);
	 ?>
						
						<aside class="leftFilterBlock">
							<header class="leftFilterHeader">����� �� ����������<div class="leftFilterHeader_Arrow"></div></header>
							<form class="leftFilterForm" action="page.php" method="post">

								<div class="customSelectBlock">
									<div class="customSelect"><?=$arResult['NAME']?><div class="customSelectBlock_Arrow"></div></div>
									<!--sublvl-->
									<div class="customSelectBlock_Sublvl">
									
										<?
										 $res = CIBlockSection::GetList(array('sort' => 'asc'), array('IBLOCK_ID' => $arParams['IBLOCK_ID'], 'ACTIVE' => 'Y'), false, array('ID', 'NAME', 'SECTION_PAGE_URL'));
										 $res->SetURLTemplates();
										 ?>
										<?while($sect = $res->GetNext()):?>
											<a class="cSB_sublvlLink<?=($sect['ID'] == $arResult['ID']? ' cSB_sublvlLink_Selected' : '')?>" href="<?=$sect['SECTION_PAGE_URL']?>"><?=$sect['NAME']?></a>
										<?endwhile?>
									</div>
									<!--sublvl-->
								</div>

								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">�����</div>
									<br class="clear_both">
									<div class="customSelect03_Block">
										<select class="customSelect03 -city-select">
											<?foreach($regionInfo as $reg):?>
												<?if($reg['DEPTH_LEVEL'] == 1):?>
												<option value="<?=$reg['ID']?>"><?=$reg['NAME']?></option>
												<?endif?>
											<?endforeach?>
										</select>
										<div class="customSelect02_arrow"></div>
									</div>
								</div>

								<div class="orderForm_lineDivider"></div>

								<div class="leftFilterForm_Line area_region">
									<div class="leftFilterForm_lineTitle">�����</div>
									<div class="leftFilterForm_addButton -droplist-open-popup -droplist-smth-selected" title="��������"></div>
									<br class="clear_both">
									<a class="leftFilterForm_Param -droplist-open-popup -droplist-noting-selected">�������� ������ ������</a>
									<span class="-droplist-selected-items">
										<script type="text/html">
											<div class="leftFilterForm_selectedParam">%VALUE%<div class="lFF_sP_Close -droplist-remove-item" title="�������"></div></div>
										</script>
									</span>
									<br class="clear_both">
									<!--sublvl-->
									<div class="leftFilterForm_Sublvl -droplist-popup">
										<div class="leftFilterForm_sublvlClose -droplist-close-popup" title="�������"><div class="lFF_sC_Ico"></div></div>
										
										<div class="-droplist-available-items">
											<script type="text/html">
												<label class="lFF_S_item"><input type="checkbox" value="%ID%" name="" />%VALUE%</label><br class="clear_both">
											</script>
										</div>
										
										<div style="float: right; position: relative;">
											<input class="formButton_Orange -droplist-select" style="width: 80px;" type="submit" value="�������" name="">
										</div>
										<br class="clear_both">
									</div>
									<!--END sublvl-->
								</div>

								<div class="orderForm_lineDivider"></div>
								
								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">���������� ������</div>
									<br class="clear_both">

									<div class="leftFilter_items">
									<script type="text/html">
										<div class="leftFilter_roomsCount" class_selected="lF_rC_Selected">%VALUE%</div>
									</script>
									</div>
									
									<br class="clear_both">
								</div>

								<div class="orderForm_lineDivider"></div>
								
								<?if($maxCost > 0):?>
								<div class="leftFilterForm_Line area_slider_cost">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">���������, ���.</div>
									<br class="clear_both">
									��<input type="text" id="cost-min" class="-slider-range-from range-slider">��<input type="text" id="cost-max" class="-slider-range-to range-slider">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=__CItemsOut::PriceValue($maxCost)?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<?if($maxFloor > 0):?>
								<div class="leftFilterForm_Line area_slider_floor">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">����</div>
									<br class="clear_both">
									��<input type="text" id="floor-min" class="-slider-range-from range-slider">��<input type="text" id="floor-max" class="-slider-range-to range-slider">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=$maxFloor?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<?if($maxSquare > 0):?>
								<div class="leftFilterForm_Line area_slider_square">
									<div class="leftFilterForm_lineTitle" style="margin: 0 0 8px 0;">����� �������, �<sup>2</sup></div>
									<br class="clear_both">
									��<input type="text" id="area-min" class="range-slider -slider-range-from">��<input type="text" id="area-max" class="range-slider -slider-range-to">
									<br class="clear_both">
									<div class="-slider-area" style="width: 217px;"></div>
									<img src="<?=SITE_TEMPLATE_PATH?>/img/slider_rulers/ruler_neutral.png" width="217" height="20" alt="">
									<span class="ruler_right_border"><?=$maxSquare?></span>
									<span class="ruler_left_border">0</span>
								</div>
								<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<?/*
								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">����� ����</div>
									<div class="leftFilterForm_addButton" title="��������"></div>
									<br class="clear_both">
									<div class="leftFilterForm_selectedParam">93-�<div class="lFF_sP_Close" title="�������"></div></div>
									<div class="leftFilterForm_selectedParam">95-�<div class="lFF_sP_Close" title="�������"></div></div>
									<div class="leftFilterForm_selectedParam">��������<div class="lFF_sP_Close" title="�������"></div></div>
									<br class="clear_both">
								</div>

								<div class="orderForm_lineDivider"></div>

								<div class="leftFilterForm_Line">
									<div class="leftFilterForm_lineTitle">��� ����</div>
									<br class="clear_both">
									<a class="leftFilterForm_Param">�������� ������ ���</a>
									<br class="clear_both">
								</div>
								*/?>
								
								<div class="orderForm_lineDivider"></div>

								<div class="leftFilterForm_Line">
									<a class="leftFilterForm_Reset">�������� ���������</a>
									<input class="formButton_Orange" style="float: right; width: 70px;" type="submit" value="�����" name="" onClick="return false" />
									<br class="clear_both">
								</div>

							</form>
						</aside>					

<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/ABaseClass.js?1.1"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/classes/CCookie.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/jquery-ui-slider.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/libs/underscore.js"></script>
<script type="text/javascript" src="<?=$templateFolder?>/js/list.model.js?<?=rand(0,999999)?>"></script>
<script type="text/javascript">

	$(".databaseTable").stickyTableHeaders(); <?// ����� ������� ������ ������ �������� ?>
					
	(function(){
		
		new CSimpleDrop({
			block: '.customSelectBlock',
			handle: '.customSelect',
			drop: '.customSelectBlock_Sublvl'
		});
		
		CustomSelect($('.customSelect03'));

		var properties = [];
		
		<?//����� - �����?>
		var items = [];
		
		<?foreach($regionInfo as $reg):?>
			<?if($reg['DEPTH_LEVEL'] == 2):?>
			items.push({ID: <?=$reg['ID']?>, VALUE: '<?=$reg['NAME']?>', parent: <?=$reg['IBLOCK_SECTION_ID']?>}); // value => ID, name => VALUE
			<?endif?>
		<?endforeach?>
		
		var regionSelector = new CDropListProperty({
			code: 'REG',
			area: '.area_region',
			items: items,
			//dontAffectReset: true <?//����� �������� "�����" ������� reset, ��� ���� ������� �������� "�����"?>,
			initialFilter: $('.-city-select').val()
		});
		properties.push(regionSelector);
		$('.-city-select').change(function(){
			regionSelector.setFilter($(this).val());
		});
		
		<?//����� ������?>
		properties.push(new CListProperty({
			code: 'RMS',
			items: [{ID:0, VALUE:'�������'},{ID:1, VALUE:'1'},{ID:2, VALUE:'2'},{ID:3, VALUE:'3'},{ID:4, VALUE:'4+'}],
			area: '.leftFilter_items',
			customMatch: function(val, self){				
				if($.inArray(val, self.value) >= 0)
					return true;
				if($.inArray(4, self.value) >= 0 && val > 4)
					return true;
				return false;
			}
		}));
		
		<?//���������?>
		<?if($maxCost > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'PR',
				area: '.area_slider_cost',
				min: 0,
				max: <?=$maxCost?>,
				step: 10
			}));
		<?endif?>
		<?//����?>
		<?if($maxFloor > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'FL',
				area: '.area_slider_floor',
				min: 0,
				max: <?=$maxFloor?>,
				step: 1
			}));
		<?endif?>
		<?//����� �������?>
		<?if($maxSquare > 0):?>
			properties.push(new CSlider2InputsProperty({
				code: 'SQ',
				area: '.area_slider_square',
				min: 0,
				max: <?=$maxSquare?>,
				step: 1
			}));
		<?endif?>
		
		var items = [];
		<?foreach($arResult['ITEMS'] as $good):?>
			items.push({
				id: <?=$good['ID']?>,
				displayProps: {
								REG: '<?=$good['NAME']?>',
								ADDR: '<?=$good['PROPERTIES']['ADDRESS']['VALUE']?>',
								URL: '<?=$good['DETAIL_PAGE_URL']?>',
								NO_PIC: <?=(empty($good['PROPERTIES']['PHOTOS']['VALUE']) ? 'true' : 'false')?>,
								NO_VID: <?=(empty($good['PROPERTIES']['VIDEO']['VALUE']) ? 'true' : 'false')?>,
								RMS: '<?=__CItemsOut::RoomsValue($good['PROPERTIES']['ROOMS']['VALUE'])?>',
								FL: '<?=__CItemsOut::FloorValue($good['PROPERTIES']['FLOOR']['VALUE'])?>',
								NOS: '<?=__CItemsOut::EmptyValue($good['PROPERTIES']['NOS']['VALUE'])?>',
								SQ_C: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_TOTAL']['VALUE'])?>',
								SQ_L: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_LIVING']['VALUE'])?>',
								SQ_K: '<?=__CItemsOut::FloatValue($good['PROPERTIES']['SQUARE_KITCHEN']['VALUE'])?>',
								PR: '<?=__CItemsOut::PriceValue($good['PROPERTIES']['PRICE']['VALUE'])?>',
								PR_M: '<?=__CItemsOut::PriceValue($good['PROPERTIES']['PRICE_M2']['VALUE'])?>'
							},
				filterProps: {
								PR: <?=intval($good['PROPERTIES']['PRICE']['VALUE'])?>,
								FL: <?=intval($good['PROPERTIES']['FLOOR']['VALUE'])?>,
								SQ: <?=intval($good['PROPERTIES']['SQUARE_TOTAL']['VALUE'])?>,
								RMS: <?=intval($good['PROPERTIES']['ROOMS']['VALUE'])?>,
								REG: <?=intval($good['PROPERTIES']['REGION']['VALUE'])?>
							}
			});
			<?$cities[] = $shop['IBLOCK_SECTION_ID'];?>	
		<?endforeach?>
					
		new CCatalogRequester({
			props: properties,
			area: $('.databaseTableBlock'),
			debounceTimeout: 200,
			resetButton: $('.leftFilterForm_Reset'),
			
			responser: new CCatalogResponserClientSide({
				items: items,
				onItemPostproc: function(domItem, item, index, self){

					if(!(index % 2))
						domItem.addClass('databaseTable_thColor');
						
					if(item.displayProps.NO_PIC)
						domItem.find('.-item-pics').remove();
					if(item.displayProps.NO_VID)
						domItem.find('.-item-video').remove();
						
					return domItem;
				},
				onBeforeRefresh: function(self){
				},
				onAfterRefresh: function(self, itemsShown){
				}
			})
		});							
		
	})();
		
	$('.leftFilterBlock').appendTo('.mainTable_leftSide');
</script>					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
<? /*

<div class="catalog-section">
<?if($arParams["DISPLAY_TOP_PAGER"]):?>
	<?=$arResult["NAV_STRING"]?><br />
<?endif;?>
<table cellpadding="0" cellspacing="0" border="0">
		<?foreach($arResult["ITEMS"] as $cell=>$arElement):?>
		<?
		$this->AddEditAction($arElement['ID'], $arElement['EDIT_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_EDIT"));
		$this->AddDeleteAction($arElement['ID'], $arElement['DELETE_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BCS_ELEMENT_DELETE_CONFIRM')));
		?>
		<?if($cell%$arParams["LINE_ELEMENT_COUNT"] == 0):?>
		<tr>
		<?endif;?>

		<td valign="top" width="<?=round(100/$arParams["LINE_ELEMENT_COUNT"])?>%" id="<?=$this->GetEditAreaId($arElement['ID']);?>">

			<table cellpadding="0" cellspacing="2" border="0">
				<tr>
					<?if(is_array($arElement["PREVIEW_PICTURE"])):?>
						<td valign="top">
						<a href="<?=$arElement["DETAIL_PAGE_URL"]?>"><img border="0" src="<?=$arElement["PREVIEW_PICTURE"]["SRC"]?>" width="<?=$arElement["PREVIEW_PICTURE"]["WIDTH"]?>" height="<?=$arElement["PREVIEW_PICTURE"]["HEIGHT"]?>" alt="<?=$arElement["NAME"]?>" title="<?=$arElement["NAME"]?>" /></a><br />
						</td>
					<?elseif(is_array($arElement["DETAIL_PICTURE"])):?>
						<td valign="top">
						<a href="<?=$arElement["DETAIL_PAGE_URL"]?>"><img border="0" src="<?=$arElement["DETAIL_PICTURE"]["SRC"]?>" width="<?=$arElement["DETAIL_PICTURE"]["WIDTH"]?>" height="<?=$arElement["DETAIL_PICTURE"]["HEIGHT"]?>" alt="<?=$arElement["NAME"]?>" title="<?=$arElement["NAME"]?>" /></a><br />
						</td>
					<?endif?>
					<td valign="top"><a href="<?=$arElement["DETAIL_PAGE_URL"]?>"><?=$arElement["NAME"]?></a><br />
						<?foreach($arElement["DISPLAY_PROPERTIES"] as $pid=>$arProperty):?>
							<?=$arProperty["NAME"]?>:&nbsp;<?
								if(is_array($arProperty["DISPLAY_VALUE"]))
									echo implode("&nbsp;/&nbsp;", $arProperty["DISPLAY_VALUE"]);
								else
									echo $arProperty["DISPLAY_VALUE"];?><br />
						<?endforeach?>
						<br />
						<?=$arElement["PREVIEW_TEXT"]?>
					</td>
				</tr>
			</table>
			<?if(is_array($arElement["OFFERS"]) && !empty($arElement["OFFERS"])):?>
				<?foreach($arElement["OFFERS"] as $arOffer):?>
					<?foreach($arParams["OFFERS_FIELD_CODE"] as $field_code):?>
						<small><?echo GetMessage("IBLOCK_FIELD_".$field_code)?>:&nbsp;<?
								echo $arOffer[$field_code];?></small><br />
					<?endforeach;?>
					<?foreach($arOffer["DISPLAY_PROPERTIES"] as $pid=>$arProperty):?>
						<small><?=$arProperty["NAME"]?>:&nbsp;<?
							if(is_array($arProperty["DISPLAY_VALUE"]))
								echo implode("&nbsp;/&nbsp;", $arProperty["DISPLAY_VALUE"]);
							else
								echo $arProperty["DISPLAY_VALUE"];?></small><br />
					<?endforeach?>
					<?foreach($arOffer["PRICES"] as $code=>$arPrice):?>
						<?if($arPrice["CAN_ACCESS"]):?>
							<p><?=$arResult["PRICES"][$code]["TITLE"];?>:&nbsp;&nbsp;
							<?if($arPrice["DISCOUNT_VALUE"] < $arPrice["VALUE"]):?>
								<s><?=$arPrice["PRINT_VALUE"]?></s> <span class="catalog-price"><?=$arPrice["PRINT_DISCOUNT_VALUE"]?></span>
							<?else:?>
								<span class="catalog-price"><?=$arPrice["PRINT_VALUE"]?></span>
							<?endif?>
							</p>
						<?endif;?>
					<?endforeach;?>
					<p>
					<?if($arParams["DISPLAY_COMPARE"]):?>
						<noindex>
						<a href="<?echo $arOffer["COMPARE_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_COMPARE")?></a>&nbsp;
						</noindex>
					<?endif?>
					<?if($arOffer["CAN_BUY"]):?>
						<?if($arParams["USE_PRODUCT_QUANTITY"]):?>
							<form action="<?=POST_FORM_ACTION_URI?>" method="post" enctype="multipart/form-data">
							<table border="0" cellspacing="0" cellpadding="2">
								<tr valign="top">
									<td><?echo GetMessage("CT_BCS_QUANTITY")?>:</td>
									<td>
										<input type="text" name="<?echo $arParams["PRODUCT_QUANTITY_VARIABLE"]?>" value="1" size="5">
									</td>
								</tr>
							</table>
							<input type="hidden" name="<?echo $arParams["ACTION_VARIABLE"]?>" value="BUY">
							<input type="hidden" name="<?echo $arParams["PRODUCT_ID_VARIABLE"]?>" value="<?echo $arOffer["ID"]?>">
							<input type="submit" name="<?echo $arParams["ACTION_VARIABLE"]."BUY"?>" value="<?echo GetMessage("CATALOG_BUY")?>">
							<input type="submit" name="<?echo $arParams["ACTION_VARIABLE"]."ADD2BASKET"?>" value="<?echo GetMessage("CATALOG_ADD")?>">
							</form>
						<?else:?>
							<noindex>
							<a href="<?echo $arOffer["BUY_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_BUY")?></a>
							&nbsp;<a href="<?echo $arOffer["ADD_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_ADD")?></a>
							</noindex>
						<?endif;?>
					<?elseif(count($arResult["PRICES"]) > 0):?>
						<?=GetMessage("CATALOG_NOT_AVAILABLE")?>
					<?endif?>
					</p>
				<?endforeach;?>
			<?else:?>
				<?foreach($arElement["PRICES"] as $code=>$arPrice):?>
					<?if($arPrice["CAN_ACCESS"]):?>
						<p><?=$arResult["PRICES"][$code]["TITLE"];?>:&nbsp;&nbsp;
						<?if($arPrice["DISCOUNT_VALUE"] < $arPrice["VALUE"]):?>
							<s><?=$arPrice["PRINT_VALUE"]?></s> <span class="catalog-price"><?=$arPrice["PRINT_DISCOUNT_VALUE"]?></span>
						<?else:?><span class="catalog-price"><?=$arPrice["PRINT_VALUE"]?></span><?endif;?>
						</p>
					<?endif;?>
				<?endforeach;?>
				<?if(is_array($arElement["PRICE_MATRIX"])):?>
					<table cellpadding="0" cellspacing="0" border="0" width="100%" class="data-table">
					<thead>
					<tr>
						<?if(count($arElement["PRICE_MATRIX"]["ROWS"]) >= 1 && ($arElement["PRICE_MATRIX"]["ROWS"][0]["QUANTITY_FROM"] > 0 || $arElement["PRICE_MATRIX"]["ROWS"][0]["QUANTITY_TO"] > 0)):?>
							<td valign="top" nowrap><?= GetMessage("CATALOG_QUANTITY") ?></td>
						<?endif?>
						<?foreach($arElement["PRICE_MATRIX"]["COLS"] as $typeID => $arType):?>
							<td valign="top" nowrap><?= $arType["NAME_LANG"] ?></td>
						<?endforeach?>
					</tr>
					</thead>
					<?foreach ($arElement["PRICE_MATRIX"]["ROWS"] as $ind => $arQuantity):?>
					<tr>
						<?if(count($arElement["PRICE_MATRIX"]["ROWS"]) > 1 || count($arElement["PRICE_MATRIX"]["ROWS"]) == 1 && ($arElement["PRICE_MATRIX"]["ROWS"][0]["QUANTITY_FROM"] > 0 || $arElement["PRICE_MATRIX"]["ROWS"][0]["QUANTITY_TO"] > 0)):?>
							<th nowrap><?
								if (IntVal($arQuantity["QUANTITY_FROM"]) > 0 && IntVal($arQuantity["QUANTITY_TO"]) > 0)
									echo str_replace("#FROM#", $arQuantity["QUANTITY_FROM"], str_replace("#TO#", $arQuantity["QUANTITY_TO"], GetMessage("CATALOG_QUANTITY_FROM_TO")));
								elseif (IntVal($arQuantity["QUANTITY_FROM"]) > 0)
									echo str_replace("#FROM#", $arQuantity["QUANTITY_FROM"], GetMessage("CATALOG_QUANTITY_FROM"));
								elseif (IntVal($arQuantity["QUANTITY_TO"]) > 0)
									echo str_replace("#TO#", $arQuantity["QUANTITY_TO"], GetMessage("CATALOG_QUANTITY_TO"));
							?></th>
						<?endif?>
						<?foreach($arElement["PRICE_MATRIX"]["COLS"] as $typeID => $arType):?>
							<td><?
								if($arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["DISCOUNT_PRICE"] < $arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["PRICE"]):?>
									<s><?=FormatCurrency($arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["PRICE"], $arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["CURRENCY"])?></s><span class="catalog-price"><?=FormatCurrency($arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["DISCOUNT_PRICE"], $arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["CURRENCY"]);?></span>
								<?else:?>
									<span class="catalog-price"><?=FormatCurrency($arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["PRICE"], $arElement["PRICE_MATRIX"]["MATRIX"][$typeID][$ind]["CURRENCY"]);?></span>
								<?endif?>&nbsp;
							</td>
						<?endforeach?>
					</tr>
					<?endforeach?>
					</table><br />
				<?endif?>
				<?if($arParams["DISPLAY_COMPARE"]):?>
					<noindex>
					<a href="<?echo $arElement["COMPARE_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_COMPARE")?></a>&nbsp;
					</noindex>
				<?endif?>
				<?if($arElement["CAN_BUY"]):?>
					<?if($arParams["USE_PRODUCT_QUANTITY"] || count($arElement["PRODUCT_PROPERTIES"])):?>
						<form action="<?=POST_FORM_ACTION_URI?>" method="post" enctype="multipart/form-data">
						<table border="0" cellspacing="0" cellpadding="2">
						<?if($arParams["USE_PRODUCT_QUANTITY"]):?>
							<tr valign="top">
								<td><?echo GetMessage("CT_BCS_QUANTITY")?>:</td>
								<td>
									<input type="text" name="<?echo $arParams["PRODUCT_QUANTITY_VARIABLE"]?>" value="1" size="5">
								</td>
							</tr>
						<?endif;?>
						<?foreach($arElement["PRODUCT_PROPERTIES"] as $pid => $product_property):?>
							<tr valign="top">
								<td><?echo $arElement["PROPERTIES"][$pid]["NAME"]?>:</td>
								<td>
								<?if(
									$arElement["PROPERTIES"][$pid]["PROPERTY_TYPE"] == "L"
									&& $arElement["PROPERTIES"][$pid]["LIST_TYPE"] == "C"
								):?>
									<?foreach($product_property["VALUES"] as $k => $v):?>
										<label><input type="radio" name="<?echo $arParams["PRODUCT_PROPS_VARIABLE"]?>[<?echo $pid?>]" value="<?echo $k?>" <?if($k == $product_property["SELECTED"]) echo '"checked"'?>><?echo $v?></label><br>
									<?endforeach;?>
								<?else:?>
									<select name="<?echo $arParams["PRODUCT_PROPS_VARIABLE"]?>[<?echo $pid?>]">
										<?foreach($product_property["VALUES"] as $k => $v):?>
											<option value="<?echo $k?>" <?if($k == $product_property["SELECTED"]) echo '"selected"'?>><?echo $v?></option>
										<?endforeach;?>
									</select>
								<?endif;?>
								</td>
							</tr>
						<?endforeach;?>
						</table>
						<input type="hidden" name="<?echo $arParams["ACTION_VARIABLE"]?>" value="BUY">
						<input type="hidden" name="<?echo $arParams["PRODUCT_ID_VARIABLE"]?>" value="<?echo $arElement["ID"]?>">
						<input type="submit" name="<?echo $arParams["ACTION_VARIABLE"]."BUY"?>" value="<?echo GetMessage("CATALOG_BUY")?>">
						<input type="submit" name="<?echo $arParams["ACTION_VARIABLE"]."ADD2BASKET"?>" value="<?echo GetMessage("CATALOG_ADD")?>">
						</form>
					<?else:?>
						<noindex>
						<a href="<?echo $arElement["BUY_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_BUY")?></a>&nbsp;<a href="<?echo $arElement["ADD_URL"]?>" rel="nofollow"><?echo GetMessage("CATALOG_ADD")?></a>
						</noindex>
					<?endif;?>
				<?elseif((count($arResult["PRICES"]) > 0) || is_array($arElement["PRICE_MATRIX"])):?>
					<?=GetMessage("CATALOG_NOT_AVAILABLE")?>
				<?endif?>
			<?endif?>
			&nbsp;
		</td>

		<?$cell++;
		if($cell%$arParams["LINE_ELEMENT_COUNT"] == 0):?>
			</tr>
		<?endif?>

		<?endforeach; // foreach($arResult["ITEMS"] as $arElement):?>

		<?if($cell%$arParams["LINE_ELEMENT_COUNT"] != 0):?>
			<?while(($cell++)%$arParams["LINE_ELEMENT_COUNT"] != 0):?>
				<td>&nbsp;</td>
			<?endwhile;?>
			</tr>
		<?endif?>

</table>
<?if($arParams["DISPLAY_BOTTOM_PAGER"]):?>
	<br /><?=$arResult["NAV_STRING"]?>
<?endif;?>
</div>
*/?>
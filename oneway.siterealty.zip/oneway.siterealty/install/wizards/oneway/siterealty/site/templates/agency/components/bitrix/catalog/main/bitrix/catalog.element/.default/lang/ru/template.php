<?
$MESS["LOCATION"] = "Расположение";
$MESS["RAION"] = " район";
$MESS["COK"] = "Цокольный";
$MESS["MANSARD"] = "Мансардный";
$MESS["FLOOR"] = "этаж";
$MESS["FLOOR_DOM"] = "-этажного дома";
$MESS["FLOOR_DOM2"] = "-этажный дом";
$MESS["DOM"] = "дом";
$MESS["SERIA"] = "серия";
$MESS["EXT_INFO"] = "Дополнительная информация";
$MESS["TOTAL_PRICE"] = "Цена общая";
$MESS["RUB"] = "руб.";
$MESS["SQUARE"] = "Площадь";
$MESS["TOTAL_SQUARE"] = "общая";
$MESS["M"] = "м";
$MESS["LIVE_SQUARE"] = "жилая";
$MESS["KITCHEN_SQUARE"] = "кухня";
$MESS["OBJECT_MAP"] = "Объект на карте";
$MESS["PHOTOS"] = "Фотографий:";
$MESS["PLAN"] = "Планировки";
$MESS["CONTACT_INFO"] = "Контактная информация";
$MESS["PHONE"] = "Тел.:";
$MESS["EMAIL"] = "E-mail:";
$MESS["SEN_ORDER"] = "Оставить заявку";
$MESS["PRICE_MSQUARE"] = "Цена за м<sup>2</sup>";
?>
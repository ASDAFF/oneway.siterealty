<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
 // ������� ����
 if(isset($arResult['FIELDS']['DETAIL_TEXT'])){
	$addit = $arResult['FIELDS']['DETAIL_TEXT'];
	unset($arResult['FIELDS']['DETAIL_TEXT']);
	$arResult['FIELDS']['DETAIL_TEXT'] = $addit;
 }
 ?> 
	 
							<form class="orderForm" action="?" method="post">

								<input type="hidden" name="object" value="<?=$GLOBALS['__OBJECT']?>" />
								
								<?if($arResult['RESULT']['FAIL']):?>
									<?if(!empty($arResult['ERROR_SUMMARY'])):?>
										<div class="error_message"><?= GetMessage("ERRORS_TEXT"); ?></div>
										<ul class="error_list">
											<?foreach($arResult['ERROR_SUMMARY'] as $error):?>
												<li><?=$error?></li>
											<?endforeach?>
										</ul>
									<?endif?>
									<?if(!empty($arResult['DB_ERROR_SUMMARY'])):?>
										<div class="error_message"><?= GetMessage("DATA_NOT_SAVED"); ?></div>
									<?endif?>
								<?elseif($arResult['RESULT']['SUCCESS']):?>
									<div class="success_message"><?= GetMessage("ORDER_SUCCESS_SEND"); ?></div>
								<?endif?>

								<div class="orderForm_lineDivider"></div>

								<?$i=0;?>
								<?foreach($arResult['FIELDS'] as $code => $prop):?>
								
									<?if($code == 'PROPERTY_OBJECT'):?>
										<input type="hidden" name="<?=$prop['INPUT_NAME']?>" value="<?=$GLOBALS['__OBJECT']?>" />
										<?continue;?>
									<?endif?>
								
									<?
									 if($code == 'PROPERTY_PHONE')
										$prop['NAME'] = GetMessage("YOUR_PHONE");
									 if($code == 'PROPERTY_EMAIL')
										$prop['NAME'] = GetMessage("YOUR_EMAIL");
									 ?>
								
									<?if($code == 'PROPERTY_PRICE') continue;?>
								
									<div class="orderForm_Line"<?=(!($i && $i%2) ? ' style="background: #eef5fb;"' : '')?>>
										<div class="orderForm_lineTitle"><?=$prop['NAME']?><?if($prop['REQUIRED']):?> <span class="formImportant"><?= GetMessage("REQUIRED_SYMBOL"); ?></span><?endif?></div>
										
										<?if($code == 'PROPERTY_ROOMS'):?>
										
											<span<?=($prop['ERROR'] ? ' class="input_error"' : '')?>><input class="lineResult_Input only_numbers" style="margin: 0 0 0 10px; width: 20px;" type="text" value="<?=$prop['VALUE']?>" name="<?=$prop['INPUT_NAME']?>"></span>
											<div class="orderForm_lineResult<?=($arResult['FIELDS']['PROPERTY_PRICE']['ERROR'] ? ' input_error' : '')?>">
												<?=$arResult['FIELDS']['PROPERTY_PRICE']['NAME']?><?if($arResult['FIELDS']['PROPERTY_PRICE']['REQUIRED']):?> <span class="formImportant"><?= GetMessage("REQUIRED_SYMBOL"); ?></span><?endif?><input class="lineResult_Input only_numbers" style="margin: 0 10px; width: 80px;" type="text" value="<?=$arResult['FIELDS']['PROPERTY_PRICE']['VALUE']?>" name="<?=$arResult['FIELDS']['PROPERTY_PRICE']['INPUT_NAME']?>">/input><?= GetMessage("RUB"); ?>
											</div>
										
										<?else:?>
										
										<div class="orderForm_lineResult<?=($prop['ERROR'] ? ' input_error' : '')?>">
												
												<?if($prop['ADVISED_TYPE'] == 'text'):?>
													<input class="lineResult_Input" type="text" value="<?=$prop['VALUE']?>" name="<?=$prop['INPUT_NAME']?>" />
												<?elseif($prop['ADVISED_TYPE'] == 'textarea'):?>
													<textarea class="lineResult_Textarea" name="<?=$prop['INPUT_NAME']?>"><?=$prop['VALUE']?></textarea>
												<?elseif($prop['ADVISED_TYPE'] == 'select'):?>
													<select class="customSelect01<?=($prop['ERROR'] ? ' input_error' : '')?>" name="<?=$prop['INPUT_NAME']?>">
														<?foreach($prop['ITEMS'] as $id => $item):?>
															<option value="<?=$id?>"<?=($id == $prop['VALUE'] ? ' selected' : '')?>><?=$item['NAME']?></option>
														<?endforeach?>
													</select>
													<div class="customSelect_Arrow"></div>
												<?endif?>
											
											<?/*<?endif?>*/?>
											
										</div>
										
										<?endif?>
										
										<br class="clear_both">
									</div>

									<div class="orderForm_lineDivider"></div>
									<?$i++;?>
								<?endforeach?>
								
								<?if($arParams['USE_CAPTCHA']):?>
									<div class="orderForm_Line"<?=(!($i && $i%2) ? ' style="background: #eef5fb;"' : '')?>>
										<?$APPLICATION->IncludeComponent("oneway:system.recaptcha", "order", Array(
											'WORD_INPUT_NAME' => $arResult['CAPTCHA']['WORD_INPUT_NAME'],
											'SID_INPUT_NAME' => $arResult['CAPTCHA']['SID_INPUT_NAME'],
											'FAILED' => $arResult['CAPTCHA']['ERROR']
										), false, array('HIDE_ICONS' => 'Y'));?>
									</div>
									<div class="orderForm_lineDivider"></div>
								<?endif?>
								
								<div class="orderForm_Line">
									<div class="orderForm_lineTitle"><?= GetMessage("FIELD_SELECT_SYMBOL"); ?> <span class="formImportant"><?= GetMessage("REQUIRED_SYMBOL"); ?></span><br><?= GetMessage("REQUIRED_FIELD"); ?></div>
									<div class="orderForm_lineResult">
										<input class="formButton_Orange" style="margin: 6px 0 0 0; width: 100px;" type="submit" value="<?= GetMessage("SEND"); ?>" name="<?=$arResult['FORM']['SUBMIT_INPUT_NAME']?>">
									</div>
									<br class="clear_both">
								</div>

							</form>
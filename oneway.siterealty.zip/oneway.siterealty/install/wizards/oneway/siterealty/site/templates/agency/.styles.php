<?
$arStyles = array(
);
return $arStyles;
?>
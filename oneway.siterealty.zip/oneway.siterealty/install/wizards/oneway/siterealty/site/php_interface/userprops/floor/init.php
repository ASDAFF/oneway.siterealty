<?
RegisterModuleDependences('iblock', 'OnIBlockPropertyBuildList', 'main', 'M_CIBlockPropertyFloor', 'GetUserTypeDescription', 100, '/php_interface/'.SITE_ID.'/userprops/floor/property.php');

/*
 AddEventHandler("iblock", "OnBeforeIBlockElementAdd", array("CCustomPropertyXPostProc", "doSmth"));
 AddEventHandler("iblock", "OnBeforeIBlockElementUpdate", array("CCustomPropertyXPostProc", "doSmth"));
 
 class CCustomPropertyXPostProc{
	
	public static function doSmth(&$elem){
		// что-то делаем
		return $elem;
	}
 }
 */
 ?>
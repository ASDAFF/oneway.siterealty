<?
 function _m_bx_restore_component_borders($iblock, $element_selector){
	CModule::IncludeModule('iblock');
 
	$iblock = CIBlock::GetByID($iblock);
	$iblock = $iblock->Fetch();
	
	$msgs = CIBlock::GetMessages($iblock['ID']);
	$controller = $iblock['CODE'];
	
	$httpDir = str_replace(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '', str_replace('\\', '/', __DIR__)).'/';
	
	?>
	<script type="text/javascript" src="<?=$httpDir?>adminborder.js"></script>
	<script type="text/javascript">
		BX.ready(function(){
			<?=$controller?> = $.adminBorder({
				bx: BX,
				
				iblockType: '<?=$iblock['IBLOCK_TYPE_ID']?>',
				iblockId: '<?=$iblock['ID']?>',
				
				editTextLabel: '<?=$msgs['ELEMENT_EDIT']?>',
				removeTextLabel: '<?=$msgs['ELEMENT_DELETE']?>',
				
				itemsSelector: '<?=$element_selector?>',
				sessid: '<?=$_SESSION['fixed_session_id']?>'
			});
		});
	</script>
	<?
	
	return $controller;
 }
 function _m_bx_restore_border($controller, $back_url){
	?>
	<script type="text/javascript">
		BX.ready(function(){
		<?=$controller?>.addBorders('<?=urlencode($back_url)?>');
		});
	</script>	
	<?
 }
 ?>
<?
 // OneWay Bitrix Framework by AwEsOmE. Version 3.0a
 // ������������� ������� �����
 
 define("__BASEMENT_FOOR_INT", "0");
 define("__ATTIC_FOOR_INT", "9999");
 define("__ONLY_ROOM_INT", "0");
 define("__BASE_COOKIE_GROUP", "base_");
 
 // install-time constants
 define("__REGION_IBLOCK_ID", "#REGION_IBLOCK_ID#");
 define("__BASE_IBLOCK_ID", "#BASE_IBLOCK_ID#");
 define("__ORDER_IBLOCK_ID", "#ORDER_IBLOCK_ID#");
 define("__DEAL_TYPES_IBLOCK_ID", "#DEAL_TYPES_IBLOCK_ID#"); 
 
 define("__DT_IN_BASE", "#DT_IN_BASE#");
 define("__DT_IN_ORDER", "#DT_IN_ORDER#");
 
 ?>
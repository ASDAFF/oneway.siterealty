<?
 //////////////////////////////////////////////////////////////////////////////////////////////////
 // ������������ ������� �� ����, �� ������ ������� �������� (���. � �����������)
 function _m_date_filter($day, $mon, $year, $field_name = 'DATE_ACTIVE_FROM')
 {
    _m_include_constants();
	_m_include_etc();
	_m_include_date();
 
 	$year = intval($year);
    $day = intval($day);
 	$mon = intval($mon);
	
 	if($day)
 	 $day = _m_positive_mod($day, 31);
 	if($mon)
 	 $mon = _m_positive_mod($mon, 12);

 	if(!$year || ($day && !$mon))
 		return false;

	if(preg_match('#^PROPERTY_#', $field_name))
	{
	 $is_property = true;
	 $field_name = str_replace('PROPERTY_', '', $field_name);
	}

    date_default_timezone_set('UTC');
	
 	$filter = array();
 	if($day)
 	{
	    $next_date = getdate(mktime(0,0,1,$mon,$day,$year) + ONE_DAY_TIMESTAMP);
		
		if($is_property) // bug walkaround
		{
		 $filter['>='.$field_name] = $year.'-'._m_leading_zeroes($mon, 2).'-'._m_leading_zeroes($day, 2);
		 $filter['<='.$field_name] = $next_date['year'].'-'._m_leading_zeroes($next_date['mon'], 2).'-'._m_leading_zeroes($next_date['mday'], 2);
		}
		else
		{
 		 $filter['>='.$field_name] = _m_leading_zeroes($day, 2).'.'._m_leading_zeroes($mon, 2).'.'.$year; // ������� � ����������, ��� sprintf()
 		 $filter['<='.$field_name] = _m_leading_zeroes($next_date['mday'], 2).'.'._m_leading_zeroes($next_date['mon'], 2).'.'.$next_date['year'];
		}

 		$desc = _m_leading_zeroes($day, 2).'.'._m_leading_zeroes($mon, 2).'.'.$year;
 	}
    elseif($mon)
    {
	    $next_date = _m_next_month_year($mon, $year);
	
	    if($is_property) // bug walkaround
		{
		 $filter['>='.$field_name] = $year.'-'._m_leading_zeroes($mon, 2).'-01';
		 $filter['<='.$field_name] = $next_date['year'].'-'._m_leading_zeroes($next_date['mon'], 2).'-01';
		}
		else
		{
    	 $filter['>='.$field_name] = '01.'._m_leading_zeroes($mon, 2).'.'.$year;
    	 $filter['<='.$field_name] = '01.'._m_leading_zeroes($next_date['mon'], 2).'.'.$next_date['year'];
		}
		
    	$desc = _m_ru_month($mon, 'NOM').' '.$year;
    }
 	elseif($year)
 	{	
 		$filter['>='.$field_name] = '01.01.'.$year;
 		$filter['<='.$field_name] = '01.01.'.($year+1);

 		$desc = $year.' ���';
 	}
	else
	 return false;
	
 	//$filter['>='.$field_name] .= ' 00:00:01';
 	//$filter['<='.$field_name] .= ' 23:59:59';
	
	$result = array();
	if($is_property)
	 $result['PROPERTY'] = $filter;
	else
	 $result = $filter;
	 
	$result['_DESC_'] = $desc;
	
	return $result;
 }

 //////////////////////////////////////////////////////////////////////////////////////////////////
 // ��������� ������� �� ����, �� ���������� ������� $_REQUEST
 function _m_set_date(&$filter, $day_fld = 'f_day', $mon_fld = 'f_mon', $year_fld = 'f_year')
 {
   if(!is_array($filter))
    $filter = array();

   $GLOBALS['__filter_by_date__'] = '';
   $filter_ = _m_date_filter($_REQUEST[$day_fld], $_REQUEST[$mon_fld], $_REQUEST[$year_fld]);

   if($filter_)
   {
 	$GLOBALS['__filter_by_date__'] = $filter_['__DESC__'];
 	unset($filter_['__DESC__']);
 	$filter = array_merge($filter_, $filter);
   }

   return $filter;
 } 
 
 /*
 //////////////////////////////////////////////////////////////////////////////////////////////////
 // ��������� �� ���� � �������
 function _m_date_expired($date_)
 {
  $date = _parse_default_date($date_);
  
  return $date['0'] < time();
 }
 */

 //////////////////////////////////////////////////////////////////////////////////////////////////
 // ������������� ������ ���������� $range ���� �����, ���������� �� ���������� ����
 function _m_date_range_filter($day, $mon, $year, $field_name, $range = 0)
 {
  	_m_include_etc();
 
 	$year = intval($year);
        $day = intval($day);
 	$mon = intval($mon);
        $range = intval($range);

        ($range < 0) && ($range *= -1);
	
        if(!strlen($field_name))
         $field_name = 'DATE_ACTIVE_FROM';

 	if($day)
 	 $day = _m_positive_mod($day, 31);
 	if($mon)
 	 $mon = _m_positive_mod($mon, 12);

 	if(!$year || !$day || !$mon)
 		return false;

	if(preg_match('#^PROPERTY_#', $field_name))
	{
	 $is_property = true;
	 $field_name = str_replace('PROPERTY_', '', $field_name);
	}

        date_default_timezone_set('UTC');

 	$filter = array();
 
	    $prev_date = getdate(mktime(0,0,1,$mon,$day,$year) - (1 + $range)*ONE_DAY_TIMESTAMP);
		
		if($is_property) // bug walkaround
		{
		 $filter['<='.$field_name] = $year.'-'._m_leading_zeroes($mon, 2).'-'._m_leading_zeroes($day, 2);
		 $filter['>='.$field_name] = $prev_date['year'].'-'._m_leading_zeroes($prevt_date['mon'], 2).'-'._m_leading_zeroes($prev_date['mday'], 2);
		}
		else
		{
 		 $filter['<='.$field_name] = _m_leading_zeroes($day, 2).'.'._m_leading_zeroes($mon, 2).'.'.$year; // ������� � ����������, ��� sprintf()
 		 $filter['>='.$field_name] = _m_leading_zeroes($prev_date['mday'], 2).'.'._m_leading_zeroes($prev_date['mon'], 2).'.'.$prev_date['year'];
		}

	$result = array();
	if($is_property)
	 $result['PROPERTY'] = $filter;
	else
	 $result = $filter;
	 
	
	return $result;
 }
?>
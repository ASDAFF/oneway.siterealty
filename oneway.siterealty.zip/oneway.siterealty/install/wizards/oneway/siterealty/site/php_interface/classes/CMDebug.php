<?
 
 class CMDebug {

 private static $allowedDevelopers = array(
	'admin', 
	'sergey', 
	'awesome', 
	'awesome1888@gmail.com'
 );

 public static function ISDeveloper(){
	if(!$GLOBALS['USER'])
		return true;
 
	if($_REQUEST['printr_force_show'] == 1)
		return true;
 
	global $allowedDevelopers;
	if(is_object($GLOBALS['USER']) && in_array($GLOBALS['USER']->GetLogin(), self::$allowedDevelopers))
		return true;
 
	return false;
 }

 public static function PrintR($arr){
  if(!self::ISDeveloper())	return;
 
  if(!isset($arr))
  {
   print('Variable is not defined.<br />');
   return;
  }

  print("<div style=\"text-align: left; background-color: white; color: black\"><pre style=\"font-size:14px\">");
  ob_start();
  print_r($arr);
  $html = ob_get_contents();
  ob_end_clean();
  print(htmlspecialchars($html));
  print("</pre></div>");
 }
 
 public static function DumpR($val){
  if(!self::ISDeveloper())	return;
	
	ob_start();
	print_r($val);
	$dump = ob_get_contents();
	ob_end_clean();
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/dump.txt', $dump, FILE_APPEND);
 }
 
 public static function MeasureTime($label = 'RANGE'){
  if(!self::ISDeveloper())	return;

  static $tm;
  if($tm === null){
	$tm = round(microtime(true), 6);
	print($label.': Start ==========================<br />');
  }else{
	$tm = round(microtime(true) - $tm, 6);
	print($label.': End => '.$tm.' sec<br />');
  }
  
  return $tm;
 } 
 
 public static function MeasureMemory($label = 'MEMORY'){
  if(!self::ISDeveloper())	return;

  static $mem;
  if($mem === null){
	$mem = memory_get_usage();
	print($label.': Start ==========================<br />');
  }else{
	$mem = memory_get_usage() - $mem;
	print($label.': End => '.($mem > 1024 ? (round($mem / 1024, 3)).' Kbytes' : $mem.' bytes').'<br />');
  }
  
  return $mem;
 } 
 
 }
 
 if(!function_exists('_print_r')){
	function _print_r($arr){
		CMDebug::PrintR($arr);
	}
 }
?>
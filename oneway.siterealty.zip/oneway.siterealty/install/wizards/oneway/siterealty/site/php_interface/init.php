<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

include_once(GetLangFileName($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/oneway.siterealty/lang/', '/php_interface/userprops/floor/property.php'));

define("IBLOCK_BASE", "#BASE_IBLOCK_ID#");

define("PROP_PRICE_ID", "#PROPERTY_PRICE_ID#");
define("PROP_PRICE_M2_ID", "#PROPERTY_PRICE_M2_ID#");
define("PROP_SQUARE_ID", "#PROPERTY_SQUARE_TOTAL_ID#");
define("PROP_FLOOR2_ID", "#PROPERTY_FLOOR2_ID#");
define("PROP_NOS_ID", "#PROPERTY_NOS_ID#");
define("PROP_ROOMS_ID", "#PROPERTY_ROOMS_ID#");
define("PROP_SQUARE_LIVING_ID", "#PROPERTY_SQUARE_LIVING_ID#");
define("PROP_SQUARE_KITCHEN_ID", "#PROPERTY_SQUARE_KITCHEN_ID#");
define("PROP_PHOTOS_ID", "#PROPERTY_PHOTOS_ID#");
define("PROP_PHOTOS_THUMB_ID", "#PROPERTY_PHOTOS_THUMB_ID#");
define("PROP_PLAN_ID", "#PROPERTY_PLAN_ID#");
define("PROP_PLAN_THUMB_ID", "#PROPERTY_PLAN_THUMB_ID#");


/* main classes */
require(__DIR__.'/classes/init.php');

/* custom props */
require(__DIR__.'/userprops/floor/init.php');

/* property validation */
require(__DIR__.'/tools/CPropValidator.php');

AddEventHandler("iblock", "OnAfterIBlockElementAdd", "_m_validate_props");
AddEventHandler("iblock", "OnAfterIBlockElementUpdate", "_m_validate_props");
function _m_validate_props(&$element){
	if(!strlen($element['NAME'])) // ��� �������, ��� �� ������������
		return $element;
	if($element['IBLOCK_ID'] != IBLOCK_BASE)
		return $element;

	CPropValidator::VInt($element, IBLOCK_BASE, 'FLOOR2', PROP_FLOOR2_ID);
	CPropValidator::VInt($element, IBLOCK_BASE, 'NOS', PROP_NOS_ID, true);
	CPropValidator::VInt($element, IBLOCK_BASE, 'ROOMS', PROP_ROOMS_ID, true);
	
	CPropValidator::VFloat($element, IBLOCK_BASE, 'SQUARE_TOTAL', PROP_SQUARE_ID, false, true);
	CPropValidator::VFloat($element, IBLOCK_BASE, 'SQUARE_LIVING', PROP_SQUARE_LIVING_ID, false, true);
	CPropValidator::VFloat($element, IBLOCK_BASE, 'SQUARE_KITCHEN', PROP_SQUARE_KITCHEN_ID, false, true);
	
	CPropValidator::VFloat($element, IBLOCK_BASE, 'PRICE', PROP_PRICE_ID, 2, true);
	CPropValidator::VFloat($element, IBLOCK_BASE, 'PRICE_M2', PROP_PRICE_M2_ID, 2, true);
			
	return $element;
}

/* triada: price, price_m2, square */

AddEventHandler("iblock", "OnBeforeIBlockElementAdd", "_store_base_element");
AddEventHandler("iblock", "OnBeforeIBlockElementUpdate", "_store_base_element");

function _store_base_element(&$element){
	if($element['IBLOCK_ID'] != IBLOCK_BASE)
		return $element;
	if(!strlen($element['NAME'])) // ��� �������, ��� �� ������������
		return $element;
	if(!intval($element['ID']))
		return $element;

	CMacro::Add('array');
	CMacro::Add('secure');
		
	// �������� � ������
	$cost_total_fi = CMArray::FirstIndex($element['PROPERTY_VALUES'][PROP_PRICE_ID]);
	$cost_m2_fi = CMArray::FirstIndex($element['PROPERTY_VALUES'][PROP_PRICE_M2_ID]);
	$cost_square_fi = CMArray::FirstIndex($element['PROPERTY_VALUES'][PROP_SQUARE_ID]);

	$cost_total = $element['PROPERTY_VALUES'][PROP_PRICE_ID][$cost_total_fi]['VALUE'] = preg_replace('#[^\d]#', '', $element['PROPERTY_VALUES'][PROP_PRICE_ID][$cost_total_fi]['VALUE']);
	$cost_m2 = $element['PROPERTY_VALUES'][PROP_PRICE_M2_ID][$cost_m2_fi]['VALUE'] = preg_replace('#[^\d]#', '', $element['PROPERTY_VALUES'][PROP_PRICE_M2_ID][$cost_m2_fi]['VALUE']);
	$square = $element['PROPERTY_VALUES'][PROP_SQUARE_ID][$cost_square_fi]['VALUE'] = CMSecure::Floatval($element['PROPERTY_VALUES'][PROP_SQUARE_ID][$cost_square_fi]['VALUE']);

	if($square && $cost_total && !$cost_m2)
		$element['PROPERTY_VALUES'][PROP_PRICE_M2_ID][$cost_m2_fi]['VALUE'] = round($cost_total / $square, 0);

	if($square && $cost_m2 && !$cost_total)
		$element['PROPERTY_VALUES'][PROP_PRICE_ID][$cost_total_fi]['VALUE'] = round($cost_m2 * $square, 0);
}
  
/* image resampling */
require(__DIR__.'/tools/CImageResample.php');

AddEventHandler("iblock", "OnAfterIBlockElementAdd", "_multiple_make_thumbnails");
AddEventHandler("iblock", "OnAfterIBlockElementUpdate", "_multiple_make_thumbnails");
  
function _multiple_make_thumbnails(&$element){
  
    // ��� ������� DETAIL_PICTURE � PREVIEW_PICTURE �� �������� �. ����������� ������� �� �������� ���������.
    CMImageResample::MakePreviewNDetail($element, IBLOCK_BASE, PROP_PHOTOS_ID);
  
    // ������ ������ => ���������
    CMImageResample::MakeThumbnails($element, IBLOCK_BASE, PROP_PHOTOS_ID, PROP_PHOTOS_THUMB_ID, 68 /*h*/, 91 /*w*/, CMImageResample::RM_HALF_INSERT);
	
	// ������ ���������� => ��������� ����������
	CMImageResample::MakeThumbnails($element, IBLOCK_BASE, PROP_PLAN_ID, PROP_PLAN_THUMB_ID, 68 /*h*/, 91 /*w*/, CMImageResample::RM_HALF_INSERT);
}

?>
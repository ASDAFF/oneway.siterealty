<?
/**
 * ���������������� �������� ���� "����"
 * @package default
 * @author Awesome <awesome1888@gmail.com>
 * @version 1.0, 12.02.2013
 * @copyright Awesome
 */
if (!class_exists('M_CIBlockPropertyFloor')){

        class M_CIBlockPropertyFloor{
		
                function GetUserTypeDescription(){
				
                        return array(
                                'PROPERTY_TYPE'   => 'S',
                                'USER_TYPE'          => 'M_PropertyFloor',
                                'DESCRIPTION'         => GetMessage('ONEWAY_FLOOR_PROPERTY_DESCRIPTION'),
                                'GetPropertyFieldHtml'  => array('M_CIBlockPropertyFloor','GetPropertyFieldHtml'),
                                'ConvertToDB'         => array('M_CIBlockPropertyFloor','ConvertToDB'),
                                'ConvertFromDB'   => array('M_CIBlockPropertyFloor','ConvertFromDB')
                        );
                }
                
                function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName){
				
						$propHTTPDir = str_replace(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '', str_replace('\\', '/', __DIR__)).'/';
						$randomTag = rand(0,9999);
						ob_start();
						?>

						<?
						 $otherSelected = !strlen($value['VALUE']) || ($value['VALUE'] != '9999' && $value['VALUE'] != '0');
						 ?>
						
						<label><input type="radio" name="floor_<?=$randomTag?>" id="attic_floor_<?=$randomTag?>" value="9999" <?=($value['VALUE'] == '9999' ? 'checked' : '')?> /> <?= GetMessage('MANSARD'); ?></label><br />
						<label><input type="radio" name="floor_<?=$randomTag?>" id="other_floor_<?=$randomTag?>" <?=($otherSelected ? 'checked' : '')?> /> <?= GetMessage('NUM_FLOOR'); ?> <input id="other_floor_value_<?=$randomTag?>" type="text" value="<?=($otherSelected ? (strlen($value['VALUE']) ? $value['VALUE'] : '') : '')?>" /></label><br />
						<label><input type="radio" name="floor_<?=$randomTag?>" id="basement_floor_<?=$randomTag?>" value="0" <?=($value['VALUE'] == '0' ? 'checked' : '')?> /> <?= GetMessage('COKOL'); ?></label><br />
						
						<input id="floor_value_<?=$randomTag?>" type="hidden" name="<?=$strHTMLControlName['VALUE']?>" value="<?=(strlen($value['VALUE']) ? $value['VALUE'] : '')?>"<?=$strTemp?>>
						
						<style type="text/css">
							#other_floor_value_<?=$randomTag?>{
								height: 20px;
								width: 70px;
							}
							#other_floor_value_<?=$randomTag?>{
								width: 100px;
							}
						</style>
						
						<script type="text/javascript">
							(function(){
								var propInput = document.getElementById('floor_value_<?=$randomTag?>');
								var otherFloorValue = document.getElementById('other_floor_value_<?=$randomTag?>');
								document.getElementById('attic_floor_<?=$randomTag?>').addEventListener('click', function(){
									propInput.value = 9999;
								});
								document.getElementById('basement_floor_<?=$randomTag?>').addEventListener('click', function(){
									propInput.value = 0;
								});
								document.getElementById('other_floor_<?=$randomTag?>').addEventListener('click', function(){
									propInput.value = otherFloorValue.value;
								});
								otherFloorValue.addEventListener('keyup', function(){
									propInput.value = this.value;
								});
							})();
						</script>
						
						<?
						$return = ob_get_contents();
						ob_end_clean();
						
                        return  $return;
                }
        
                function ConvertToDB($arProperty, $value)
                {
						//$value = trim($value);
						//$value = substr(str_replace('#', '', strtolower(trim($value))), 0, 6);
						//if(preg_match('#[0-9a-f]{6}#', $value))
							return $value; //array('VALUE' => $value);
						
                }
        
                function ConvertFromDB($arProperty, $value)
                {
						//$value = substr(str_replace('#', '', strtolower(trim($value))), 0, 6);
						//$value = trim($value);
						//if(preg_match('#[0-9a-f]{6}#', $value))
							return $value; //array('VALUE' => $value);
				}
        
        }
}

?>
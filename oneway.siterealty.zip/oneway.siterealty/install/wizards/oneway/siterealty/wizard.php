<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/modules/main/install/wizard_sol/wizard.php");

class SelectSiteStep extends CSelectSiteWizardStep
{
	function InitStep()
	{
		parent::InitStep();
		$wizard =& $this->GetWizard();
		$wizard->solutionName = "siterealty";
	}
}

class SelectTemplateStep extends CSelectTemplateWizardStep
{
	function InitStep()
	{
		parent::InitStep();
		
		$wizard =& $this->GetWizard();
		$wizard->solutionName = "siterealty";
		$this->SetNextStep("site_settings");
	}
}

class SiteSettingsStep extends CSiteSettingsWizardStep
{
	function InitStep()
	{
		parent::InitStep();
		
		$wizard =& $this->GetWizard();
		$wizard->solutionName = "siterealty";
		$this->SetPrevStep("select_template");
		
		$templateID = $wizard->GetVar("templateID");
		$includesPath = WIZARD_SITE_ROOT_PATH . "/bitrix/wizards/oneway/" . $wizard->solutionName . "/site/public/" . LANGUAGE_ID . "/include/";
		$logoFileName = $includesPath . "logo.png";
		
		if (!file_exists(WIZARD_SITE_ROOT_PATH.$logoFileName))
				$logoFileName = "";
		
		$wizard->SetDefaultVars(
			Array(
				"siteLogo" => $logoFileName,
				"siteSlogan" => $this->GetFileContent($includesPath . "slogan.html", GetMessage("WIZ_COMPANY_SLOGAN_DEF")),
				"sitePhone" => $this->GetFileContent($includesPath . "cphone.html", GetMessage("WIZ_COMPANY_PHONE_DEF")),
				"siteCopy" => $this->GetFileContent($includesPath . "copyright.html", GetMessage("WIZ_COMPANY_COPY_DEF")),
				"siteContacts" => $this->GetFileContent($includesPath . "contacts.html", GetMessage("WIZ_COMPANY_CONTACTS_DEF")),
				"siteContactsFull" => $this->GetFileContent($includesPath . "contacts_full.html", GetMessage("WIZ_COMPANY_CONTACTS_FULL_DEF")),
				"siteMetaDescription" => GetMessage("wiz_site_desc"),
				"siteMetaKeywords" => GetMessage("wiz_keywords")
			)
		);
	}

	function ShowStep()
	{
        $wizard =& $this->GetWizard();
				
		$siteLogo = $wizard->GetVar("siteLogo", true);
        if (strlen($siteLogo) > 0)
            $siteLogo = str_replace(WIZARD_SITE_ROOT_PATH, '', $siteLogo);
        
        $this->content .= '<table width="100%" cellspacing="0" cellpadding="0">';
		
		$this->content .= '<tr><td>
				<div class="wizard-input-form-block" style="margin-bottom: 0">
						<h4 style="margin-top:0"><label for="siteMetaDescription">'.GetMessage("wiz_header_data").'</label></h4>
				</div>
		</td></tr>';
		
		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-logo">'.GetMessage("WIZ_COMPANY_LOGO").'</label><br />';
		$this->content .= CFile::ShowImage($siteLogo, 316, 77, "border=0 vspace=15");
		$this->content .= "<br />".$this->ShowFileField("siteLogo", Array("show_file_info" => "N", "id" => "site-logo"));
		$this->content .= '</tr></td>';

		$this->content .= '<tr><td><br /></td></tr>';
		
		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-slogan">'.GetMessage("WIZ_COMPANY_SLOGAN").'</label><br />';
		$this->content .= $this->ShowInputField("textarea", "siteSlogan", Array("id" => "site-slogan", "style" => "width:100%", "rows"=>"3"));
		$this->content .= '</tr></td>';

		$this->content .= '<tr><td><br /></td></tr>';
		
		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-slogan">'.GetMessage("WIZ_COMPANY_PHONE").'</label><br />';
		$this->content .= $this->ShowInputField("textarea", "sitePhone", Array("id" => "site-phone", "style" => "width:100%", "rows"=>"3"));
		$this->content .= '</tr></td>';
		
		$this->content .= '<tr><td><br /><br /></td></tr>';
		
		$this->content .= '<tr><td>
				<div class="wizard-input-form-block" style="margin-bottom:0">
						<h4 style="margin-top:0"><label for="siteMetaDescription">'.GetMessage("wiz_footer_data").'</label></h4>
				</div>
		</td></tr>';
		
		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-copy">'.GetMessage("WIZ_COMPANY_COPY").'</label><br />';
		$this->content .= $this->ShowInputField("textarea", "siteCopy", Array("id" => "site-copy", "style" => "width:100%", "rows"=>"3"));
		$this->content .= '</tr></td>';

		$this->content .= '<tr><td><br /></td></tr>';

		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-copy">'.GetMessage("WIZ_COMPANY_CONTACTS").'</label><br />';
		$this->content .= $this->ShowInputField("textarea", "siteContacts", Array("id" => "site-copy", "style" => "width:100%", "rows"=>"3"));
		$this->content .= '</tr></td>';

		$this->content .= '<tr><td><br /><br /></td></tr>';
		
		$this->content .= '<tr><td>
				<div class="wizard-input-form-block" style="margin-bottom:0">
						<h4 style="margin-top:0"><label for="siteMetaDescription">'.GetMessage("wiz_info_data").'</label></h4>
				</div>
		</td></tr>';
		
		$this->content .= '<tr><td>';
		$this->content .= '<label for="site-copy">'.GetMessage("WIZ_COMPANY_CONTACTS_FULL").'</label><br />';
		$this->content .= $this->ShowInputField("textarea", "siteContactsFull", Array("id" => "site-copy", "style" => "width:100%", "rows"=>"3"));
		$this->content .= '</tr></td>';
		
		$firstStep = COption::GetOptionString("main", "wizard_first" . substr($wizard->GetID(), 7)  . "_" . $wizard->GetVar("siteID"), false, $wizard->GetVar("siteID"));

		$styleMeta = 'style="display:block"';
		if($firstStep == "Y") $styleMeta = 'style="display:none"';
		
		$this->content .= '<tr><td><br /><br /></td></tr>';
		$this->content .= '<tr><td>
		<div  id="bx_metadata" '.$styleMeta.'>
			<div class="wizard-input-form-block">
				<h4 style="margin-top:0"><label for="siteMetaDescription">'.GetMessage("wiz_meta_data").'</label></h4>
		 		<label for="siteMetaDescription">'.GetMessage("wiz_meta_description").'</label>'.
				$this->ShowInputField("textarea", "siteMetaDescription", Array("id" => "siteMetaDescription", "style" => "width:100%", "rows"=>"3")).'
			</div>';
			$this->content .= '
			<div class="wizard-input-form-block">
				<label for="siteMetaKeywords">'.GetMessage("wiz_meta_keywords").'</label><br>'.
				$this->ShowInputField('text', 'siteMetaKeywords', array("id" => "siteMetaKeywords", "style" => "background-color:#fff;width:100% !important")).
			'</div>
		</div>';
		
		if($firstStep == "Y")
		{
			$this->content .= '<tr><td style="padding-bottom:3px;">';
			$this->content .= $this->ShowCheckboxField("installDemoData", "Y", 
				(array("id" => "install-demo-data", "onClick" => "if(this.checked == true){document.getElementById('bx_metadata').style.display='block';}else{document.getElementById('bx_metadata').style.display='none';}")));
			$this->content .= '<label for="install-demo-data">'.GetMessage("wiz_structure_data").'</label><br />';
			$this->content .= '</td></tr>';
			
			$this->content .= '<tr><td>&nbsp;</td></tr>';
		}
		else
		{
			$this->content .= $this->ShowHiddenField("installDemoData","Y");
		}

		$this->content .= '</table>';
        
		$formName = $wizard->GetFormName();
		$installCaption = $this->GetNextCaption();
		$nextCaption = GetMessage("NEXT_BUTTON");
	}

	function OnPostForm()
	{
		$wizard =& $this->GetWizard();
		$res = $this->SaveFile("siteLogo", Array("extensions" => "gif,jpg,jpeg,png", "max_height" => 77, "max_width" => 316, "make_preview" => "Y"));
	}
}

class DataInstallStep extends CDataInstallWizardStep
{
}

class FinishStep extends CFinishWizardStep
{
}
?>
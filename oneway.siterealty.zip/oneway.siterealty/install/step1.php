<?
if(!check_bitrix_sessid()) return;
IncludeModuleLangFile(__FILE__);
?>

<? if ($ex = $APPLICATION->GetException()): ?>
	<?= CAdminMessage::ShowMessage(Array(
		"TYPE" => "ERROR",
		"MESSAGE" => GetMessage("SITEREALTY_MOD_UNINST_ERR"),
		"DETAILS" => $ex->GetString(),
		"HTML" => true,
	)); ?>
<? else: ?>
    <?= CAdminMessage::ShowNote(GetMessage("SITEREALTY_MOD_INST_OK")); ?>
    <?= GetMessage("SITEREALTY_INSTALL_WIZARD", array("#HREF#" => "/bitrix/admin/wizard_install.php?lang=".LANGUAGE_ID."&wizardName=oneway:siterealty&".bitrix_sessid_get())); ?>
    <br><br>
<? endif; ?>

<form action="<?=$APPLICATION->GetCurPage()?>">
	<input type="hidden" name="lang" value="<?=LANG?>">
	<input type="submit" name="back" value="<?=GetMessage("SITEREALTY_MOD_BACK")?>">
<form>

<?
if(!check_bitrix_sessid()) return;

IncludeModuleLangFile(__FILE__);

if ($ex = $APPLICATION->GetException())
    echo CAdminMessage::ShowMessage(Array(
		"TYPE" => "ERROR",
		"MESSAGE" => GetMessage("SITEREALTY_MOD_INST_ERR"),
		"DETAILS" => $ex->GetString(),
		"HTML" => true
	));
else
    echo CAdminMessage::ShowNote(GetMessage("SITEREALTY_MOD_UNINST_OK"));
?>

<form action="<?=$APPLICATION->GetCurPage()?>">
	<input type="hidden" name="lang" value="<?=LANG?>">
	<input type="submit" name="" value="<?=GetMessage("SITEREALTY_MOD_BACK")?>">
<form>

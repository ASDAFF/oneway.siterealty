<?
$MESS["AW_IBFORM_DESC_ASC"] = "По возрастанию";
$MESS["AW_IBFORM_DESC_DESC"] = "По убыванию";
$MESS["AW_IBFORM_DESC_FID"] = "ID";
$MESS["AW_IBFORM_DESC_FNAME"] = "Название";

$MESS["AW_IBFORM_DESC_LIST_ID"] = "Код информационного блока";
$MESS["AW_IBFORM_DESC_LIST_TYPE"] = "Тип информационного блока (используется только для проверки)";
$MESS["AW_IBFORM_IBLOCK_FIELD"] = "Поля элемента";
$MESS["AW_IBFORM_IBLOCK_PROPERTY"] = "Свойства элемента";

$MESS["AW_IBFORM_IBLOCK_FIELD_REQUIRED"] = "Обязательные поля элемента";
$MESS["AW_IBFORM_IBLOCK_PROPERTY_REQUIRED"] = "Обязательные свойства элемента";

$MESS ['AW_IBFORM_ADD_NAME'] = "наименование";
$MESS ['AW_IBFORM_ADD_TAGS'] = "теги";
$MESS ['AW_IBFORM_ADD_ACTIVE_FROM'] = "дата начала";
$MESS ['AW_IBFORM_ADD_ACTIVE_TO'] = "дата завершения";
$MESS ['AW_IBFORM_ADD_IBLOCK_SECTION'] = "раздел инфоблока";
$MESS ['AW_IBFORM_ADD_PREVIEW_TEXT'] = "текст анонса";
$MESS ['AW_IBFORM_ADD_PREVIEW_PICTURE'] = "картинка анонса";
$MESS ['AW_IBFORM_ADD_DETAIL_TEXT'] = "подробный текст";
$MESS ['AW_IBFORM_ADD_DETAIL_PICTURE'] = "подробная картинка";
$MESS ['AW_IBFORM_ADD_SORT'] = "сортировка";
$MESS ['AW_IBFORM_ADD_XML_ID'] = "внешний код";
$MESS ['AW_IBFORM_ADD_CODE'] = "символьный код";

$MESS ['AW_IBFORM_CAPTCHA'] = "Использовать CAPTCHA";
$MESS ['AW_IBFORM_SUCCESS_URL'] = "Страница успешной отправки заявки";
$MESS ['AW_IBFORM_ERROR_CSS_CLASS'] = "CSS-класс input`а с ошибкой";

$MESS ['AW_IBFORM_IT_CSS'] = "CSS-класс для input type=\"text\"";
$MESS ['AW_IBFORM_SEL_CSS'] = "CSS-класс для input select";
$MESS ['AW_IBFORM_FILE_CSS'] = "CSS-класс для input type=\"file\"";

$MESS ['AW_IBFORM_FORM_NAME'] = "Имя формы (name)";
$MESS ['AW_IBFORM_CALENDAR_TEMPLATE'] = "Имя шаблона для main.calendar";

$MESS ['AW_IBFORM_ALT_NAMES'] = "Альтернативные названия";

$MESS["AW_IBFORM_EVENT_TYPES"] = "Тип почтового события";
$MESS["AW_IBFORM_REQUEST_PREFIX"] = 'Префикс переменных в $_REQUEST';

$MESS["AW_FETCH_OPTIONS"] = "Получать значения списковых свойств";
?>
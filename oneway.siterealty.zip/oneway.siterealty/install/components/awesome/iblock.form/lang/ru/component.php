<?
$MESS['AW_IBFORM_NAME'] = "Поле &laquo;#PROP_NAME#&raquo; обязательно для заполнения.";
$MESS['AW_IBFORM_WRONG_EMAIL'] = "Неверно указан e-mail.";
$MESS['AW_IBFORM_WRONG_CAPTCHA'] = "Неверно введён код с картинки.";

$MESS['AW_MESSAGE_ID'] = "Идентификатор элемента инфоблока";
$MESS['AW_MESSAGE_NAME'] = "Имя элемента инфоблока";
$MESS['AW_LINK'] = "Путь к элементу в админке";
?>
<?
$MESS ['AW_IBFORM_NAME'] = "Инфоблок форма";
$MESS ['AW_IBFORM_DESC'] = "Эмуляция веб-формы на инфоблоках (v2.0 04.02.2013).";

$MESS ['GROUP_AWESOME'] = "Awesome";
?>
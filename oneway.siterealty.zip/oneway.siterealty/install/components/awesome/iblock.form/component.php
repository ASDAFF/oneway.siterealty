<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arParams["IBLOCK_TYPE"] = trim($arParams["IBLOCK_TYPE"]);
if(strlen($arParams["IBLOCK_TYPE"])<=0)
 	$arParams["IBLOCK_TYPE"] = "news";
$arParams["IBLOCK_ID"] = trim($arParams["IBLOCK_ID"]);

########################################################################

CComponentTools::Escape($arParams['REQUEST_PREFIX']);
CComponentTools::Escape($arParams['ERROR_CSS_CLASS']);
CComponentTools::Escape($arParams['FORM_NAME']);

CComponentTools::Boolean($arParams["USE_CAPTCHA"]);
CComponentTools::Boolean($arParams["FETCH_OPTIONS"]);
CComponentTools::DropEmptyItems($arParams['FIELDS']);
CComponentTools::DropEmptyItems($arParams['PROPS']);

if(!strlen($arParams['FORM_NAME']))
	$arParams['FORM_NAME'] = 'form_iblock_'.$arParams["IBLOCK_ID"];

if(!strlen($arParams['REQUEST_PREFIX']))
	$arParams['REQUEST_PREFIX'] = $arParams['FORM_NAME'];

if($GLOBALS['USER']->IsAuthorized())
 $arParams["USE_CAPTCHA"] = false;

if(!strlen($arParams['ERROR_CSS_CLASS']))
 $arParams['ERROR_CSS_CLASS'] = 'request_form_error';
 
$ADMIN_PATH = 'http://'.$_SERVER['SERVER_NAME'].'/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=#IBLOCK_ID#&type=#IBLOCK_TYPE#&ID=#MESSAGE_ID#';
 
########################################################################

	if(!CModule::IncludeModule("iblock"))
	{
		ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
		return;
	}
	
	$arResult = array();
	$iblock_f = CIBlock::GetFields($arParams['IBLOCK_ID']);
	
	//print_r($iblock_f);
	
	foreach($arParams['FIELDS'] as $fld)
	{
	 if(in_array($fld, array('PREVIEW_TEXT', 'DETAIL_TEXT')))
	 {
	  $type = 'textarea';
	 }
	 elseif(in_array($fld, array('PREVIEW_PICTURE', 'DETAIL_PICTURE')))
	 {
	  $type = 'file';
	 }
	 elseif($fld == 'IBLOCK_SECTION')
	 {
	  $type = 'select';
	 }
	 else
	 {
	  $type = 'text';
	 }
	
	 $arResult['FIELDS'][$fld] = array(
	  'CODE' => $fld,
	  'SYSTEM' => false,
	  'MULTIPLE' => false,
	  'VALUE' => '',
	  'REQUIRED' => $iblock_f[$fld]['IS_REQUIRED'] == 'Y',
	  'ADVISED_TYPE' => $type,
	  'NAME' => strlen($arParams[$fld.'_ALT']) ? $arParams[$fld.'_ALT'] : $iblock_f[$fld]['NAME'],
	  'INPUT_NAME' => $arParams['REQUEST_PREFIX'].'[FIELDS]['.$fld.']',
	  'VALUE' => htmlspecialchars($_REQUEST[$arParams['REQUEST_PREFIX']]['FIELDS'][$fld]), // ��� ����� ������������ ��� �������� � ����� ��������� ��������
	  'IS_PROPERTY' => false
	 );
	}
	
	// ��� ���� ������ ���������� ������� �������
	$selectedProps = array_flip($arParams['PROPS']);
	$usedProps = array();
	$res = CIBlockProperty::GetList(Array("SORT"=>"ASC", "NAME"=>"ASC"), Array("ACTIVE"=>"Y", "IBLOCK_ID"=>$arParams['IBLOCK_ID']));
	while($prop = $res->Fetch())
		if(isset($selectedProps[$prop['CODE']]))
			$usedProps[$prop['CODE']] = $prop;
			
	foreach($usedProps as $fld => $res){

	 $name = $res['NAME'];
	 unset($res['NAME']);
	 
     if(in_array($res['PROPERTY_TYPE'], array('L', 'E', 'G')))
	  $type = 'select';
	 elseif($res['PROPERTY_TYPE'] == 'F')
	  $type = 'file';
	 elseif($res['ROW_COUNT'] > 1)
	  $type = 'textarea';
	 else
	  $type = 'text';
	 
	 $arResult['FIELDS']['PROPERTY_'.$fld] = array(
	 
	  'CODE' => 'PROPERTY_'.$fld,
	  'SYSTEM' => $res,
	  'MULTIPLE' => $res['MULTIPLE'] == 'Y',
	  'VALUE' => '',
	  'REQUIRED' => $res['IS_REQUIRED'] == 'Y',
	  'NAME' => $name,
	  'ADVISED_TYPE' => $type,
	  'INPUT_NAME' => $arParams['REQUEST_PREFIX'].'[FIELDS][PROPERTY_'.$fld.']',
	  'VALUE' => htmlspecialchars($_REQUEST[$arParams['REQUEST_PREFIX']]['FIELDS']['PROPERTY_'.$fld]), // ��� ����� ������������ ��� �������� � ����� ��������� ��������
	  'IS_PROPERTY' => true,
	  'TYPE' => $res['PROPERTY_TYPE']
	 
	 );
	 
	 if($res['PROPERTY_TYPE'] == 'E' && $arParams["FETCH_OPTIONS"]){
	  $list = array();
	  $elems = CIBlockElement::GetList(array('SORT' => 'ASC'), array('IBLOCK_ID' => $res['LINK_IBLOCK_ID'], 'ACTIVE' => 'Y'), false, false, array('ID', 'NAME'));
	  while($elem = $elems->Fetch())
	   $list[$elem['ID']] = $elem;
	  
	  $arResult['FIELDS']['PROPERTY_'.$fld]['ITEMS'] = $list;
	 }
	 if($res['PROPERTY_TYPE'] == 'L'){
	  $list = array();
	  $list_ = CIBlockPropertyEnum::GetList(array('sort' => 'asc'), array('CODE' => $fld, 'IBLOCK_ID' => $arParams['IBLOCK_ID']));
	  while($item = $list_->Fetch())
	   $list[$item['ID']] = array('NAME' => $item['VALUE']);
	   
	  $arResult['FIELDS']['PROPERTY_'.$fld]['ITEMS'] = $list;
	 }
	 if($res['PROPERTY_TYPE'] == 'G' && $arParams["FETCH_OPTIONS"]){
		$list = array();
		$elems = CIBlockSection::GetList(array('LEFT_MARGIN' => 'ASC', 'SORT' => 'ASC'), array('IBLOCK_ID' => $res['LINK_IBLOCK_ID'], 'ACTIVE' => 'Y'));
		$elems->SetURLTemplates();
		while($elem = $elems->GetNext())
			$list[$elem['ID']] = $elem;
		  
		$arResult['FIELDS']['PROPERTY_'.$fld]['ITEMS'] = $list;	
	 }

	}
	
	if($arParams["USE_CAPTCHA"])
	{
		include_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/classes/general/captcha.php"); 
	
		$arResult["CAPTCHA"]["SID"] =  htmlspecialchars($APPLICATION->CaptchaGetCode());
		$arResult["CAPTCHA"]["WORD_INPUT_NAME"] = $arParams['REQUEST_PREFIX'].'[CAPTCHA][WORD]';
		$arResult["CAPTCHA"]["SID_INPUT_NAME"] = $arParams['REQUEST_PREFIX'].'[CAPTCHA][SID]';
	} 
	
    $arResult['FORM']['SUBMIT_INPUT_NAME'] = $arParams['REQUEST_PREFIX'].'[SUBMIT]';
	
	// ��� ���������� ��������������� ����������� ����������
	if($_REQUEST[$arParams['REQUEST_PREFIX']]['SUBMIT'])
	{
	 $were_errors = false;
	 $request = $_REQUEST[$arParams['REQUEST_PREFIX']];
	 
	 foreach($arResult['FIELDS'] as $fid => $field){
	 
	  $arResult['FIELDS'][$fid]['VALUE'] = htmlspecialchars($request['FIELDS'][$field['CODE']]);
	  if(!strlen($arResult['FIELDS'][$fid]['VALUE']) && $field['REQUIRED']){
	   $arResult['FIELDS'][$fid]['ERROR'] = true;
	   $arResult['ERROR_SUMMARY'][] = str_replace('#PROP_NAME#', $field['NAME'], GetMessage('AW_IBFORM_NAME'));
	   $were_errors = true;
	  }
	  if(
		$fid == 'PROPERTY_EMAIL'
		&& 
		strlen($arResult['FIELDS'][$fid]['VALUE'])
		&& 
		!preg_match('#^[^\s]+@[^\s]+\.[^\s]+$#', $arResult['FIELDS'][$fid]['VALUE'])){ // cool non-documented feature :)
			$arResult['ERROR_SUMMARY'][] = GetMessage('AW_IBFORM_WRONG_EMAIL');
			$arResult['FIELDS'][$fid]['ERROR'] = true;
			$were_errors = true;
	  }
	 }
	 
	 // ��������� �����
	 if(
	    $arParams["USE_CAPTCHA"]
		&&
		!$APPLICATION->CaptchaCheckCode($request["CAPTCHA"]["WORD"], $request['CAPTCHA']['SID'])
	 )
	 {
	  $were_errors = true;
	  $arResult['CAPTCHA']['ERROR'] = true;
	  $arResult['ERROR_SUMMARY'][] = GetMessage('AW_IBFORM_WRONG_CAPTCHA');
	 }
	 
	 // ������ ����� ���������� ��������� � ��������� � ��������, ���� �� ���� ������
	 if(!$were_errors){
	 
	  $fields = array();
	  $props = array();
	  $mixed = array();
	  foreach($arResult['FIELDS'] as $fid => $field)
	  {
	   if($field['IS_PROPERTY'])
	    $props[$field['SYSTEM']['CODE']] = $field['VALUE'];
	   else
	    $fields[$field['CODE']] = $field['VALUE'];
		
	   $val = $field['VALUE'];
	   // ���� ������������ ���������� ��������� �������� ��� ������
	   if(in_array($field['TYPE'], array('L','G','E'))){
		if($arParams["FETCH_OPTIONS"])
			$val = $field['ITEMS'][$val]['NAME'].' ['.$val.']';	
		else{
		
			if($field['TYPE'] == 'E'){ // element
				$res = CIBlockElement::GetByID($val);
				$res = $res->Fetch();
				$val = $res['NAME'].' ['.$res['ID'].']';
			}
		
		}
	   }
		
	   $mixed[$field['CODE']] = $val;
	  }
	  
	  // ���������� � ��������
	  $element = array(
		"MODIFIED_BY" => $USER->GetID(),
		"IBLOCK_ID" => $arParams['IBLOCK_ID'],
        "ACTIVE"  => "Y",
		"ACTIVE_FROM" => ConvertTimeStamp(time(), 'FULL')
	  );
	  $element = array_merge($element, $fields);
	  $element['PROPERTY_VALUES'] = $props;
	  
	  $elem = new CIBlockElement();
	  $result = $elem->Add($element);
	  
	  if(!$result){
		$arResult['DB_ERROR_SUMMARY'][] = $elem->LAST_ERROR;
		$arResult['RESULT']['FAIL'] = true;
	  }else{
	  
		  $mixed['MESSAGE_ID'] = $result;
		  $mixed['MESSAGE_NAME'] = $mixed['NAME'];
		  $mixed['LINK'] = str_replace(array(
											'#IBLOCK_ID#',
											'#IBLOCK_TYPE#',
											'#MESSAGE_ID#'
											), array(
											 $arParams['IBLOCK_ID'],
											 $arParams['IBLOCK_TYPE'],
											 $result
											), $ADMIN_PATH);
	  
	      // /bitrix/admin/iblock_element_edit.php?IBLOCK_ID=#IBLOCK_ID#&type=#IBLOCK_TYPE#&ID=#MESSAGE_ID#
	  
		  // ������� ���������
		  //_print_r($arParams['EVENT_TYPE']);
		  //_print_r($mixed);
		  
		  if(strlen($arParams['EVENT_TYPE'])){
			$event = new CEvent;
			$eid = $event->Send($arParams['EVENT_TYPE'], SITE_ID, $mixed);
			//_print_r($eid);
			//_print_r(get_object_vars($event));
		  }
		  
		  //_print_r($mixed);
		  //_print_r(SITE_ID);
		  //_print_r('sent on '.$arParams['EVENT_TYPE']);
		  
		  if(strlen($arParams['SUCCESS_URL'])){
		   LocalRedirect($arParams['SUCCESS_URL']);
		   exit();
		  }
		  
		  $arResult['RESULT']['SUCCESS'] = true;
	  }
	 }
	 else
	  $arResult['RESULT']['FAIL'] = true;
	}

	// �����������-�� HTML-���
	foreach($arResult['FIELDS'] as $fid => $o)
	{
	 $err_class = '';//'class="#CLASS_HERE#'.($o['ERROR'] ? ' '.$arParams['ERROR_CSS_CLASS'] : '').'"';
	
	 if($o['ADVISED_TYPE'] == 'select')
	 {
	  $html = '<select name="'.$o['INPUT_NAME'].'"'.$err_class.'>';
	  foreach($o['ITEMS'] as $id=>$val)
	   $html .= '<option value="'.$id.'"'.($val == $o['VALUE'] ? ' selected' : '').'>'.$val.'</option>';
	  $html .= '</select>';
	 }
	 elseif($o['ADVISED_TYPE'] == 'file')
	  $html = '<input type="file" name="'.$o['INPUT_NAME'].'" value=""'.$err_class.' />';
	 elseif($o['ADVISED_TYPE'] == 'textarea')
	  $html = '<textarea name="'.$o['INPUT_NAME'].'"'.$err_class.'>'.$o['VALUE'].'</textarea>';
	 else
	 {
	  $html = '<input type="text" name="'.$o['INPUT_NAME'].'" value="'.$o['VALUE'].'"'.$err_class.' ';
	  
	  if($o['SYSTEM']['USER_TYPE'] == 'DateTime')
	  {
	   ob_start();
	   $APPLICATION->IncludeComponent(
										'bitrix:main.calendar',
										$arParams['CALENDAR_TEMPLATE'],
										array(
											'FORM_NAME' => $arParams['FORM_NAME'],
											'INPUT_NAME' => $o['INPUT_NAME'],
											'INPUT_VALUE' => '',
										),
										null,
										array('HIDE_ICONS' => 'Y')
									);
		$html .= ' appearance="datetime" />'.ob_get_contents();
		ob_end_clean();
									
	  }
	  else
	   $html .= ' />';
	 }
	 
     $arResult['FIELDS'][$fid]['ADVISED_HTML'] = $html;
	}
	
	//_print_r(_CIBlockFormTools::FormatEventDescription($arResult));
	//_print_r(_CIBlockFormTools::FormatMailTemplate($arResult));
	
	$this->IncludeComponentTemplate();

?>
<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("AW_IBFORM_NAME"),
	"DESCRIPTION" => GetMessage("AW_IBFORM_DESC"),
	"ICON" => "/images/aw_icon.gif",
	"PATH" => array(
		"ID" => "awesome_components",
		"NAME" => GetMessage("GROUP_AWESOME"),
	),
);
?>
<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentParameters = array(
	"PARAMETERS"  =>  array(
		"WORD_INPUT_NAME" => Array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("RC_WORD_INPUT_NAME"),
			"TYPE" => "STRING",
			"DEFAULT" => "captcha_word",
			"MULTIPLE" => "N",
		),
		"SID_INPUT_NAME" => Array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("RC_SID_INPUT_NAME"),
			"TYPE" => "STRING",
			"DEFAULT" => "captcha_sid",
			"MULTIPLE" => "N",
		),
		"FAILED" => Array(
			"PARENT" => "BASE",
			"NAME" => GetMessage("RC_FAILED"),
			"TYPE" => "STRING",
			"DEFAULT" => "",
			"MULTIPLE" => "N",
		),
	)
);

?>

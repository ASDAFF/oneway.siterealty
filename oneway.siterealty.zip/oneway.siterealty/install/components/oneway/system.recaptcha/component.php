<?
 if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
 
 ########################################################################

 $arResult = array();
 $arResult['CODE'] = $GLOBALS['APPLICATION']->CaptchaGetCode();
 
 if($_REQUEST['AJAX_CALL'] == 'Y')
 {
	$GLOBALS['APPLICATION']->RestartBuffer();
	?>
	{
		"result": true,
		"code": "<?=$arResult['CODE']?>"
	}
	<?
	die();
 }
 
 ########################################################################
	
 $this->IncludeComponentTemplate();
?>
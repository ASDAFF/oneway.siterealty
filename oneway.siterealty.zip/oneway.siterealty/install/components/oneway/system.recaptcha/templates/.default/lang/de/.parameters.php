<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Elementdatum anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Vorschaubild anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Vorschautext anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Element-Ьberschrift anzeigen";
?>
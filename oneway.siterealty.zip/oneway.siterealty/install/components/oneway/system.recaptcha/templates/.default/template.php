<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if($arParams['FAILED']):?>
	����� ��������.
<?endif?>

<div>
	<div>�������� ���</div>
	<div class="review_recaptcha">
		<div>
			<img class="-m-recaptcha-image -m-recaptcha-update" src="/bitrix/tools/captcha.php?captcha_code=<?=$arResult["CODE"]?>" alt="������� �������� ��� � ���� ��������" />
		</div>
		<div>
			<input class="-m-recaptcha-input" type="text" value="" name="<?=$arParams['WORD_INPUT_NAME']?>" style="text-transform: uppercase" /><br />
			<a href="javascript:void(0)" class="-m-recaptcha-update">�� ���� ��������</a>
			<a href="javascript:void(0)" class="-m-recaptcha-update -m-recaptcha-button"></a>
			<div class="-m-recaptcha-loader"></div>
		</div>									
		<input class="-m-recaptcha-code" type="hidden" name="<?=$arParams['SID_INPUT_NAME']?>" value="<?=$arResult["CODE"]?>"/>
	</div>
</div>

<style type="text/css">
	.-m-recaptcha-button,
	.-m-recaptcha-loader
	{
		background: url(<?=$templateFolder?>/img/captcha_update.png) 0 0 no-repeat scroll;
		width: 16px;
		height: 16px;
		display: block;
		position: absolute;
		top: 4px;
		right: -20px;
	}
	.-m-recaptcha-loader
	{
		background-image: url(<?=$templateFolder?>/img/recaptcha_loader.gif);
		display: none;
	}
</style>

<script type="text/javascript">
 window.jQuery || document.write('<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"><\/script>');
</script>
<script type="text/javascript">
	
	(function($){$.fn.recaptcha = function(options){function operations(options, dom){this.dom = dom;
	
		this.links = $('.-m-recaptcha-update', this.dom);
		this.button = $('.-m-recaptcha-button', this.dom);
		this.loader = $('.-m-recaptcha-loader', this.dom);
		this.img = $('.-m-recaptcha-image', this.dom);
		this.code = $('.-m-recaptcha-code', this.dom);
		this.word = $('.-m-recaptcha-input', this.dom);
	
		this.unlock = function()
		{
			this.button.show();
			this.loader.hide();
		}
		this.lock = function()
		{
			this.button.hide();
			this.loader.show();
		}
	
		var _this = this;
	
		this.links.click(function(){
			
			var fields = {};
			fields.AJAX_CALL = 'Y';
			
			_this.lock();
			$.ajax({
					url: '<?=$this->__component->__path?>/component.php',
					data: fields,
					type: "POST",
					dataType: "json",
					success: function(result){
				
												if(result.result)
												{
													_this.img.attr('src', '/bitrix/tools/captcha.php?captcha_code='+result.code);
													_this.code.val(result.code);
													_this.word.val('');
												}
						
												_this.unlock();
											},
					error: function(){
									  _this.unlock();
									 }
			});
			
		});
	
	}return new operations(options, this);}})( jQuery );
	
	$('.review_recaptcha').recaptcha();
</script>
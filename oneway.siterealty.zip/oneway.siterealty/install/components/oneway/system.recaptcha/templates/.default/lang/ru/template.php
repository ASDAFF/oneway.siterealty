<?
$MESS["CAPTCHA_TITLE"] = "Введите символы с картинки";
$MESS["CAPTCHA_BLOCK_TITLE"] = "Защитный код";
?>
<?
$MESS["RC_WORD_INPUT_NAME"] = "Значение аттрибута name поля ввода кода";
$MESS["RC_SID_INPUT_NAME"] = "Значение аттрибута name скрытого поля";
$MESS["RC_FAILED"] = "Индикатор провала";

?>
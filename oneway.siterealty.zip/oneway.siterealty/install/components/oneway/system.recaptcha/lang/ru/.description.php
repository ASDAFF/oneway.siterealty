<?
$MESS ['OW_COMPONENT_NAME'] = "Обновляемая captcha";
$MESS ['OW_COMPONENT_DESC'] = "Обновляемая captcha на ajax (v1.1 04.02.2013)";

$MESS ['GROUP_ONEWAY'] = "Разработки студии OneWay";
?>
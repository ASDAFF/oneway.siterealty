<?
//$MESS ['T_NEWS_NEWS_NA'] = "Раздел не найден.";
?>
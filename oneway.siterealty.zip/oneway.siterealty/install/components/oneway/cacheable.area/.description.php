<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("OW_PROMO_NAME"),
	"DESCRIPTION" => GetMessage("OW_PROMO_DESC"),
	"ICON" => "/images/oneway.gif",
	"PATH" => array(
		"ID" => "oneway_components",
		"NAME" => GetMessage("GROUP_ONEWAY"),
	),
);
?>
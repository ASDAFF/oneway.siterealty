<?
 $MESS['RC_WORD_INPUT_NAME'] = "Значение аттрибута name поля ввода слова";
 $MESS['RC_SID_INPUT_NAME'] = "Значение аттрибута name скрытого поля";
?>
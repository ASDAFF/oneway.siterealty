<?
$MESS ['OW_PROMO_NAME'] = "Кешируемая область";
$MESS ['OW_PROMO_DESC'] = "Кешируемая область.";

$MESS ['GROUP_ONEWAY'] = "Разработки студии OneWay";
?>
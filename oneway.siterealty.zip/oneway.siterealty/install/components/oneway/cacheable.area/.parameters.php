<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentParameters = array(
	"GROUPS" => array(
	),
	"PARAMETERS"  =>  array(
		// ��������� �����������
		"CACHE_TIME"  =>  Array("DEFAULT"=>36000),
		"SIGNIFICANT_VALUES" => Array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("CA_SIGNIFICANT_VALS"),
			"TYPE" => "STRING",
			"DEFAULT" => "",
			"ADDITIONAL_VALUES" => "Y",
			"MULTIPLE" => "Y",
		),
	),
);

?>

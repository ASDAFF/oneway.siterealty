<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if(!isset($arParams["CACHE_TIME"]))
	$arParams["CACHE_TIME"] = 3600;
	
if(!strlen($arParams['WORD_INPUT_NAME']))
	$arParams['WORD_INPUT_NAME'] = 'captcha_word';
if(!strlen($arParams['SID_INPUT_NAME']))
	$arParams['SID_INPUT_NAME'] = 'captcha_sid';
	
// ������ � �����	
if($this->StartResultCache(false, ($arParams["CACHE_GROUPS"]==="N"? false: $USER->GetGroups()), $arParams['SIGNIFICANT_VALUES']))
{		
	$this->IncludeComponentTemplate();
}
?>
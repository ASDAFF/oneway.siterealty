<?
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2014-03-11 17:00:00"
);
?>